import { lazy, Suspense, useEffect, useState } from 'react';
import './index.css';
import { TicketProvider, useTickets, useTicketSync } from './lib/TicketContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Hero from './sections/Hero';
import Destinations from './sections/Destinations';
import RoutesTable from './sections/RoutesTable';
import Fleet from './sections/Fleet';
import Passes from './sections/Passes';
import WhyAndTestimonials from './sections/WhyAndTestimonials';
import Faq from './sections/Faq';
import BookingWizard from './components/BookingWizard';
import FloatingWhatsApp from './components/FloatingWhatsApp';
import { ToastViewport } from './components/ui';

const AdminApp = lazy(() => import('./admin/AdminApp'));

function Orchestrator() {
  const { bookingOpen, setBookingOpen, modal, closeModal } = useTickets();
  useTicketSync();

  return (
    <div className="min-h-screen bg-[#f7f1e3] text-[#22312a]">
      <Navbar />
      <main>
        <Hero />
        <Destinations />
        <RoutesTable />
        <Fleet />
        <Passes />
        <WhyAndTestimonials />
        <Faq />
      </main>
      <Footer />

      <FloatingWhatsApp />
      <ToastViewport />

      {bookingOpen && <BookingWizard onClose={() => setBookingOpen(false)} />}
      {modal && (
        <div className="fixed inset-0 z-[70]">
          <div className="absolute inset-0 bg-[#04150e]/65 backdrop-blur-[2px]" onClick={closeModal} />
          <div className="absolute inset-0 overflow-y-auto p-4 flex">{modal}</div>
        </div>
      )}
    </div>
  );
}

const isAdminHash = () => window.location.hash.startsWith('#/admin');

export default function App() {
  // لوحة الإدارة على الرابط  /#/admin  — بقية الموقع كما هو
  const [admin, setAdmin] = useState(isAdminHash);
  useEffect(() => {
    const on = () => setAdmin(isAdminHash());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);

  if (admin) {
    return (
      <Suspense fallback={<div className="p-10 text-center font-bold text-[#6b5a2e]">جارٍ التحميل…</div>}>
        <AdminApp />
      </Suspense>
    );
  }
  return (
    <TicketProvider>
      <Orchestrator />
    </TicketProvider>
  );
}
