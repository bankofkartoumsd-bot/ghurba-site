import { useMemo, useState } from 'react';
import { ArrowLeft, Search, Plane, Bus, Clock, Wallet2 } from 'lucide-react';
import { SectionHead, GoldButton } from '../components/ui';
import { ROUTES, cityById, fmt, minutesLabel, SDG_PER_USD } from '../lib/data';
import { useTickets } from '../lib/TicketContext';
import { EMPTY_DRAFT } from '../lib/tickets';

type Filter = 'all' | 'domestic' | 'intl';

export default function RoutesTable() {
  const { patchDraft, setBookingOpen } = useTickets();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<Filter>('all');

  const rows = useMemo(() => {
    const term = q.trim();
    return ROUTES.filter(r => {
      if (filter === 'domestic' && r.intl) return false;
      if (filter === 'intl' && !r.intl) return false;
      if (!term) return true;
      const f = cityById(r.from)?.name ?? '', t = cityById(r.to)?.name ?? '';
      return f.includes(term) || t.includes(term);
    });
  }, [q, filter]);

  const book = (routeId: string) => {
    const r = ROUTES.find(x => x.id === routeId)!;
    const f = cityById(r.from)!, t = cityById(r.to)!;
    patchDraft({
      ...EMPTY_DRAFT, fromId: r.from, toId: r.to, fromName: f.name, toName: t.name,
      routeId: r.id, minutes: r.minutes, dateISO: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
      time: '09:00', intl: !!r.intl, seats: 45,
    });
    setBookingOpen(true);
  };

  return (
    <section id="routes-table" className="bg-[#0c3b2e] py-14 sm:py-18 text-[#f7f1e3] relative overflow-hidden">
      <img src="/images/station-dusk.jpg" alt="محطة بصات الغربة عند الغروب" aria-hidden="true"
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-[0.16]" />
      <div className="relative mx-auto max-w-7xl px-4">
        <SectionHead dark kicker="الخطوط والأسعار" title="شبكة الغربة كاملة — خط خط" sub="الأسعار استرشادية شاملة الوجبة والحقيبة (25kg) — الدولي بالدولار ويُسدد ببنكك أو فوري أو مدى. اضغط «احجز» على أي خط." />

        {/* أدوات التحكم */}
        <div className="mt-8 flex flex-col items-center justify-between gap-3 md:flex-row">
          <div className="flex items-center gap-1.5 rounded-2xl bg-[#071f16] p-1.5 ring-1 ring-[#e3b54a]/25">
            {([['all', 'الكل'], ['domestic', 'داخل السودان'], ['intl', 'دولي']] as const).map(([v, l]) => (
              <button key={v} onClick={() => setFilter(v)}
                className={`flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-[12px] font-bold transition ${filter === v ? 'bg-[#e3b54a] text-[#2b1d05]' : 'text-[#cfe3d6] hover:text-[#f7f1e3]'}`}>
                {v === 'intl' ? <Plane size={13} /> : <Bus size={13} />}{l}
              </button>
            ))}
          </div>
          <label className="relative w-full md:w-80">
            <Search size={16} className="absolute start-3.5 top-1/2 -translate-y-1/2 text-[#e3b54a]/70" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="دوّر على مدينة… (مثال: بورتسودان)" aria-label="البحث في الخطوط"
              className="w-full rounded-2xl border border-[#e3b54a]/30 bg-[#071f16] py-3 ps-10 pe-4 text-[13px] text-[#f7f1e3] placeholder-[#cfe3d6]/40 outline-none focus:border-[#e3b54a]" />
          </label>
        </div>

        {/* الجدول */}
        <div className="mt-5 overflow-hidden rounded-2xl ring-1 ring-[#e3b54a]/30 shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-[12px]">
              <thead>
                <tr className="bg-[#071f16] text-[#e3b54a]">
                  <th className="px-4 py-3 text-start font-display">الخط — من ← إلى</th>
                  <th className="px-4 py-3 text-start font-display"><Clock size={13} className="inline" /> المدة</th>
                  <th className="px-4 py-3 text-start font-display">السعر</th>
                  <th className="px-4 py-3 text-start font-display hidden lg:table-cell">أبرز المحطات</th>
                  <th className="px-4 py-3 text-start font-display"></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => {
                  const f = cityById(r.from)!, t = cityById(r.to)!;
                  return (
                    <tr key={r.id} className={`${i % 2 ? 'bg-[#0f4634]' : 'bg-[#0c3b2e]'} transition hover:bg-[#155741]`}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2 font-bold text-[#f7f1e3]">
                          {f.name}
                          <ArrowLeft size={14} className="text-[#e3b54a]" />
                          {t.name}
                          {r.intl && <span className="rounded-md bg-[#e3b54a]/20 px-1.5 py-0.5 text-[8.5px] font-black text-[#e3b54a]">دولي</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-[#cfe3d6]">{minutesLabel(r.minutes)}</td>
                      <td className="px-4 py-3">
                        <span className="font-changa font-bold text-[#f4cd6f]">{r.intl ? `$${fmt(r.priceUSD!)}` : `${fmt(r.priceSDG!)} ج.س`}</span>
                        {!r.intl && <span className="block text-[9px] text-[#cfe3d6]/70">≈ ${fmt(r.priceSDG! / SDG_PER_USD)}</span>}
                      </td>
                      <td className="hidden max-w-[220px] truncate px-4 py-3 text-[10px] text-[#cfe3d6]/85 lg:table-cell" title={r.stops.join('، ')}>{r.stops.join(' • ')}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => book(r.id)} className="rounded-lg bg-[#e3b54a] px-3.5 py-2 text-[10.5px] font-black text-[#2b1d05] transition hover:brightness-110">احجز</button>
                      </td>
                    </tr>
                  );
                })}
                {rows.length === 0 && (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-sm text-[#cfe3d6]/70">ما لقينا خط بهذا الاسم — جرّب «الخرطوم» أو «بورتسودان».</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-[11px] text-[#cfe3d6]/85">
          <span className="flex items-center gap-1.5"><Wallet2 size={13} className="text-[#e3b54a]" /> بنكك • فوري • ماي كاشي • ميزة • مدى • STC Pay • أبل باي • فوري مصر</span>
          <span className="hidden h-1 w-1 rounded-full bg-[#e3b54a]/60 sm:block" />
          <span>ركوب/إنزال في أي محطة على الخط</span>
        </div>
      </div>
    </section>
  );
}
