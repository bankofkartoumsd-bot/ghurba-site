import { useState } from 'react';
import { ChevronDown, MessageCircle } from 'lucide-react';
import { SectionHead } from '../components/ui';
import { WHATSAPP } from '../lib/data';

const FAQS = [
  { q: 'كيف أحجز تذكرة بصات الغربة أونلاين؟', a: 'اضغط «احجز تذكرتك» في أي مكان بالموقع، اختار (من ← إلى) وتاريخ الإقلاع، اختار البص والمقعد، ادفع ببنكك أو فوري أو ميزة أو مدى — واستلم الكرت الرقمي فوراً على الشاشة وفي «محفظتي».' },
  { q: 'ما هي طرق الدفع المقبولة؟', a: 'داخل السودان: بنكك (بنك الخرطوم)، ماي كاشي، فوري السودان، ونقاط البيع في المواقف. في مصر: ميزة، فودافون كاش، أورنج كاش، إنستاباي، وفوري مصر. في السعودية: مدى، STC Pay، أبل باي. ودولياً: فيزا وماستر كارد (3D Secure).' },
  { q: 'أقدر ألغي الحجز أو أسترد المبلغ؟', a: 'أكيد — إلغاء مجاني قبل 6 ساعات من الإقلاع واسترداد 100%. بين 6 ساعات وساعة: استرداد 50%. أقل من ساعة: التذكرة تتحول لرصيد في «باسبور الغربة» صالحة شهرين. اطلب الإلغاء من «محفظتي» أو على 19988.' },
  { q: 'هل أقدر أركب من محطة غير المحطة الرئيسية؟', a: 'أيوه — كل خط ليه نقاط صعود وإنزال على طول الطريق (مثلاً شندي وعطبرة في طريق الخرطوم ← بورتسودان). بس ننبّه: المحطات الجانبية بتحتاج الحجز قبلها بـ 3 ساعات على الأقل.' },
  { q: 'كم مسموح من الأمتعة؟', a: '25 كيلوجرام مجاناً لكل مسافر + حقيبة يد داخل البص. الزيادة 5,000 ج.س لكل 10kg. خطوط دارفور والدولي مسموح فيها 35kg مجاناً.' },
  { q: 'ما هي إجراءات السفر الدولي (مصر / السعودية)؟', a: 'جواز سفر ساري المفعول 6 أشهر على الأقل + تأشيرة إذا كانت مطلوبة لوجهتك. بصاتنا الدولية بتوقف في إجراءات المنافذ الرسمية مع مرشد الغربة طوال الطريق.' },
  { q: 'نسيت تحجز ورحت الموقف — أقدر أدفع كاش؟', a: 'طبعاً — المواقف الرئيسية شغالة 24/7 وشباك الغربة بيقبل كاش وماي كاشي وبنكك لحظة بلحظة، بس الأفضل تحجز مقدم عشان تضمن مقعدك في المواعيد المزدحمة.' },
];

export default function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <section className="bg-[#fcfaf3] py-14 sm:py-18">
      <div className="mx-auto max-w-4xl px-4">
        <SectionHead kicker="أسئلة شائعة" title="كل اللي عايز تعرفه عن السفر" />
        <div className="mt-9 divide-y divide-[#0c3b2e]/10 overflow-hidden rounded-2xl border border-[#0c3b2e]/12 bg-white shadow-sm">
          {FAQS.map((f, i) => (
            <div key={i}>
              <button onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-start transition hover:bg-[#0c3b2e]/4">
                <span className="font-display text-[13.5px] font-extrabold text-[#0c3b2e]">{f.q}</span>
                <ChevronDown size={18} className={`shrink-0 text-[#c9992e] transition-transform duration-300 ${open === i ? 'rotate-180' : ''}`} />
              </button>
              {open === i && <div className="px-5 pb-4"><p className="border-s-2 border-[#e3b54a] ps-4 text-[12px] leading-7 text-[#3d4a41]">{f.a}</p></div>}
            </div>
          ))}
        </div>
        <p className="mt-5 text-center text-[12px] text-[#4c5a50]">ما لقيتش إجابتك؟ <a href={WHATSAPP} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-bold text-[#0c3b2e] underline decoration-[#e3b54a] decoration-2 underline-offset-4 hover:text-[#c9992e]"><MessageCircle size={13} /> اسألنا على واتساب</a> — بنرد في أقل من 5 دقائق.</p>
      </div>
    </section>
  );
}
