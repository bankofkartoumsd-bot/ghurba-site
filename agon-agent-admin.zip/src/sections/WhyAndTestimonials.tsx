import { ShieldCheck, Armchair, Wallet2, Headset, Star, Quote, BadgeCheck } from 'lucide-react';
import { SectionHead } from '../components/ui';

const WHY = [
  { icon: ShieldCheck, title: 'أمان قبل كل شيء', desc: 'سائقون بخبرة +7 سنوات، فحص 40 نقطة قبل كل رحلة، وأجهزة تتبع GPS لحظي توصل لأهلك.' },
  { icon: Armchair, title: 'كراسي تريحك فعلًا', desc: 'كراسي إسفنجية عالية الكثافة متكئة حتى 160° مع مسند أرجل — رحلة الشمال ما بتوجع ضهرك.' },
  { icon: Wallet2, title: 'أسعار عادلة بدون مفاجآت', desc: 'السعر اللي بتشوفه هو اللي بتدفعه — الوجبة والحقيبة (25kg) مشمولة في كل التذاكر.' },
  { icon: Headset, title: 'دعم سوداني 24/7', desc: '19988 من أي شبكة — من بدري الصبح لآخر رحلة بالليل، حتى في رمضان والعيد.' },
];

const REVIEWS = [
  { name: 'سارة الطيب', from: 'الخرطوم ← بورتسودان', rating: 5, text: 'سافرت مع الغربة لأول مرة وكان الفرق واضح — البص نظيف، الواي فاي شغال، والسائق محترف. وصلنا في المعاد بالظبط.', date: 'منذ أسبوع' },
  { name: 'عثمان محمد أحمد', from: 'أم درمان ← عطبرة', rating: 5, text: 'بحجز من التطبيق من 3 سنين — الكود بيوصلني في دقيقة والرحلة دايماً في وقتها. أصحابي كلهم بسافروا بيها.', date: 'منذ 3 أيام' },
  { name: 'مريم الأنصاري', from: 'القاهرة ← الخرطوم', rating: 5, text: 'رحلة القاهرة الشاقة صارت سهلة — كراسي جلد، وجبة محترمة، والأهم إن حقائبي وصلت معاي من غير مشاكل.', date: 'منذ شهر' },
  { name: 'خالد النور', from: 'الخرطوم ← جدة', rating: 4, text: 'الباقة الشهرية وفّرت لي ربع مرتبي تقريباً — كل شهر بروح جدة مرتاح وأوصل بالسلامة. شكراً بصات الغربة.', date: 'منذ أسبوعين' },
];

export default function WhyAndTestimonials() {
  return (
    <section className="bg-[#f7f1e3] py-14 sm:py-18">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHead kicker="ليه الغربة؟" title="لأن الرحلة أهم من الوجهة" />

        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {WHY.map(w => (
            <div key={w.title} className="group rounded-2xl border border-[#0c3b2e]/12 bg-[#fcfaf3] p-5 shadow-sm transition hover:-translate-y-1 hover:border-[#c9992e] hover:shadow-[0_18px_40px_-18px_rgba(201,153,46,.45)]">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#0c3b2e] text-[#e3b54a] transition group-hover:scale-110"><w.icon size={23} /></span>
              <h3 className="mt-3 font-display font-extrabold text-[#0c3b2e]">{w.title}</h3>
              <p className="mt-1.5 text-[11.5px] leading-6 text-[#4c5a50]">{w.desc}</p>
            </div>
          ))}
        </div>

        {/* آراء المسافرين */}
        <div className="mt-12">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-[#c9992e]">آراء المسافرين</p>
              <h3 className="mt-1 font-display text-2xl font-black text-[#0c3b2e]">+18,400 مسافر قالوا رأيهم</h3>
            </div>
            <div className="flex items-center gap-3 rounded-2xl bg-[#0c3b2e] px-5 py-3 text-[#f7f1e3]">
              <span className="font-changa text-3xl font-extrabold text-[#e3b54a]">4.9</span>
              <span className="text-[10px] leading-4 text-[#cfe3d6]">متوسط التقييم<br /><span className="flex gap-0.5 pt-0.5">{[...Array(5)].map((_, i) => <Star key={i} size={11} className="fill-[#e3b54a] text-[#e3b54a]" />)}</span></span>
            </div>
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {REVIEWS.map(r => (
              <figure key={r.name} className="flex flex-col rounded-2xl border border-[#0c3b2e]/12 bg-[#fcfaf3] p-5 shadow-sm">
                <Quote size={22} className="text-[#e3b54a]" />
                <blockquote className="mt-2 flex-1 text-[11.5px] leading-6 text-[#22312a]">“{r.text}”</blockquote>
                <div className="mt-3 border-t border-[#0c3b2e]/10 pt-3">
                  <div className="flex gap-0.5">{[...Array(5)].map((_, i) => <Star key={i} size={11} className={i < r.rating ? 'fill-[#e3b54a] text-[#c9992e]' : 'text-[#d8cfae]'} />)}</div>
                  <figcaption className="mt-1.5 flex items-center gap-1.5 text-[11px]">
                    <BadgeCheck size={13} className="text-emerald-600" />
                    <span className="font-bold text-[#0c3b2e]">{r.name}</span>
                    <span className="text-[#8a6a12]">• {r.from}</span>
                  </figcaption>
                  <p className="mt-0.5 text-[9px] text-[#9aa89c]">{r.date} — رحلة موثّقة</p>
                </div>
              </figure>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
