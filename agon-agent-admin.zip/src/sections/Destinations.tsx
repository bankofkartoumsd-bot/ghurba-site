import { MapPin, Clock, BusFront } from 'lucide-react';
import { SectionHead } from '../components/ui';
import { useTickets } from '../lib/TicketContext';
import { EMPTY_DRAFT } from '../lib/tickets';
import { CITIES, findRoute, fmt, minutesLabel, SDG_PER_USD } from '../lib/data';

interface Dest { img: string; cityId: string; blurb: string; tag: string; }
const DESTS: Dest[] = [
  { img: '/images/dest-portsudan.jpg', cityId: 'portsudan', tag: 'رحلات يومية 5:30 صباحاً', blurb: 'عاصمة البحر الأحمر — الميناء والشواطئ الذهبية' },
  { img: '/images/dest-kassala.jpg', cityId: 'kassala', tag: '3 رحلات يومياً', blurb: 'جبل توكر العملاق وسهليات البطانة' },
  { img: '/images/dest-omdurman.jpg', cityId: 'omdurman', tag: 'كل ساعة', blurb: 'على ضفاف النيل — سوق أم درمان الكبير' },
  { img: '/images/dest-desert.jpg', cityId: 'atbara', tag: 'كل ساعة صباحاً', blurb: 'عبر طريق الشمال — عطبرة، شندي وأبو حمد' },
  { img: '/images/dest-cairo.jpg', cityId: 'cairo', tag: 'الاثنين والخميس', blurb: 'القاهرة ووادي النيل — رحلة الغربة الكبرى' },
  { img: '/images/dest-dubai.jpg', cityId: 'jeddah', tag: 'الثلاثاء والجمعة', blurb: 'جدة والرياض — للمغتربين والزوار' },
];

export default function Destinations() {
  const { patchDraft, setBookingOpen } = useTickets();
  const book = (cityId: string) => {
    const target = cityId === 'khartoum' ? 'portsudan' : cityId;
    const r = findRoute('khartoum', target);
    const toC = CITIES.find(c => c.id === target)!;
    patchDraft({
      ...EMPTY_DRAFT, fromId: 'khartoum', toId: target,
      fromName: 'الخرطوم', toName: toC.name,
      routeId: r?.id ?? '', minutes: r?.minutes ?? 0,
      dateISO: new Date(Date.now() + 86400000).toISOString().slice(0, 10), time: '09:00',
      intl: !!r?.intl, seats: 45,
    });
    setBookingOpen(true);
  };

  return (
    <section id="routes" className="relative bg-[#f7f1e3] star-pattern-soft py-14 sm:py-18">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHead kicker="الوجهات" title="وين رايح يا غالي؟" sub="اختر وجهتك واضغط — نحجز ليك على طول من الخرطوم. كل الخطوط تمر بمواقفنا الرئيسية مع إمكانيات الركوب من أي محطة." />
        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {DESTS.map(d => {
            const city = CITIES.find(c => c.id === d.cityId)!;
            const r = findRoute('khartoum', d.cityId);
            const price = r ? (r.intl ? `$${fmt(r.priceUSD!)}` : `${fmt(r.priceSDG!)} ج.س ≈ $${fmt(r.priceSDG! / SDG_PER_USD)}`) : '';
            return (
              <button key={d.cityId} onClick={() => book(d.cityId)} aria-label={`احجز من الخرطوم إلى ${city.name}`}
                className="group relative overflow-hidden rounded-2xl text-start shadow-md ring-1 ring-black/10 transition duration-300 hover:-translate-y-1.5 hover:shadow-[0_26px_50px_-18px_rgba(7,31,22,.55)]">
                <img src={d.img} alt={city.name} loading="lazy"
                  className="h-52 w-full object-cover transition duration-700 group-hover:scale-110 sm:h-60" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#04150e]/92 via-[#04150e]/35 to-transparent" />
                <span className="absolute top-3 start-3 rounded-full bg-[#e3b54a] px-3 py-1 text-[9.5px] font-black text-[#2b1d05] shadow">{d.tag}</span>
                <div className="absolute inset-x-0 bottom-0 p-4">
                  <p className="flex items-center gap-1.5 font-changa text-2xl font-extrabold text-[#f7f1e3]"><MapPin size={17} className="text-[#e3b54a]" />{city.name}</p>
                  <p className="mt-0.5 text-[11px] leading-5 text-[#e9e4cd]">{d.blurb}</p>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10.5px] font-bold text-[#e3b54a]">
                      {r && <><Clock size={11} />{minutesLabel(r.minutes)}</>}
                      {price && <span className="text-[#f7f1e3]/90">• {price}</span>}
                    </span>
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#e3b54a] text-[#2b1d05] transition group-hover:rotate-[-12deg]"><BusFront size={16} /></span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
