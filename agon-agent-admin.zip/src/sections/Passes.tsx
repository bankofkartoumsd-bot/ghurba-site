import { Check, Crown, GraduationCap, IdCard, BadgeCheck } from 'lucide-react';
import { SectionHead, GoldButton } from '../components/ui';
import { PASSES, fmt } from '../lib/data';
import { useTickets } from '../lib/TicketContext';

const PASS_ICON = [IdCard, Crown, GraduationCap];

export default function Passes() {
  const { toast, setBookingOpen } = useTickets();
  const buy = (name: string) => {
    toast('تم استلام طلب اشتراكك!', `باقة «${name}» — سيصلك رابط الدفع على واتساب خلال دقائق.`, 'ok');
  };

  return (
    <section id="passes" className="relative bg-[#071f16] py-14 sm:py-18 text-[#f7f1e3] star-pattern">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHead dark kicker="باقات الغربة" title="سافر مرتاح — وادفع أقل" sub="باقات اشتراك شهرية وسنوية للمسافرين الدائمين والطلبة — تتجدد تلقائياً وتنفع على كل الخطوط الداخلية والدولية." />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {PASSES.map((p, i) => {
            const Icon = PASS_ICON[i];
            return (
              <div key={p.id}
                className={`relative flex flex-col rounded-3xl p-6 ring-1 transition hover:-translate-y-1.5 duration-300 ${p.popular ? 'bg-gradient-to-b from-[#114e3c] to-[#0c3b2e] ring-[#e3b54a] shadow-[0_25px_60px_-15px_rgba(227,181,74,.35)] md:scale-[1.04]' : 'bg-[#0c3b2e]/80 ring-[#e3b54a]/25'}`}>
                {p.popular && <span className="absolute -top-3.5 start-1/2 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full bg-[#e3b54a] px-4 py-1.5 text-[10px] font-black text-[#2b1d05] shadow"><Crown size={12} /> الأكثر طلباً — وفّر 22%</span>}
                <Icon size={30} className="text-[#e3b54a]" />
                <h3 className="mt-3 font-display text-2xl font-black text-[#f7f1e3]">{p.name}</h3>
                <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#cfe3d6]/70">{p.nameEn}</p>
                <p className="mt-4 font-changa"><span className="text-4xl font-extrabold text-[#f4cd6f]">{fmt(p.priceSDG)}</span> <span className="text-xs text-[#cfe3d6]">ج.س / {p.validityDays} يوم</span></p>
                <p className="text-[11px] font-bold text-[#e3b54a]">{p.trips} رحلات ذهاباً مشمولة</p>
                <ul className="mt-4 flex-1 space-y-2">
                  {p.perks.map(perk => (
                    <li key={perk} className="flex items-start gap-2 text-[11.5px] leading-5 text-[#e9e4cd]"><BadgeCheck size={14} className="mt-0.5 shrink-0 text-[#e3b54a]" />{perk}</li>
                  ))}
                </ul>
                <GoldButton onClick={() => buy(p.name)} className="mt-5 w-full !py-3 text-sm">اشترك الآن — ادفع عند الموقف أو أونلاين</GoldButton>
              </div>
            );
          })}
        </div>
        <p className="mt-5 text-center text-[11px] text-[#cfe3d6]/75">أو <button className="font-bold text-[#e3b54a] underline underline-offset-2 hover:brightness-110" onClick={() => setBookingOpen(true)}>احجز تذكرة واحدة</button> من غير اشتراك — الإلغاء مجاني حتى 6 ساعات قبل الإقلاع.</p>
      </div>
    </section>
  );
}
