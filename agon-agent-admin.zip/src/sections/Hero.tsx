import { useState } from 'react';
import { ArrowLeftRight, CalendarDays, ChevronDown, Search, Star, MapPin, Clock, Sparkles, ShieldCheck, Users } from 'lucide-react';
import { CITIES, SDG_PER_USD, fmt, findRoute, minutesLabel } from '../lib/data';
import { useTickets } from '../lib/TicketContext';
import { EMPTY_DRAFT } from '../lib/tickets';
import { GoldButton } from '../components/ui';
import GhurbaLogo from '../components/GhurbaLogo';

const DESTS = ['الخرطوم', 'بورتسودان', 'عطبرة', 'كسلا', 'ود مدني', 'الدمازين', 'الجنينة', 'القضارف', 'كوستي', 'الفاشر', 'القاهرة', 'جدة', 'الرياض'];

export default function Hero() {
  const { patchDraft, setBookingOpen, toast } = useTickets();
  const [tripType, setTripType] = useState<'oneway' | 'round'>('oneway');
  const [fromId, setFromId] = useState('khartoum');
  const [toId, setToId] = useState('portsudan');
  const [dateISO, setDateISO] = useState(() => new Date(Date.now() + 86400000).toISOString().slice(0, 10));
  const [time, setTime] = useState('09:00');

  const minDate = new Date().toISOString().slice(0, 10);
  const r = findRoute(fromId, toId);

  const search = () => {
    if (fromId === toId) { toast('اختر مدينتي مختلفتين', 'لا يمكن الحجز من المدينة إلى نفسها.', 'warn'); return; }
    if (!r) { toast('لا يوجد خط مباشر', 'جرّب الخرطوم أو بورتسودان كمفترق رئيسي.', 'err'); return; }
    const f = CITIES.find(c => c.id === fromId)!, t = CITIES.find(c => c.id === toId)!;
    patchDraft({
      ...EMPTY_DRAFT, tripType, fromId, toId, fromName: f.name, toName: t.name,
      routeId: r.id, minutes: r.minutes, dateISO, time,
      intl: !!r.intl, seats: 45,
    });
    setBookingOpen(true);
  };

  return (
    <section id="home" className="relative overflow-hidden">
      {/* الخلفية */}
      <img src="/images/hero-desert.jpg" alt="بص بصات الغربة على طريق الصحراء بين مدن السودان" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-l from-[#04150e]/88 via-[#071f16]/60 to-[#071f16]/15" aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#04150e]/85 via-transparent to-[#04150e]/35" aria-hidden="true" />
      {/* جزيئات الغبار الذهبية */}
      {[...Array(7)].map((_, i) => (
        <span key={i} aria-hidden="true" className="dust absolute bottom-[18%] h-1.5 w-1.5 rounded-full bg-[#e3b54a]/70" style={{ insetInlineStart: `${8 + i * 13}%`, animationDelay: `${i * 0.9}s` }} />
      ))}

      <div className="relative mx-auto grid max-w-7xl gap-8 px-4 pb-14 pt-10 sm:pt-14 lg:grid-cols-12 lg:gap-10 lg:pb-20 lg:pt-20">
        {/* ── النص ── */}
        <div className="lg:col-span-7 flex flex-col justify-center text-[#f7f1e3]">
          <span className="inline-flex w-fit items-center gap-2 rounded-full bg-[#e3b54a]/15 px-4 py-1.5 text-[10.5px] font-bold text-[#e3b54a] ring-1 ring-[#e3b54a]/45 backdrop-blur">
            <Sparkles size={13} /> منذ 1998 — شريك السفر الأول في السودان
          </span>
          <h1 className="mt-4 font-amiri font-bold text-5xl leading-[1.18] sm:text-6xl xl:text-7xl">
            الغُربَة تبدا<br />
            <span className="text-[#e3b54a]">من هنا.</span>
          </h1>
          <p className="mt-4 max-w-xl text-base leading-8 text-[#e9e4cd] sm:text-lg sm:leading-9">
            احجز تذكرة البص من <b className="text-[#e3b54a]">الخرطوم إلى بورتسودان، عطبرة، القاهرة وجدة</b> — أونلاين في دقيقتين،
            اختار مقعدك، ادفع ببنكك أو فوري أو ميزة، واستلم كرتك الرقمي على طول.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <GoldButton onClick={() => setBookingOpen(true)} className="text-base !px-8 !py-4">احجز تذكرتك الآن <ArrowLeftRight size={19} /></GoldButton>
            <a href="#routes" className="rounded-xl border border-[#f7f1e3]/40 px-6 py-4 font-display font-bold text-[#f7f1e3] backdrop-blur transition hover:border-[#e3b54a] hover:text-[#e3b54a]">استكشف الخطوط ←</a>
          </div>

          {/* أرقام الثقة */}
          <div className="mt-7 flex flex-wrap items-center gap-x-7 gap-y-3 text-[11px] text-[#cfe3d6]">
            <span className="flex items-center gap-2"><Users size={15} className="text-[#e3b54a]" /><b className="text-[#f7f1e3]">+2.4 مليون</b> مسافر عبروا الغربة</span>
            <span className="flex items-center gap-2"><ShieldCheck size={15} className="text-[#e3b54a]" /><b className="text-[#f7f1e3]">99.2%</b> رحلات في موعدها</span>
            <span className="flex items-center gap-2"><Star size={15} className="fill-[#e3b54a] text-[#e3b54a]" /><b className="text-[#f7f1e3]">4.9/5</b> (18,400 تقييم)</span>
          </div>
        </div>

        {/* ── بطاقة البحث السريع ── */}
        <div className="lg:col-span-5 flex items-center">
          <form onSubmit={e => { e.preventDefault(); search(); }}
            className="relative w-full rounded-3xl bg-[#fcfaf3] p-4 sm:p-5 shadow-[0_30px_70px_-20px_rgba(0,0,0,.6)] ring-1 ring-[#c9992e]/50">
            <span className="absolute -top-3 end-4 rounded-full bg-[#0c3b2e] px-3 py-1 text-[9.5px] font-black text-[#e3b54a] ring-1 ring-[#e3b54a]/60">ذهاب وعودة = خصم 10%</span>
            <div className="flex items-center gap-2.5 border-b border-[#0c3b2e]/10 pb-2.5">
              <GhurbaLogo size={34} withWord={false} />
              <p className="font-display text-base font-black text-[#0c3b2e]">ابحث عن رحلتك</p>
            </div>

            <div className="mt-3 flex gap-1.5 rounded-xl bg-[#0c3b2e]/6 p-1 ring-1 ring-[#0c3b2e]/10">
              {([['oneway', 'اتجاه واحد'], ['round', 'ذهاب وعودة']] as const).map(([v, l]) => (
                <button key={v} type="button" onClick={() => setTripType(v)}
                  className={`flex-1 rounded-lg py-2 text-[11.5px] font-bold transition ${tripType === v ? 'bg-[#0c3b2e] text-[#f7f1e3]' : 'text-[#0c3b2e]'}`}>{l}</button>
              ))}
            </div>

            <div className="relative mt-3 grid grid-cols-[1fr_auto_1fr] items-end gap-1.5">
              <label className="block">
                <span className="mb-1 block text-[10px] font-bold text-[#0c3b2e]">من</span>
                <div className="relative">
                  <MapPin size={14} className="pointer-events-none absolute start-2.5 top-1/2 -translate-y-1/2 text-emerald-700" />
                  <select value={fromId} onChange={e => setFromId(e.target.value)} aria-label="مدينة المغادرة"
                    className="w-full appearance-none rounded-xl border border-[#0c3b2e]/20 bg-white py-3 ps-8 pe-6 text-[12px] font-bold outline-none focus:border-[#c9992e]">
                    {CITIES.filter(c => c.country === 'SD').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    <optgroup label="مصر">{CITIES.filter(c => c.country === 'EG').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</optgroup>
                    <optgroup label="السعودية">{CITIES.filter(c => c.country === 'SA').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</optgroup>
                  </select>
                  <ChevronDown size={13} className="pointer-events-none absolute end-2 top-1/2 -translate-y-1/2 text-[#6b5a2e]" />
                </div>
              </label>
              <button type="button" onClick={() => { setFromId(toId); setToId(fromId); }} aria-label="عكس الاتجاه"
                className="mb-1 flex h-9 w-9 items-center justify-center rounded-full bg-[#e3b54a] text-[#2b1d05] ring-1 ring-[#8a6a12] transition hover:rotate-180 duration-300">
                <ArrowLeftRight size={16} />
              </button>
              <label className="block">
                <span className="mb-1 block text-[10px] font-bold text-[#0c3b2e]">إلى</span>
                <div className="relative">
                  <MapPin size={14} className="pointer-events-none absolute start-2.5 top-1/2 -translate-y-1/2 text-rose-600" />
                  <select value={toId} onChange={e => setToId(e.target.value)} aria-label="مدينة الوصول"
                    className="w-full appearance-none rounded-xl border border-[#0c3b2e]/20 bg-white py-3 ps-8 pe-6 text-[12px] font-bold outline-none focus:border-[#c9992e]">
                    {CITIES.filter(c => c.country === 'SD').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    <optgroup label="مصر">{CITIES.filter(c => c.country === 'EG').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</optgroup>
                    <optgroup label="السعودية">{CITIES.filter(c => c.country === 'SA').map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</optgroup>
                  </select>
                  <ChevronDown size={13} className="pointer-events-none absolute end-2 top-1/2 -translate-y-1/2 text-[#6b5a2e]" />
                </div>
              </label>
            </div>

            <div className="mt-2.5 grid grid-cols-2 gap-2">
              <label className="block">
                <span className="mb-1 block text-[10px] font-bold text-[#0c3b2e]"><CalendarDays size={10} className="inline" /> التاريخ</span>
                <input type="date" min={minDate} value={dateISO} onChange={e => setDateISO(e.target.value)} aria-label="تاريخ السفر"
                  className="w-full rounded-xl border border-[#0c3b2e]/20 bg-white px-2.5 py-3 text-[12px] font-bold outline-none focus:border-[#c9992e]" />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10px] font-bold text-[#0c3b2e]"><Clock size={10} className="inline" /> الإقلاع</span>
                <select value={time} onChange={e => setTime(e.target.value)} aria-label="وقت الإقلاع"
                  className="w-full appearance-none rounded-xl border border-[#0c3b2e]/20 bg-white px-2.5 py-3 font-mono text-[12px] font-bold outline-none focus:border-[#c9992e]">
                  {['05:30','07:00','09:00','11:00','13:30','15:00','17:30','20:00','22:00'].map(t => <option key={t}>{t}</option>)}
                </select>
              </label>
            </div>

            {r && (
              <p className="mt-2.5 rounded-lg bg-[#0c3b2e]/5 px-3 py-1.5 text-center text-[10.5px] font-bold text-[#0c3b2e]">
                {minutesLabel(r.minutes)} — {r.intl ? `من $${r.priceUSD}` : `من ${fmt(r.priceSDG!)} ج.س (≈ $${fmt(r.priceSDG! / SDG_PER_USD)})`}
              </p>
            )}
            <GoldButton type="submit" className="mt-3 w-full !py-4 text-[15px]"><Search size={19} /> ابحث عن البصات المتاحة</GoldButton>
          </form>
        </div>
      </div>

      {/* ── ماركي الوجهات + البص المتحرك ── */}
      <div className="relative border-t border-[#e3b54a]/25 bg-[#04150e]/88 backdrop-blur">
        <div className="marquee-mask overflow-hidden py-2" dir="ltr">
          <div className="animate-marquee flex items-center gap-8 whitespace-nowrap">
            {[...DESTS, ...DESTS].map((d, i) => (
              <span key={i} className="flex items-center gap-2 text-[11px] font-bold tracking-wide text-[#e9e2c8]">
                <span className="h-1.5 w-1.5 rounded-full bg-[#e3b54a]" /> {d}
              </span>
            ))}
          </div>
        </div>
        {/* خط الرحلة المتحرك */}
        <div className="pointer-events-none absolute inset-x-0 top-1/2 hidden h-px lg:block" aria-hidden="true">
          <svg className="h-px w-full" preserveAspectRatio="none" viewBox="0 0 100 1"><line x1="0" y1="0.5" x2="100" y2="0.5" stroke="#e3b54a" strokeWidth="0.35" strokeDasharray="1.2 1.6" className="animate-dash" opacity="0.55" /></svg>
        </div>
      </div>
    </section>
  );
}

