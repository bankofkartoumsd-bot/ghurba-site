import { useState } from 'react';
import { Armchair, ChevronLeft, ChevronRight, Check, BusFront, Sparkles } from 'lucide-react';
import { SectionHead } from '../components/ui';
import { FLEET } from '../lib/data';

export default function Fleet() {
  const [active, setActive] = useState(0);
  const bus = FLEET[active];
  const prev = () => setActive(a => (a - 1 + FLEET.length) % FLEET.length);
  const next = () => setActive(a => (a + 1) % FLEET.length);

  return (
    <section id="fleet" className="star-pattern-soft bg-[#fcfaf3] py-14 sm:py-18">
      <div className="mx-auto max-w-7xl px-4">
        <SectionHead kicker="الأسطول" title="أحدث بوصات في البلد" sub="كل بوص في الغربة يتفحص قبل كل رحلة بـ 40 نقطة أمان — من الفرامل للوسادات لمكيف الصحراء." />

        {/* البص النشط */}
        <div className="relative mt-9 overflow-hidden rounded-3xl bg-[#0c3b2e] shadow-[0_30px_70px_-25px_rgba(7,31,22,.6)] ring-1 ring-[#c9992e]/40">
          <div className="star-pattern absolute inset-0 opacity-70" aria-hidden="true" />
          <div className="relative grid lg:grid-cols-2">
            <div className="flex flex-col justify-center p-6 sm:p-9">
              {bus.featured && <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-[#e3b54a] px-3 py-1 text-[9.5px] font-black text-[#2b1d05]"><Sparkles size={12} /> نجم الأسطول</span>}
              <p className="mt-3 font-amiri text-4xl font-bold text-[#f4cd6f] sm:text-5xl">{bus.name}</p>
              <p className="mt-1 font-changa text-xs font-semibold uppercase tracking-[0.3em] text-[#cfe3d6]/80">{bus.nameEn}</p>
              <p className="mt-2 text-[12px] font-bold text-[#e9e4cd]/90">{bus.brand} • موديل {bus.year}</p>
              <p className="mt-3 max-w-md leading-7 text-[#e9e4cd]">{bus.tagline}</p>
              <ul className="mt-4 grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                {bus.onboard.map(f => (
                  <li key={f} className="flex items-center gap-1.5 text-[11px] font-semibold text-[#f7f1e3]"><Check size={13} className="shrink-0 text-[#e3b54a]" />{f}</li>
                ))}
              </ul>
              <div className="mt-5 flex items-center gap-3">
                <span className="flex items-center gap-2 rounded-2xl bg-[#071f16] px-4 py-2.5 ring-1 ring-[#e3b54a]/35">
                  <Armchair size={19} className="text-[#e3b54a]" />
                  <span><b className="font-changa text-lg text-[#f7f1e3]">{bus.seats}</b><span className="block text-[9px] text-[#cfe3d6]/75">مقعد مريح</span></span>
                </span>
                <span className="flex items-center gap-2 rounded-2xl bg-[#071f16] px-4 py-2.5 ring-1 ring-[#e3b54a]/35">
                  <BusFront size={19} className="text-[#e3b54a]" />
                  <span><b className="font-changa text-lg text-[#f7f1e3]">40</b><span className="block text-[9px] text-[#cfe3d6]/75">نقطة فحص أمان</span></span>
                </span>
              </div>
            </div>
            <div className="relative flex items-center justify-center border-t border-[#e3b54a]/20 p-6 lg:border-s lg:border-t-0">
              <img key={bus.id} src="/images/fleet-bus.png" alt={`بص ${bus.name} — ${bus.brand}`}
                className="w-full max-w-lg object-contain drop-shadow-[0_30px_35px_rgba(0,0,0,.55)] animate-[busIn_.5s_ease]" />
              <style>{`@keyframes busIn{from{opacity:0;transform:translateX(-60px)}to{opacity:1;transform:none}}`}</style>
              {/* أزرار التنقل */}
              <button onClick={next} aria-label="البص السابق" className="absolute start-3 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-[#f7f1e3]/10 text-[#f7f1e3] ring-1 ring-[#e3b54a]/40 backdrop-blur transition hover:bg-[#e3b54a] hover:text-[#2b1d05]"><ChevronRight size={20} /></button>
              <button onClick={prev} aria-label="البص التالي" className="absolute end-3 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-[#f7f1e3]/10 text-[#f7f1e3] ring-1 ring-[#e3b54a]/40 backdrop-blur transition hover:bg-[#e3b54a] hover:text-[#2b1d05]"><ChevronLeft size={20} /></button>
            </div>
          </div>
        </div>

        {/* مؤشرات */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {FLEET.map((b, i) => (
            <button key={b.id} onClick={() => setActive(i)} aria-label={b.name} aria-pressed={i === active}
              className={`rounded-xl px-3.5 py-2 text-[11px] font-bold transition ring-1 ${i === active ? 'bg-[#0c3b2e] text-[#e3b54a] ring-[#0c3b2e] shadow' : 'bg-white text-[#0c3b2e] ring-[#0c3b2e]/20 hover:ring-[#c9992e]'}`}>
              {b.name}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
