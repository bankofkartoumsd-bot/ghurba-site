import { Printer, X } from 'lucide-react';
import type { Ticket } from '../lib/tickets';
import { BUS_CAPACITY, COMPANY_NAME } from '../lib/data';
import { routeName } from './utils';

export interface ManifestTrip { routeId: string; dateISO: string; time: string; busName: string; }

// قائمة ركاب قابلة للطباعة لرحلة واحدة: رقم التذكرة • الاسم • رقم الهاتف
export default function Manifest({ trip, passengers, onClose }: { trip: ManifestTrip; passengers: Ticket[]; onClose: () => void }) {
  const dateLong = new Date(trip.dateISO + 'T00:00:00').toLocaleDateString('ar-SD', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const pending = passengers.filter(p => p.status === 'قيد المراجعة').length;
  const full = passengers.length >= BUS_CAPACITY;

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center overflow-y-auto bg-[#04150e]/70 p-3 sm:p-6 print:static print:bg-transparent print:p-0">
      {/* الطباعة على A4 عمودي */}
      <style>{`@media print { @page { size: A4 portrait; margin: 12mm; } #manifest-print { padding: 0 !important; } }`}</style>
      <div className="w-full max-w-3xl print:max-w-none">
        <div className="mb-2 flex items-center justify-end gap-2 print:hidden">
          <button onClick={() => window.print()} className="inline-flex items-center gap-1.5 rounded-xl bg-[#e3b54a] px-4 py-2.5 text-sm font-black text-[#2b1d05] shadow hover:bg-[#f4cd6f]"><Printer size={16} /> طباعة القائمة</button>
          <button onClick={onClose} aria-label="إغلاق" className="rounded-xl bg-white/90 p-2.5 text-[#0c3b2e] hover:bg-white"><X size={18} /></button>
        </div>

        <div id="manifest-print" dir="rtl" className="rounded-2xl bg-white p-6 text-[#111] shadow-2xl">
          <div className="flex items-start justify-between gap-4 border-b-2 border-[#0c3b2e] pb-3">
            <div>
              <p className="font-display text-xl font-black text-[#0c3b2e]">شركة {COMPANY_NAME} للنقل</p>
              <p className="mt-0.5 text-sm font-bold">قائمة ركاب الرحلة</p>
            </div>
            <div className="text-end text-xs font-bold leading-6">
              <p>{routeName(trip.routeId)}</p>
              <p>{dateLong} — <span dir="ltr">{trip.time}</span></p>
              <p>{trip.busName}</p>
            </div>
          </div>

          <p className="mt-2 text-xs font-bold">
            عدد الركاب: <span dir="ltr">{passengers.length} / {BUS_CAPACITY}</span>{full ? ' — الرحلة مكتملة' : ''}
            {pending > 0 ? ` — منهم ${pending} قيد مراجعة الدفع` : ''}
          </p>

          <table className="mt-3 w-full border-collapse text-[12.5px]">
            <thead>
              <tr className="bg-[#0c3b2e]/10">
                {['م', 'المقعد', 'رقم التذكرة', 'الاسم', 'رقم الهاتف', 'صعود'].map(h => (
                  <th key={h} className="border border-[#0c3b2e]/40 px-2 py-1.5 text-start font-black">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {passengers.map((p, i) => (
                <tr key={p.code} className="break-inside-avoid">
                  <td className="border border-[#0c3b2e]/30 px-2 py-1.5">{i + 1}</td>
                  <td className="border border-[#0c3b2e]/30 px-2 py-1.5 font-bold">{p.seat}</td>
                  <td className="border border-[#0c3b2e]/30 px-2 py-1.5 font-mono" dir="ltr" style={{ textAlign: 'start' }}>{p.code}</td>
                  <td className="border border-[#0c3b2e]/30 px-2 py-1.5">{p.passengerName}{p.status === 'قيد المراجعة' ? ' *' : ''}</td>
                  <td className="border border-[#0c3b2e]/30 px-2 py-1.5 font-mono" dir="ltr" style={{ textAlign: 'start' }}>{p.passengerPhone}</td>
                  <td className="w-14 border border-[#0c3b2e]/30 px-2 py-1.5" />
                </tr>
              ))}
              {!passengers.length && <tr><td colSpan={6} className="border border-[#0c3b2e]/30 py-6 text-center">لا يوجد ركاب.</td></tr>}
            </tbody>
          </table>
          {pending > 0 && <p className="mt-2 text-[11px]">* الدفع قيد المراجعة ولم يُؤكد بعد.</p>}
          <p className="mt-4 text-[10px] text-[#555]">طُبعت في {new Date().toLocaleString('ar-SD')}</p>
        </div>
      </div>
    </div>
  );
}
