import { useCallback, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { LayoutDashboard, ListChecks, BusFront, BarChart3, LogOut, RefreshCw, ArrowRight, Lock } from 'lucide-react';
import { COMPANY_NAME } from '../lib/data';
import GhurbaLogo from '../components/GhurbaLogo';
import { supabase } from '../lib/supabase';
import { rowToTicket, RECEIPT_BUCKET, type TicketRow } from '../lib/remote';
import type { Ticket } from '../lib/tickets';
import { Overview, Bookings, Trips, Reports } from './panels';

type Tab = 'overview' | 'bookings' | 'trips' | 'reports';
const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'overview', label: 'نظرة عامة', icon: <LayoutDashboard size={16} /> },
  { id: 'bookings', label: 'الحجوزات', icon: <ListChecks size={16} /> },
  { id: 'trips', label: 'الرحلات', icon: <BusFront size={16} /> },
  { id: 'reports', label: 'التقارير', icon: <BarChart3 size={16} /> },
];

const inputCls = 'w-full rounded-xl border border-[#0c3b2e]/20 bg-white px-3.5 py-3 text-sm font-semibold text-[#22312a] focus:border-[#c9992e] focus:outline-none focus:ring-2 focus:ring-[#e3b54a]/40';

function Shell({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-[#f7f1e3] text-[#22312a]">{children}</div>;
}

function Login({ onDone }: { onDone: () => void }) {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.SyntheticEvent) => {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true); setErr('');
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pass });
    setBusy(false);
    if (error) setErr('البريد أو كلمة المرور غير صحيحة.'); else onDone();
  };

  return (
    <Shell>
      <div className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-4">
        <div className="mb-6 flex justify-center"><GhurbaLogo size={56} /></div>
        <form onSubmit={submit} className="space-y-3 rounded-3xl border border-[#0c3b2e]/12 bg-white p-6 shadow-lg">
          <h1 className="flex items-center gap-2 font-display text-xl font-black text-[#0c3b2e]"><Lock size={18} className="text-[#c9992e]" /> دخول الإدارة</h1>
          <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="البريد الإلكتروني" className={inputCls} dir="ltr" autoComplete="username" />
          <input type="password" required value={pass} onChange={e => setPass(e.target.value)} placeholder="كلمة المرور" className={inputCls} dir="ltr" autoComplete="current-password" />
          {err && <p className="text-xs font-bold text-rose-600">{err}</p>}
          <button disabled={busy} className="w-full rounded-xl bg-[#0c3b2e] py-3 font-display text-sm font-black text-[#f7f1e3] transition hover:bg-[#114e3c] disabled:opacity-60">{busy ? 'جارٍ الدخول…' : 'دخول'}</button>
          <a href="#/" className="block text-center text-xs font-bold text-[#6b5a2e] hover:text-[#c9992e]">العودة إلى الموقع</a>
        </form>
      </div>
    </Shell>
  );
}

export default function AdminApp() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [tab, setTab] = useState<Tab>('overview');
  const [preset, setPreset] = useState<{ status: 'all' | Ticket['status']; n: number }>({ status: 'all', n: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!supabase) { setSession(null); return; }
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!supabase || !session) { setIsAdmin(null); return; }
    supabase.rpc('ghurba_is_admin').then(({ data }) => setIsAdmin(data === true));
  }, [session]);

  const load = useCallback(async () => {
    if (!supabase) return;
    setLoading(true); setError('');
    const { data, error: e } = await supabase.from('ghurba_tickets').select('*').order('created_at', { ascending: false }).limit(5000);
    setLoading(false);
    if (e) { setError('تعذر تحميل الحجوزات.'); return; }
    setTickets((data as TicketRow[]).map(rowToTicket));
  }, []);

  useEffect(() => {
    if (!supabase || !isAdmin) return;
    void load();
    const ch = supabase.channel('ghurba-tickets')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'ghurba_tickets' }, () => { void load(); })
      .subscribe();
    return () => { void supabase?.removeChannel(ch); };
  }, [isAdmin, load]);

  const checkIn = async (t: Ticket, v: boolean) => {
    if (!supabase) return;
    await supabase.rpc('ghurba_set_checkin', { p_code: t.code, p_checked: v });
    void load();
  };
  const setStatus = async (t: Ticket, status: 'مؤكدة' | 'مرفوضة') => {
    if (!supabase) return;
    await supabase.from('ghurba_tickets').update({ status }).eq('code', t.code);
    void load();
  };
  // رابط مؤقت لصورة الإشعار (5 دقائق)
  const openReceipt = async (t: Ticket) => {
    if (!supabase || !t.receiptPath) return;
    const w = window.open('', '_blank');
    const { data } = await supabase.storage.from(RECEIPT_BUCKET).createSignedUrl(t.receiptPath, 300);
    if (data?.signedUrl && w) w.location.href = data.signedUrl; else { w?.close(); setError('تعذر فتح الإشعار.'); }
  };
  const reviewPending = () => { setPreset(p => ({ status: 'قيد المراجعة', n: p.n + 1 })); setTab('bookings'); };
  const cancel = async (t: Ticket) => {
    if (!supabase) return;
    await supabase.from('ghurba_tickets').update({ status: 'ملغاة' }).eq('code', t.code);
    void load();
  };

  if (!supabase) {
    return <Shell><p className="p-10 text-center font-bold">لم يتم ضبط اتصال Supabase (VITE_SUPABASE_URL / VITE_SUPABASE_KEY).</p></Shell>;
  }
  if (session === undefined) return <Shell><p className="p-10 text-center font-bold text-[#6b5a2e]">جارٍ التحميل…</p></Shell>;
  if (!session) return <Login onDone={() => undefined} />;
  if (isAdmin === false) {
    return (
      <Shell>
        <div className="mx-auto max-w-sm p-10 text-center">
          <p className="font-display text-lg font-black text-[#0c3b2e]">هذا الحساب ليس مشرفاً</p>
          <p className="mt-2 text-sm font-semibold text-[#6b5a2e]">اطلب من مسؤول النظام إضافة حسابك إلى قائمة المشرفين.</p>
          <button onClick={() => supabase?.auth.signOut()} className="mt-4 rounded-xl bg-[#0c3b2e] px-5 py-2.5 text-sm font-black text-[#f7f1e3]">تسجيل الخروج</button>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <header className="sticky top-0 z-30 border-b border-[#0c3b2e]/10 bg-[#f7f1e3]/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-2.5">
          <div className="flex items-center gap-3"><GhurbaLogo size={40} /><span className="hidden font-display text-sm font-black text-[#0c3b2e] sm:inline">لوحة الإدارة — {COMPANY_NAME}</span></div>
          <div className="flex items-center gap-1.5">
            <button onClick={() => void load()} title="تحديث" className="rounded-xl p-2.5 text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 hover:bg-[#0c3b2e]/5"><RefreshCw size={16} className={loading ? 'animate-spin' : ''} /></button>
            <a href="#/" className="inline-flex items-center gap-1.5 rounded-xl px-3 py-2.5 text-xs font-black text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 hover:bg-[#0c3b2e]/5"><ArrowRight size={14} /> الموقع</a>
            <button onClick={() => supabase?.auth.signOut()} className="inline-flex items-center gap-1.5 rounded-xl bg-[#0c3b2e] px-3 py-2.5 text-xs font-black text-[#f7f1e3] hover:bg-[#114e3c]"><LogOut size={14} /> خروج</button>
          </div>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 pb-2">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`inline-flex shrink-0 items-center gap-1.5 rounded-xl px-4 py-2 text-[13px] font-black transition ${tab === t.id ? 'bg-[#0c3b2e] text-[#e3b54a]' : 'text-[#0c3b2e] hover:bg-[#0c3b2e]/8'}`}>
              {t.icon} {t.label}
              {t.id === 'bookings' && tickets.some(x => x.status === 'قيد المراجعة') && <span className="h-2 w-2 rounded-full bg-amber-500" />}
            </button>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-5">
        {error && <p className="mb-3 rounded-xl bg-rose-50 px-4 py-2 text-sm font-bold text-rose-700">{error}</p>}
        {tab === 'overview' && <Overview tickets={tickets} onReview={reviewPending} onFull={() => setTab('trips')} />}
        {tab === 'bookings' && <Bookings key={preset.n} tickets={tickets} initialStatus={preset.status} onCheckIn={checkIn} onCancel={cancel} onSetStatus={setStatus} onReceipt={openReceipt} />}
        {tab === 'trips' && <Trips tickets={tickets} />}
        {tab === 'reports' && <Reports tickets={tickets} />}
      </main>
    </Shell>
  );
}
