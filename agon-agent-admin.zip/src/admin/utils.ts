import type { Ticket } from '../lib/tickets';
import { BUS_CAPACITY, PAY_METHODS, routeById, cityById } from '../lib/data';

// إيراد/تقارير: المؤكدة والمستخدمة فقط — المقعد محجوز أيضاً أثناء المراجعة
export const isLive = (t: Ticket) => t.status === 'مؤكدة' || t.status === 'مستخدمة';
export const isHeld = (t: Ticket) => isLive(t) || t.status === 'قيد المراجعة';
export const sdg = (list: Ticket[]) => list.filter(t => isLive(t) && !t.intl).reduce((a, t) => a + t.amount, 0);
export const usdSum = (list: Ticket[]) => list.filter(t => isLive(t) && t.intl).reduce((a, t) => a + t.amount, 0);
export const n = (x: number) => Math.round(x).toLocaleString('en-US');
export const todayISO = () => new Date().toISOString().slice(0, 10);
export const dayKey = (ms: number) => new Date(ms).toISOString().slice(0, 10);
export const routeLabel = (t: Ticket) => `${t.fromName} ← ${t.toName}`;
export const payName = (id: string) => PAY_METHODS.find(p => p.id === id)?.nameAr ?? id;
export const busSeats = () => BUS_CAPACITY;
export const tripKey = (t: Ticket) => `${t.routeId}|${t.dateISO}|${t.time}|${t.busId}`;
// ركاب رحلة واحدة (محجوزون أو قيد المراجعة) مرتبون بالمقعد
export const tripPassengers = (all: Ticket[], key: string) =>
  all.filter(t => isHeld(t) && tripKey(t) === key).sort((a, b) => a.seat - b.seat);
export const fullTripKeys = (all: Ticket[], fromDate: string) => {
  const m = new Map<string, number>();
  for (const t of all.filter(isHeld)) if (t.dateISO >= fromDate) m.set(tripKey(t), (m.get(tripKey(t)) ?? 0) + 1);
  return [...m.entries()].filter(([, c]) => c >= BUS_CAPACITY).map(([k]) => k);
};
export const routeName = (id: string) => {
  const r = routeById(id);
  return r ? `${cityById(r.from)?.name ?? r.from} ← ${cityById(r.to)?.name ?? r.to}` : id;
};
export const money = (t: Ticket) => (t.intl ? `${n(t.amount)} $` : `${n(t.amount)} ج.س`);

export function groupSum<T>(list: Ticket[], key: (t: Ticket) => string, label: (k: string) => string) {
  const m = new Map<string, { label: string; count: number; sdg: number; usd: number }>();
  for (const t of list.filter(isLive)) {
    const k = key(t);
    const e = m.get(k) ?? { label: label(k), count: 0, sdg: 0, usd: 0 };
    e.count++; if (t.intl) e.usd += t.amount; else e.sdg += t.amount;
    m.set(k, e);
  }
  return [...m.values()].sort((a, b) => b.sdg - a.sdg || b.usd - a.usd || b.count - a.count);
}

export function downloadCSV(name: string, rows: (string | number)[][]) {
  const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
  const csv = '\uFEFF' + rows.map(r => r.map(esc).join(',')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}
