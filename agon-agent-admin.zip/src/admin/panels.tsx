import { useMemo, useState } from 'react';
import { Search, Download, CheckCircle2, XCircle, Undo2, Users, Banknote, CalendarCheck, Ban, FileImage, BadgeCheck, Hourglass, Printer } from 'lucide-react';
import type { Ticket } from '../lib/tickets';
import Manifest, { type ManifestTrip } from './Manifest';
import { BUS_CAPACITY } from '../lib/data';
import {
  isLive, isHeld, tripKey, tripPassengers, fullTripKeys, sdg, usdSum, n, todayISO, dayKey, routeLabel, payName, busSeats, routeName, money, groupSum, downloadCSV,
} from './utils';

const card = 'rounded-2xl border border-[#0c3b2e]/12 bg-white p-4 shadow-sm';
const th = 'px-3 py-2.5 text-start text-[11px] font-black text-[#6b5a2e] whitespace-nowrap';
const td = 'px-3 py-2.5 text-[12.5px] font-semibold text-[#22312a] whitespace-nowrap';
const input = 'rounded-xl border border-[#0c3b2e]/20 bg-white px-3 py-2 text-sm font-semibold focus:border-[#c9992e] focus:outline-none focus:ring-2 focus:ring-[#e3b54a]/40';

const STATUS_CLS: Record<Ticket['status'], string> = {
  'مؤكدة': 'bg-emerald-100 text-emerald-800',
  'مستخدمة': 'bg-sky-100 text-sky-800',
  'ملغاة': 'bg-rose-100 text-rose-700',
  'قيد المراجعة': 'bg-amber-100 text-amber-800',
  'مرفوضة': 'bg-rose-100 text-rose-700',
};
const Badge = ({ s }: { s: Ticket['status'] }) => (
  <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-black ${STATUS_CLS[s]}`}>{s}</span>
);

function Kpi({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return (
    <div className={card}>
      <div className="flex items-center gap-2 text-[#6b5a2e]"><span className="text-[#c9992e]">{icon}</span><span className="text-xs font-bold">{label}</span></div>
      <div className="mt-2 font-display text-2xl font-black text-[#0c3b2e]" dir="ltr" style={{ textAlign: 'start' }}>{value}</div>
      {sub && <div className="mt-0.5 text-[11px] font-semibold text-[#6b5a2e]">{sub}</div>}
    </div>
  );
}

function Bars({ rows, unit }: { rows: { label: string; value: number; extra?: string }[]; unit: string }) {
  const max = Math.max(1, ...rows.map(r => r.value));
  if (!rows.length) return <p className="py-6 text-center text-sm font-semibold text-[#6b5a2e]">لا توجد بيانات بعد.</p>;
  return (
    <ul className="space-y-2">
      {rows.map(r => (
        <li key={r.label}>
          <div className="flex items-center justify-between gap-2 text-xs font-bold text-[#22312a]">
            <span className="truncate">{r.label}</span>
            <span dir="ltr" className="shrink-0 text-[#0c3b2e]">{n(r.value)} {unit}{r.extra ? ` · ${r.extra}` : ''}</span>
          </div>
          <div className="mt-1 h-2 rounded-full bg-[#0c3b2e]/8">
            <div className="h-2 rounded-full bg-gradient-to-l from-[#e3b54a] to-[#c9992e]" style={{ width: `${(r.value / max) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

/* ───────── نظرة عامة ───────── */
export function Overview({ tickets, onReview, onFull }: { tickets: Ticket[]; onReview: () => void; onFull: () => void }) {
  const today = todayISO();
  const todays = tickets.filter(t => dayKey(t.createdAt) === today);
  const upcoming = tickets.filter(t => t.status === 'مؤكدة' && t.dateISO >= today).length;
  const pending = tickets.filter(t => t.status === 'قيد المراجعة').length;
  const fullCount = fullTripKeys(tickets, today).length;
  const days = useMemo(() => {
    const out: { label: string; value: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const k = dayKey(Date.now() - i * 86400000);
      out.push({ label: k.slice(5), value: tickets.filter(t => isLive(t) && !t.intl && dayKey(t.createdAt) === k).reduce((a, t) => a + t.amount, 0) });
    }
    return out;
  }, [tickets]);
  const max = Math.max(1, ...days.map(d => d.value));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi icon={<Users size={16} />} label="حجوزات اليوم" value={n(todays.filter(isHeld).length)} sub={`الإجمالي ${n(tickets.filter(isHeld).length)}`} />
        <Kpi icon={<Banknote size={16} />} label="إيرادات اليوم" value={`${n(sdg(todays))} ج.س`} sub={`${n(usdSum(todays))} $ دولي`} />
        <Kpi icon={<CalendarCheck size={16} />} label="رحلات قادمة (مؤكدة)" value={n(upcoming)} sub={`صعدوا فعلاً ${n(tickets.filter(t => t.checkedIn).length)}`} />
        <Kpi icon={<Hourglass size={16} />} label="بانتظار مراجعة الإشعار" value={n(pending)} sub={pending ? 'اضغط للمراجعة الآن' : 'لا توجد طلبات معلّقة'} />
      </div>
      {fullCount > 0 && (
        <button onClick={onFull} className="flex w-full items-center justify-between gap-3 rounded-2xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-start text-sm font-black text-emerald-900 hover:bg-emerald-100">
          <span className="flex items-center gap-2"><Printer size={16} /> {n(fullCount)} رحلة اكتملت ({BUS_CAPACITY} مقعداً)</span><span className="text-xs">اطبع قائمة الركاب ←</span>
        </button>
      )}
      {pending > 0 && (
        <button onClick={onReview} className="flex w-full items-center justify-between gap-3 rounded-2xl border border-amber-300 bg-amber-50 px-4 py-3 text-start text-sm font-black text-amber-900 hover:bg-amber-100">
          <span className="flex items-center gap-2"><Hourglass size={16} /> {n(pending)} حجز بانتظار تأكيد الدفع</span><span className="text-xs">راجع الإشعارات ←</span>
        </button>
      )}

      <div className={card}>
        <h3 className="font-display text-sm font-black text-[#0c3b2e]">إيرادات آخر 14 يوم (بالجنيه السوداني)</h3>
        <div className="mt-3 flex h-40 items-end gap-1.5" dir="ltr">
          {days.map(d => (
            <div key={d.label} className="flex flex-1 flex-col items-center justify-end gap-1" title={`${d.label}: ${n(d.value)}`}>
              <div className="w-full rounded-t-md bg-gradient-to-t from-[#0c3b2e] to-[#1a6b52]" style={{ height: `${Math.max(3, (d.value / max) * 100)}%` }} />
              <span className="text-[9px] font-bold text-[#6b5a2e]">{d.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className={card}>
        <h3 className="mb-2 font-display text-sm font-black text-[#0c3b2e]">آخر الحجوزات</h3>
        <div className="overflow-x-auto">
          <table className="w-full"><tbody className="divide-y divide-[#0c3b2e]/8">
            {tickets.slice(0, 8).map(t => (
              <tr key={t.code}>
                <td className={td} dir="ltr">{t.code}</td><td className={td}>{t.passengerName}</td>
                <td className={td}>{routeLabel(t)}</td><td className={td}>{money(t)}</td><td className={td}><Badge s={t.status} /></td>
              </tr>
            ))}
            {!tickets.length && <tr><td className="py-6 text-center text-sm font-semibold text-[#6b5a2e]">لا توجد حجوزات بعد.</td></tr>}
          </tbody></table>
        </div>
      </div>
    </div>
  );
}

/* ───────── الحجوزات ───────── */
export function Bookings({ tickets, initialStatus = 'all', onCheckIn, onCancel, onSetStatus, onReceipt }: {
  tickets: Ticket[]; initialStatus?: 'all' | Ticket['status'];
  onCheckIn: (t: Ticket, v: boolean) => void; onCancel: (t: Ticket) => void;
  onSetStatus: (t: Ticket, s: 'مؤكدة' | 'مرفوضة') => void; onReceipt: (t: Ticket) => void;
}) {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState<'all' | Ticket['status']>(initialStatus);
  const [date, setDate] = useState('');
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return tickets.filter(t =>
      (status === 'all' || t.status === status) && (!date || t.dateISO === date) &&
      (!s || [t.code, t.passengerName, t.passengerPhone, t.passengerNationalId].some(v => v.toLowerCase().includes(s))));
  }, [tickets, q, status, date]);

  const exportCsv = () => downloadCSV(`ghurba-bookings-${todayISO()}.csv`, [
    ['الكود', 'الراكب', 'الهاتف', 'الهوية', 'الخط', 'تاريخ الرحلة', 'الوقت', 'البص', 'المقعد', 'المبلغ', 'العملة', 'الدفع', 'رقم العملية', 'إشعار', 'الحالة', 'تاريخ الحجز'],
    ...list.map(t => [t.code, t.passengerName, t.passengerPhone, t.passengerNationalId, routeLabel(t), t.dateISO, t.time, t.busName, t.seat, t.amount, t.intl ? 'USD' : 'SDG', payName(t.paidWith), t.payRef ?? '', t.hasReceipt ? 'نعم' : 'لا', t.status, new Date(t.createdAt).toISOString()]),
  ]);

  return (
    <div className={card}>
      <div className="flex flex-wrap items-center gap-2">
        <label className="relative min-w-[200px] flex-1">
          <Search size={15} className="pointer-events-none absolute top-1/2 -translate-y-1/2 start-3 text-[#6b5a2e]" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="ابحث بالكود أو الاسم أو الهاتف…" className={`${input} w-full ps-9`} />
        </label>
        <select value={status} onChange={e => setStatus(e.target.value as typeof status)} className={input}>
          <option value="all">كل الحالات</option><option value="قيد المراجعة">قيد المراجعة</option><option value="مؤكدة">مؤكدة</option><option value="مستخدمة">مستخدمة</option><option value="مرفوضة">مرفوضة</option><option value="ملغاة">ملغاة</option>
        </select>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} className={input} aria-label="تاريخ الرحلة" />
        <button onClick={exportCsv} className="inline-flex items-center gap-1.5 rounded-xl bg-[#0c3b2e] px-3.5 py-2 text-xs font-black text-[#f7f1e3] hover:bg-[#114e3c]"><Download size={14} /> تصدير CSV</button>
      </div>
      <p className="mt-2 text-[11px] font-bold text-[#6b5a2e]">{n(list.length)} حجز</p>
      <div className="mt-2 overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-[#0c3b2e]/10"><tr>
            {['الكود', 'الراكب', 'الهاتف', 'الخط', 'الرحلة', 'مقعد', 'المبلغ', 'الدفع', 'الحالة', ''].map(h => <th key={h} className={th}>{h}</th>)}
          </tr></thead>
          <tbody className="divide-y divide-[#0c3b2e]/8">
            {list.map(t => (
              <tr key={t.code} className="hover:bg-[#f7f1e3]/60">
                <td className={td} dir="ltr">{t.code}</td><td className={td}>{t.passengerName}</td>
                <td className={td} dir="ltr">{t.passengerPhone}</td><td className={td}>{routeLabel(t)}</td>
                <td className={td} dir="ltr">{t.dateISO} {t.time}</td><td className={td}>{t.seat}</td>
                <td className={td}>{money(t)}</td><td className={td}>{payName(t.paidWith)}{t.payRef && <span className="block text-[10px] text-[#6b5a2e]" dir="ltr">#{t.payRef}</span>}</td>
                <td className={td}><Badge s={t.status} /></td>
                <td className={td}>
                  <div className="flex items-center gap-1">
                    {t.hasReceipt && <button onClick={() => onReceipt(t)} title="عرض إشعار الدفع" className="rounded-lg p-1.5 text-[#8a6a12] hover:bg-[#e3b54a]/20"><FileImage size={17} /></button>}
                    {t.status === 'قيد المراجعة' && <button onClick={() => onSetStatus(t, 'مؤكدة')} title="تأكيد الدفع" className="rounded-lg p-1.5 text-emerald-700 hover:bg-emerald-50"><BadgeCheck size={17} /></button>}
                    {t.status === 'قيد المراجعة' && <button onClick={() => { if (confirm(`رفض الحجز ${t.code}؟ سيتحرر المقعد.`)) onSetStatus(t, 'مرفوضة'); }} title="رفض" className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50"><Ban size={17} /></button>}
                    {t.status === 'مؤكدة' && <button onClick={() => onCheckIn(t, true)} title="تسجيل صعود" className="rounded-lg p-1.5 text-emerald-700 hover:bg-emerald-50"><CheckCircle2 size={17} /></button>}
                    {t.status === 'مستخدمة' && <button onClick={() => onCheckIn(t, false)} title="تراجع عن الصعود" className="rounded-lg p-1.5 text-sky-700 hover:bg-sky-50"><Undo2 size={17} /></button>}
                    {(t.status === 'مؤكدة' || t.status === 'مستخدمة') && <button onClick={() => { if (confirm(`إلغاء التذكرة ${t.code}؟`)) onCancel(t); }} title="إلغاء" className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50"><XCircle size={17} /></button>}
                  </div>
                </td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan={10} className="py-8 text-center text-sm font-semibold text-[#6b5a2e]">لا توجد نتائج.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ───────── الرحلات ───────── */
export function Trips({ tickets }: { tickets: Ticket[] }) {
  const [scope, setScope] = useState<'upcoming' | 'past' | 'all'>('upcoming');
  const [open, setOpen] = useState<{ trip: ManifestTrip; key: string } | null>(null);
  const today = todayISO();
  const trips = useMemo(() => {
    const m = new Map<string, { key: string; routeId: string; dateISO: string; time: string; busId: string; busName: string; booked: number; boarded: number; sdg: number; usd: number }>();
    for (const t of tickets.filter(isHeld)) {
      const k = `${t.routeId}|${t.dateISO}|${t.time}|${t.busId}`;
      const e = m.get(k) ?? { key: tripKey(t), routeId: t.routeId, dateISO: t.dateISO, time: t.time, busId: t.busId, busName: t.busName, booked: 0, boarded: 0, sdg: 0, usd: 0 };
      e.booked++; if (t.checkedIn) e.boarded++;
      if (t.intl) e.usd += t.amount; else e.sdg += t.amount;
      m.set(k, e);
    }
    return [...m.values()]
      .filter(x => scope === 'all' || (scope === 'upcoming' ? x.dateISO >= today : x.dateISO < today))
      .sort((a, b) => (scope === 'past' ? -1 : 1) * `${a.dateISO}${a.time}`.localeCompare(`${b.dateISO}${b.time}`));
  }, [tickets, scope, today]);

  return (
    <div className={card}>
      <div className="flex items-center gap-2">
        {([['upcoming', 'القادمة'], ['past', 'السابقة'], ['all', 'الكل']] as const).map(([v, l]) => (
          <button key={v} onClick={() => setScope(v)} className={`rounded-xl px-3.5 py-1.5 text-xs font-black transition ${scope === v ? 'bg-[#0c3b2e] text-[#e3b54a]' : 'text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 hover:bg-[#0c3b2e]/5'}`}>{l}</button>
        ))}
        <span className="ms-auto text-[11px] font-bold text-[#6b5a2e]">{n(trips.length)} رحلة</span>
      </div>
      <div className="mt-3 overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-[#0c3b2e]/10"><tr>{['الخط', 'التاريخ', 'الوقت', 'البص', 'الإشغال', 'صعدوا', 'الإيراد', 'القائمة'].map(h => <th key={h} className={th}>{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-[#0c3b2e]/8">
            {trips.map(x => {
              const cap = busSeats(), pct = Math.min(100, Math.round((x.booked / cap) * 100));
              return (
                <tr key={`${x.routeId}${x.dateISO}${x.time}${x.busId}`} className="hover:bg-[#f7f1e3]/60">
                  <td className={td}>{routeName(x.routeId)}</td><td className={td} dir="ltr">{x.dateISO}</td><td className={td} dir="ltr">{x.time}</td><td className={td}>{x.busName}</td>
                  <td className={td}>
                    <div className="flex items-center gap-2"><div className="h-2 w-24 rounded-full bg-[#0c3b2e]/10"><div className={`h-2 rounded-full ${pct >= 90 ? 'bg-rose-500' : 'bg-[#c9992e]'}`} style={{ width: `${pct}%` }} /></div><span dir="ltr">{x.booked}/{cap}</span></div>
                  </td>
                  <td className={td}>{x.boarded}</td><td className={td} dir="ltr">{x.usd ? `${n(x.usd)} $` : `${n(x.sdg)} ج.س`}</td>
                  <td className={td}>
                    <button onClick={() => setOpen({ key: x.key, trip: { routeId: x.routeId, dateISO: x.dateISO, time: x.time, busName: x.busName } })}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-black transition ${x.booked >= cap ? 'bg-[#e3b54a] text-[#2b1d05] hover:bg-[#f4cd6f]' : 'text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 hover:bg-[#0c3b2e]/5'}`}>
                      <Printer size={13} /> {x.booked >= cap ? 'مكتملة — اطبع' : 'قائمة الركاب'}
                    </button>
                  </td>
                </tr>
              );
            })}
            {!trips.length && <tr><td colSpan={8} className="py-8 text-center text-sm font-semibold text-[#6b5a2e]">لا توجد رحلات في هذا النطاق.</td></tr>}
          </tbody>
        </table>
      </div>
      {open && <Manifest trip={open.trip} passengers={tripPassengers(tickets, open.key)} onClose={() => setOpen(null)} />}
    </div>
  );
}

/* ───────── التقارير ───────── */
type G = ReturnType<typeof groupSum>;
const localRows = (g: G) => g.filter(r => r.sdg > 0).slice(0, 8).map(r => ({ label: r.label, value: r.sdg, extra: `${r.count} تذكرة` }));
const intlRows = (g: G) => g.filter(r => r.usd > 0).slice(0, 8).map(r => ({ label: r.label, value: r.usd, extra: `${r.count} تذكرة` }));
function Split({ title, g }: { title: string; g: G }) {
  const intl = intlRows(g);
  return (
    <div className={card}>
      <h3 className="mb-3 font-display text-sm font-black text-[#0c3b2e]">{title}</h3>
      <Bars rows={localRows(g)} unit="ج.س" />
      {intl.length > 0 && (<>
        <h4 className="mb-2 mt-4 border-t border-[#0c3b2e]/10 pt-3 text-[11px] font-black text-[#6b5a2e]">الدولي (بالدولار)</h4>
        <Bars rows={intl} unit="$" />
      </>)}
    </div>
  );
}

export function Reports({ tickets }: { tickets: Ticket[] }) {
  const [days, setDays] = useState<7 | 30 | 90 | 0>(30);
  const list = useMemo(() => {
    const from = days ? Date.now() - days * 86400000 : 0;
    return tickets.filter(t => t.createdAt >= from);
  }, [tickets, days]);
  const live = list.filter(isLive);
  const byRoute = groupSum(list, t => t.routeId, routeName);
  const byPay = groupSum(list, t => t.paidWith, payName);
  const byBus = groupSum(list, t => t.busId, id => list.find(t => t.busId === id)?.busName ?? id);
  const exportCsv = () => downloadCSV(`ghurba-report-${todayISO()}.csv`, [
    ['القسم', 'البند', 'عدد التذاكر', 'إيراد ج.س', 'إيراد $'],
    ...byRoute.map(r => ['الخط', r.label, r.count, r.sdg, r.usd]),
    ...byPay.map(r => ['طريقة الدفع', r.label, r.count, r.sdg, r.usd]),
    ...byBus.map(r => ['البص', r.label, r.count, r.sdg, r.usd]),
  ]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {([[7, '7 أيام'], [30, '30 يوم'], [90, '90 يوم'], [0, 'الكل']] as const).map(([v, l]) => (
          <button key={v} onClick={() => setDays(v)} className={`rounded-xl px-3.5 py-1.5 text-xs font-black transition ${days === v ? 'bg-[#0c3b2e] text-[#e3b54a]' : 'text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 hover:bg-[#0c3b2e]/5'}`}>{l}</button>
        ))}
        <button onClick={exportCsv} className="ms-auto inline-flex items-center gap-1.5 rounded-xl bg-[#0c3b2e] px-3.5 py-2 text-xs font-black text-[#f7f1e3] hover:bg-[#114e3c]"><Download size={14} /> تصدير التقرير</button>
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi icon={<Users size={16} />} label="تذاكر سارية" value={n(live.length)} />
        <Kpi icon={<Banknote size={16} />} label="إيراد محلي" value={`${n(sdg(list))} ج.س`} />
        <Kpi icon={<Banknote size={16} />} label="إيراد دولي" value={`${n(usdSum(list))} $`} />
        <Kpi icon={<Ban size={16} />} label="نسبة الإلغاء" value={list.length ? `${Math.round((list.filter(t => t.status === 'ملغاة').length / list.length) * 100)}%` : '—'} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Split title="الإيراد حسب الخط" g={byRoute} />
        <Split title="حسب طريقة الدفع" g={byPay} />
        <Split title="حسب البص" g={byBus} />
      </div>
    </div>
  );
}
