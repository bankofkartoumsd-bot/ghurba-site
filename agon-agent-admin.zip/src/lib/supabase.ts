import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_KEY as string | undefined;

// إذا لم تُضبط المتغيرات يعمل الموقع محلياً كما كان (بدون مزامنة)
export const supabase = url && key ? createClient(url, key) : null;
