import {
  createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode,
} from 'react';
import {
  EMPTY_DRAFT, loadTickets, type BookingDraft, type Ticket, type ToastMsg,
} from './tickets';

type Step = 1 | 2 | 3 | 4;

interface Ctx {
  draft: BookingDraft;
  patchDraft: (p: Partial<BookingDraft>) => void;
  resetDraft: () => void;
  step: Step;
  setStep: (s: Step) => void;
  tickets: Ticket[];
  refreshTickets: () => void;
  toasts: ToastMsg[];
  toast: (title: string, desc: string | undefined, tone: ToastMsg['tone']) => void;
  dismissToast: (id: number) => void;
  modal: ReactNode | null;
  openModal: (node: ReactNode) => void;
  closeModal: () => void;
  bookingOpen: boolean;
  setBookingOpen: (v: boolean) => void;
}

const TicketCtx = createContext<Ctx | null>(null);
const DRAFT_KEY = 'ghurba-draft-v1';

export function TicketProvider({ children }: { children: ReactNode }) {
  const [draft, setDraft] = useState<BookingDraft>(() => {
    try {
      const raw = sessionStorage.getItem(DRAFT_KEY);
      return raw ? { ...EMPTY_DRAFT, ...JSON.parse(raw) } : EMPTY_DRAFT;
    } catch { return EMPTY_DRAFT; }
  });
  const [step, setStep] = useState<Step>(1);
  const [tickets, setTickets] = useState<Ticket[]>(() => loadTickets());
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const [modal, setModal] = useState<ReactNode | null>(null);
  const [bookingOpen, setBookingOpen] = useState(false);

  useEffect(() => {
    try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify(draft)); } catch { /* ignore */ }
  }, [draft]);

  // قفل تمرير الصفحة عند فتح أي مودال
  useEffect(() => {
    document.body.style.overflow = modal || bookingOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [modal, bookingOpen]);

  const patchDraft = useCallback((p: Partial<BookingDraft>) => {
    setDraft(d => ({ ...d, ...p }));
  }, []);
  const resetDraft = useCallback(() => {
    setDraft(EMPTY_DRAFT);
    setStep(1);
    try { sessionStorage.removeItem(DRAFT_KEY); } catch { /* ignore */ }
  }, []);

  const refreshTickets = useCallback(() => setTickets(loadTickets()), []);

  const toast = useCallback((title: string, desc: string | undefined, tone: ToastMsg['tone']) => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t.slice(-2), { id, title, desc, tone }]);
    window.setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 5200);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts(t => t.filter(x => x.id !== id)), []);

  const openModal = useCallback((node: ReactNode) => setModal(node), []);
  const closeModal = useCallback(() => setModal(null), []);

  const value = useMemo<Ctx>(() => ({
    draft, patchDraft, resetDraft, step, setStep,
    tickets, refreshTickets,
    toasts, toast, dismissToast,
    modal, openModal, closeModal,
    bookingOpen, setBookingOpen,
  }), [draft, patchDraft, resetDraft, step, tickets, refreshTickets, toasts, toast, dismissToast,
       modal, openModal, closeModal, bookingOpen]);

  return <TicketCtx.Provider value={value}>{children}</TicketCtx.Provider>;
}

export function useTickets() {
  const c = useContext(TicketCtx);
  if (!c) throw new Error('useTickets must be used inside <TicketProvider>');
  return c;
}

// حفظ/استرجاع تذاكر من التخزين عند تحميل أي مكوّن (تأكد من المزامنة بين التبويبات)
export function useTicketSync() {
  const { refreshTickets } = useTickets();
  useEffect(() => {
    const onStorage = (e: StorageEvent) => { if (e.key === 'ghurba-tickets-v1') refreshTickets(); };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, [refreshTickets]);
}

