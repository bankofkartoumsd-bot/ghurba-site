// نموذج التذكرة + التخزين المحلي + أدوات مشتركة
export interface Ticket {
  code: string;
  fromId: string; fromName: string;
  toId: string; toName: string;
  routeId: string;
  dateISO: string;
  time: string;
  busId: string; busName: string;
  seat: number;
  intl: boolean;
  amount: number;           // بالجنيه السوداني أو بالدولار حسب intl
  paidWith: string;         // معرّف طريقة الدفع
  passengerName: string;
  passengerPhone: string;
  passengerNationalId: string;
  tripType: 'oneway' | 'round';
  status: 'قيد المراجعة' | 'مؤكدة' | 'مستخدمة' | 'ملغاة' | 'مرفوضة';
  payRef?: string;          // رقم عملية التحويل (اختياري)
  receiptPath?: string;     // مسار صورة إشعار الدفع في التخزين (للمشرفين فقط)
  hasReceipt?: boolean;
  createdAt: number;
  checkedIn: boolean;
}

const KEY = 'ghurba-tickets-v1';

export function loadTickets(): Ticket[] {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Ticket[]) : [];
  } catch {
    return [];
  }
}
export function saveTickets(list: Ticket[]) {
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* private mode */ }
}

export function upsertTicket(t: Ticket): Ticket[] {
  const list = loadTickets();
  const i = list.findIndex(x => x.code === t.code);
  if (i >= 0) list[i] = t; else list.unshift(t);
  saveTickets(list);
  return list;
}
export function removeTicket(code: string): Ticket[] {
  const list = loadTickets().filter(t => t.code !== code);
  saveTickets(list);
  return list;
}
export function updateTicket(code: string, patch: Partial<Ticket>): Ticket[] {
  const list = loadTickets().map(t => (t.code === code ? { ...t, ...patch } : t));
  saveTickets(list);
  return list;
}
export function getTicket(code: string): Ticket | undefined {
  return loadTickets().find(t => t.code === code.toUpperCase());
}

// توليد كرت صعود رقمي — مثلاً GR-2026-X4K7A2
const ALPHABET = 'ACDEFGHJKLMNPQRTUVWXYZ23456789';
export function generateCode(): string {
  const y = new Date().getFullYear();
  let rand = '';
  const arr = new Uint8Array(6);
  crypto.getRandomValues(arr);
  for (let i = 0; i < 6; i++) rand += ALPHABET[arr[i] % ALPHABET.length];
  return `GR-${y}-${rand}`;
}

// حجز المقاعد المشغولة لكل رحلة (تشويش حتمي مبني على مفتاح الرحلة فلا تتغير الأرقام بين الزيارات)
export function occupiedSeats(tripKey: string, seatCount: number, ratio = 0.38): Set<number> {
  let h = 2166136261;
  for (let i = 0; i < tripKey.length; i++) {
    h ^= tripKey.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const rand = () => {
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h ^= h >>> 15;
    return (h >>> 0) / 4294967296;
  };
  const occ = new Set<number>();
  for (let s = 1; s <= seatCount; s++) if (rand() < ratio) occ.add(s);
  return occ;
}

export interface BookingDraft {
  fromId: string; fromName: string;
  toId: string; toName: string;
  routeId: string; minutes: number;
  dateISO: string; time: string;
  busId: string; busName: string; brand: string; seats: number;
  seat: number;
  intl: boolean; price: number;
  tripType: 'oneway' | 'round';
  promoCode: string; discount: number;
}
export const EMPTY_DRAFT: BookingDraft = {
  fromId: '', fromName: '', toId: '', toName: '', routeId: '', minutes: 0,
  dateISO: '', time: '', busId: '', busName: '', brand: '', seats: 45,
  seat: 0, intl: false, price: 0, tripType: 'oneway', promoCode: '', discount: 0,
};

export interface ToastMsg { id: number; title: string; desc?: string; tone: 'ok' | 'warn' | 'err' | 'info'; }
