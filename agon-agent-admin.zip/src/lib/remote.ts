// المزامنة مع Supabase — الزبون يحجز بدون حساب ويتتبع حجزه برقم هاتفه
import { supabase } from './supabase';
import type { BookingDraft, Ticket } from './tickets';

// offline = لا يوجد اتصال Supabase مضبوط (وضع تطوير محلي)
export type PushResult = 'ok' | 'conflict' | 'offline' | 'error';

export const RECEIPT_BUCKET = 'ghurba-receipts';
export const MAX_RECEIPT_BYTES = 5 * 1024 * 1024;
export const RECEIPT_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'application/pdf'];

export interface TicketRow {
  code: string; from_id: string; from_name: string; to_id: string; to_name: string;
  route_id: string; date_iso: string; dep_time: string; bus_id: string; bus_name: string;
  seat: number; intl: boolean; amount: number; paid_with: string;
  passenger_name: string; passenger_phone: string; passenger_national_id?: string;
  trip_type: 'oneway' | 'round'; status: Ticket['status']; checked_in: boolean; created_at: string;
  receipt_path?: string | null; pay_ref?: string | null; has_receipt?: boolean;
}

export const rowToTicket = (r: TicketRow): Ticket => ({
  code: r.code, fromId: r.from_id, fromName: r.from_name, toId: r.to_id, toName: r.to_name,
  routeId: r.route_id, dateISO: r.date_iso, time: r.dep_time, busId: r.bus_id, busName: r.bus_name,
  seat: r.seat, intl: r.intl, amount: Number(r.amount), paidWith: r.paid_with,
  passengerName: r.passenger_name, passengerPhone: r.passenger_phone,
  passengerNationalId: r.passenger_national_id ?? '', tripType: r.trip_type, status: r.status,
  createdAt: Date.parse(r.created_at), checkedIn: r.checked_in,
  payRef: r.pay_ref ?? undefined, receiptPath: r.receipt_path ?? undefined,
  hasReceipt: r.has_receipt ?? !!r.receipt_path,
});

// يرفع إشعار الدفع ثم يسجل الحجز «قيد المراجعة» حتى يؤكده المشرف
export async function pushTicket(t: Ticket, receipt?: File | null): Promise<PushResult> {
  if (!supabase) return 'offline';
  try {
    let receiptPath: string | null = null;
    if (receipt) {
      const ext = (receipt.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) || 'jpg';
      receiptPath = `${t.code}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from(RECEIPT_BUCKET).upload(receiptPath, receipt, { contentType: receipt.type });
      if (up.error) return 'error';
    }
    const { error } = await supabase.from('ghurba_tickets').insert({
      code: t.code, from_id: t.fromId, from_name: t.fromName, to_id: t.toId, to_name: t.toName,
      route_id: t.routeId, date_iso: t.dateISO, dep_time: t.time, bus_id: t.busId, bus_name: t.busName,
      seat: t.seat, intl: t.intl, amount: t.amount, paid_with: t.paidWith,
      passenger_name: t.passengerName, passenger_phone: t.passengerPhone,
      passenger_national_id: t.passengerNationalId, trip_type: t.tripType,
      status: 'قيد المراجعة', checked_in: false,
      receipt_path: receiptPath, pay_ref: t.payRef || null,
    });
    if (!error) return 'ok';
    return error.code === '23505' ? 'conflict' : 'error';
  } catch { return 'error'; }
}

// تتبع حجوزات الزبون برقم هاتفه (بدون الرقم الوطني)
export async function trackByPhone(phone: string): Promise<Ticket[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase.rpc('ghurba_track_by_phone', { p_phone: phone });
    return error ? [] : ((data as TicketRow[] | null) ?? []).map(rowToTicket);
  } catch { return []; }
}

export async function fetchTakenSeats(d: BookingDraft): Promise<number[]> {
  if (!supabase || !d.routeId || !d.dateISO) return [];
  try {
    const { data, error } = await supabase.rpc('ghurba_taken_seats', {
      p_route: d.routeId, p_date: d.dateISO, p_time: d.time, p_bus: d.busId,
    });
    return error ? [] : ((data as number[] | null) ?? []);
  } catch { return []; }
}

export async function cancelRemote(code: string): Promise<void> {
  if (!supabase) return;
  try { await supabase.rpc('ghurba_cancel_ticket', { p_code: code }); } catch { /* ignore */ }
}

// يعمل فقط إذا كان المشرف مسجّل الدخول في نفس المتصفح
export async function checkInRemote(code: string, checked: boolean): Promise<void> {
  if (!supabase) return;
  try { await supabase.rpc('ghurba_set_checkin', { p_code: code, p_checked: checked }); } catch { /* ignore */ }
}

// للماسح: يجلب أي تذكرة بالكود إذا كان المشرف مسجّلاً الدخول
export async function getTicketRemote(code: string): Promise<Ticket | undefined> {
  if (!supabase) return undefined;
  try {
    const { data } = await supabase.from('ghurba_tickets').select('*').eq('code', code).maybeSingle();
    return data ? rowToTicket(data as TicketRow) : undefined;
  } catch { return undefined; }
}
