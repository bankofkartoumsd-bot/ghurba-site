// ─────────────────────────────────────────────────────────────
//  بصات الغربة — البيانات المرجعية: المدن، الخطوط، الأسطول،
//  طرق الدفع، الباقات، السوشيال. أسعار الخطوط اليومية **بالجنيه السوداني**
//  وتُعرض بالدولار بسعر السوق الموازي (SDG_PER_USD)، والخطوط الدولية بالدولار.
// ─────────────────────────────────────────────────────────────

// شركة أبو يوسف للنقل — كل البصات 48 مقعداً
export const COMPANY_NAME = 'أبو يوسف';
export const BUS_CAPACITY = 48;

export const SDG_PER_USD = 2400;
export const fmt = (n: number) => Math.round(n).toLocaleString('en-US');
export const usd = (n: number) => Math.round(n).toLocaleString('en-US');

export interface City { id: string; name: string; nameEn: string; country: 'SD' | 'EG' | 'SA'; station: string; }

export const CITIES: City[] = [
  { id: 'khartoum', name: 'الخرطوم', nameEn: 'Khartoum', country: 'SD', station: 'موقف الغربة الرئيسي — الخرطوم بحري، تقاطع شارع المعونة' },
  { id: 'omdurman', name: 'أم درمان', nameEn: 'Omdurman', country: 'SD', station: 'موقف الموردة — أم درمان، أمام السوق الكبير' },
  { id: 'portsudan', name: 'بورتسودان', nameEn: 'Port Sudan', country: 'SD', station: 'محطة البحر الأحمر — بورتسودان، حي الشاحنات' },
  { id: 'kassala', name: 'كسلا', nameEn: 'Kassala', country: 'SD', station: 'موقف كسلا المركزي — أمام جبل توكر' },
  { id: 'damazin', name: 'الدمازين', nameEn: 'Damazin', country: 'SD', station: 'موقف الدمازين — سوق الدمازين الكبير، الكرمك' },
  { id: 'elgenina', name: 'الجنينة', nameEn: 'El Geneina', country: 'SD', station: 'موقف الجنينة المركزي — الجنينة، غرب دارفور' },
  { id: 'atbara', name: 'عطبرة', nameEn: 'Atbara', country: 'SD', station: 'موقف عطبرة — أمام محطة عطبرة (عقد البجا)' },
  { id: 'wadmadani', name: 'ود مدني', nameEn: 'Wad Madani', country: 'SD', station: 'موقف ود مدني — المحطة القديمة، مدني الكبرى' },
  { id: 'elqadarif', name: 'القضارف', nameEn: 'El Gedaref', country: 'SD', station: 'موقف القضارف — سوق أُم دافوق الكبير' },
  { id: 'kostti', name: 'كوستي', nameEn: 'Kosti', country: 'SD', station: 'موقف كوستي — نهر النيل الأبيض، الجزيرة أبا' },
  { id: 'elfashir', name: 'الفاشر', nameEn: 'El Fasher', country: 'SD', station: 'موقف الفاشر — السوق الكبير، شمال دارفور' },
  { id: 'portsudan-intl', name: 'بورتسودان (الشحن الدولي)', nameEn: 'Port Sudan Intl', country: 'SD', station: 'ميناء بورتسودان — محطة الحاويات والشحن الدولي' },
  { id: 'gedaref-intl', name: 'القضارف (المعبر الحدودي)', nameEn: 'Gedaref Border', country: 'SD', station: 'معبر القلابات الحدودي — القضارف / إثيوبيا' },
  { id: 'cairo', name: 'القاهرة', nameEn: 'Cairo', country: 'EG', station: 'موقف الغربة — القاهرة، موقف المنيب (الجيزة)' },
  { id: 'aswan', name: 'أسوان', nameEn: 'Aswan', country: 'EG', station: 'محطة أسوان — موقف الشلال' },
  { id: 'hurghada', name: 'الغردقة', nameEn: 'Hurghada', country: 'EG', station: 'موقف الغردقة الجديد — شارع الشريف' },
  { id: 'jeddah', name: 'جدة', nameEn: 'Jeddah', country: 'SA', station: 'جدة — محطة النقل الجماعي، حي النسيم' },
  { id: 'riyadh', name: 'الرياض', nameEn: 'Riyadh', country: 'SA', station: 'الرياض — موقف الرياض الدولي، حي السلي' },
];
export const cityById = (id: string) => CITIES.find(c => c.id === id);

export interface Route {
  id: string; from: string; to: string; minutes: number;
  priceSDG?: number; priceUSD?: number; intl?: boolean; stops: string[];
}

// المسافات التقريبية بالدقائق (طريق معبّد) — الأسعار استرشادية بالجنيه السوداني / دولار للدولي
export const ROUTES: Route[] = [
  { id: 'khartoum-omdurman', from: 'khartoum', to: 'omdurman', minutes: 35, priceSDG: 15_000, stops: ['جسر النيل الأبيض', 'سوق أم درمان'] },
  { id: 'khartoum-wadmadani', from: 'khartoum', to: 'wadmadani', minutes: 150, priceSDG: 55_000, stops: ['البطانة', 'المسيد', 'ود الحداد'] },
  { id: 'khartoum-atbara', from: 'khartoum', to: 'atbara', minutes: 210, priceSDG: 68_000, stops: ['شندي', 'عطبرة المحطة'] },
  { id: 'khartoum-portsudan', from: 'khartoum', to: 'portsudan', minutes: 540, priceSDG: 120_000, stops: ['شندي', 'عطبرة', 'نهر عطبرة', 'هيا', 'سواكن'] },
  { id: 'khartoum-kassala', from: 'khartoum', to: 'kassala', minutes: 300, priceSDG: 85_000, stops: ['ود مدني', 'القضارف', 'كركورة'] },
  { id: 'khartoum-damazin', from: 'khartoum', to: 'damazin', minutes: 420, priceSDG: 95_000, stops: ['سنار', 'سنجة', 'ربك'] },
  { id: 'khartoum-elgenina', from: 'khartoum', to: 'elgenina', minutes: 780, priceSDG: 180_000, stops: ['نيالا', 'الفاشر', 'زالنجي'] },
  { id: 'khartoum-kostti', from: 'khartoum', to: 'kostti', minutes: 270, priceSDG: 60_000, stops: ['ربك', 'كوستي المحطة'] },
  { id: 'khartoum-elqadarif', from: 'khartoum', to: 'elqadarif', minutes: 330, priceSDG: 72_000, stops: ['ود مدني', 'القضارف الكبرى'] },
  { id: 'khartoum-elfashir', from: 'khartoum', to: 'elfashir', minutes: 720, priceSDG: 165_000, stops: ['الفاشر الطريق', 'نيالا'] },
  { id: 'omdurman-atbara', from: 'omdurman', to: 'atbara', minutes: 240, priceSDG: 65_000, stops: ['شندي', 'عتبرة'] },
  { id: 'omdurman-wadmadani', from: 'omdurman', to: 'wadmadani', minutes: 165, priceSDG: 52_000, stops: ['البطانة', 'المسيد'] },
  { id: 'portsudan-kassala', from: 'portsudan', to: 'kassala', minutes: 330, priceSDG: 88_000, stops: ['كسلا الطريق', 'هيا'] },
  { id: 'atbara-portsudan', from: 'atbara', to: 'portsudan', minutes: 330, priceSDG: 78_000, stops: ['نهر عطبرة', 'هيا', 'سواكن'] },
  // دولي
  { id: 'khartoum-cairo', from: 'khartoum', to: 'cairo', minutes: 1560, priceUSD: 85, intl: true, stops: ['أسوان', 'الكسارات (وادي حلفا)', 'أبو سمبل'] },
  { id: 'khartoum-jeddah', from: 'khartoum', to: 'jeddah', minutes: 2880, priceUSD: 180, intl: true, stops: ['بورتسودان', 'جدة — المحطة الدولية'] },
  { id: 'khartoum-riyadh', from: 'khartoum', to: 'riyadh', minutes: 2640, priceUSD: 195, intl: true, stops: ['بورتسودان', 'جدة', 'الرياض المحطة'] },
  { id: 'portsudan-jeddah', from: 'portsudan', to: 'jeddah', minutes: 420, priceUSD: 65, intl: true, stops: ['جدة — الميناء'] },
  { id: 'cairo-khartoum', from: 'cairo', to: 'khartoum', minutes: 1560, priceUSD: 85, intl: true, stops: ['وادي حلفا', 'أبو سمبل', 'أسوان'] },
  { id: 'aswan-khartoum', from: 'aswan', to: 'khartoum', minutes: 1080, priceUSD: 55, intl: true, stops: ['وادي حلفا', 'أبو سمبل'] },
  { id: 'gedaref-intl-cairo', from: 'gedaref-intl', to: 'cairo', minutes: 1800, priceUSD: 95, intl: true, stops: ['القلابات', 'بورتسودان', 'أسوان'] },
];

export const routeById = (id: string) => ROUTES.find(r => r.id === id);
export const findRoute = (from: string, to: string) =>
  ROUTES.find(r => r.from === from && r.to === to) || ROUTES.find(r => r.from === to && r.to === from);

export const minutesLabel = (m: number) => {
  const h = Math.floor(m / 60), r = m % 60;
  if (h === 0) return `${r} دقيقة`;
  return `${h} ساعة${r ? ` و ${r} دقيقة` : ''}`;
};

export const DEPARTURE_TIMES = ['05:30', '07:00', '09:00', '11:00', '13:30', '15:00', '17:30', '20:00', '22:00'] as const;
export type DepartureTime = typeof DEPARTURE_TIMES[number];

// ───────────── الأسطول ─────────────
export interface FleetBus {
  id: string; name: string; nameEn: string; brand: string;
  seats: number; year: number; onboard: string[]; tagline: string; featured?: boolean;
}
export const FLEET: FleetBus[] = [
  {
    id: 'ghazal', name: 'الغزال الذهبي', nameEn: 'Golden Ghazal', brand: 'مرسيدس بنز ترافيكو فايبر',
    seats: 48, year: 2024, tagline: 'القمة في الراحة للخطوط الطويلة مع كراسي جلد إسفنجي ومساند أرجل.',
    onboard: ['Wi-Fi مجاني 5G', 'شاشة ترفيه شخصية 15.6"', 'مكيف بارد', 'شحن USB-C لكل مقعد', 'مقعد لوکس متكئ 160°', 'قهوة الغربة المجانية'],
    featured: true,
  },
  {
    id: 'nile', name: 'النيل الأزرق', nameEn: 'Blue Nile', brand: 'فولفو 9700 كوستر',
    seats: 48, year: 2023, tagline: 'أيقونة الخطوط الشمالية — هدوء تام وتعليق هوائي يناسب طريق الشمال.',
    onboard: ['Wi-Fi مجاني', 'شاشة رئيسية 42"', 'تعليق هوائي', 'شحن USB لكل مقعد', 'مكيف صحراوي', 'وجبة ضيافة'],
  },
  {
    id: 'sayl', name: 'السيل العارم', nameEn: 'Rushing Torrent', brand: 'مان Lion’s Coach L متدلية',
    seats: 48, year: 2024, tagline: 'للخطوط الدولية — مقاعد VIP من الجلد الطبيعي مع مكتبة وصالون.',
    onboard: ['كراسي جلد إيطالي 180°', 'واي فاي دولي', 'صالون ضيافة وقهوة', 'مقعدين متقابلين للعائلة', 'مكيف مركزي', 'مرافق ضيف'],
    featured: true,
  },
  {
    id: 'qadarif', name: 'القضارف الفائق', nameEn: 'Gedaref Super', brand: 'سكودو شيفروليه أوبترا',
    seats: 48, year: 2022, tagline: 'ميني باص مريح للخطوط المتوسطة — حل مثالي للمجموعات الصغيرة.',
    onboard: ['واي فاي', 'مكيف', 'شحن USB', 'شاشة ترفيه', 'حقائب أمتعة 3'],
  },
  {
    id: 'fater', name: 'الفاتح الذهبي', nameEn: 'Al-Fatih Gold', brand: 'كيا غرند ستاركس',
    seats: 48, year: 2025, tagline: 'أحدث طراز في الأسطول — التكنولوجيا الألمانية باللمسة السودانية.',
    onboard: ['شاشة لمس ذكية', 'بلوتوث لكل مقعد', 'مكيف إكسترم', 'شحن لاسلكي', 'إضاءة ليلية'],
  },
  {
    id: 'marra', name: 'جبل مرة', nameEn: 'Jebel Marra', brand: 'تويوتا كوستر 75',
    seats: 48, year: 2021, tagline: 'وحش الطرق الوعرة — مخصص لخطوط دارفور وكردفان مع أنظمة دفع رباعي.',
    onboard: ['دفع رباعي 4×4', 'واي فاي', 'مكيف', 'حقائب أمتعة 4', 'طقم نجاة متكامل'],
  },
];

// ───────────── طرق الدفع ─────────────
export interface PayMethod {
  id: string; name: string; nameAr: string; country: 'SD' | 'EG' | 'SA' | 'GLOBAL';
  desc: string; brandBg: string; text: string; group: 'Sudan' | 'Egypt' | 'KSA' | 'Intl';
}
export const PAY_METHODS: PayMethod[] = [
  // السودان
  { id: 'bankak', name: 'Bankak', nameAr: 'بنكك — بنك الخرطوم', country: 'SD', group: 'Sudan', desc: 'تحويل فوري عبر تطبيق بنكك (بنك الخرطوم) باستخدام رقم الهاتف أو رقم الحساب.', brandBg: '#1d4ed8', text: '#ffffff' },
  { id: 'my-cashi', name: 'MyCashi', nameAr: 'ماي كاشي', country: 'SD', group: 'Sudan', desc: 'دفع من محفظة ماي كاشي عبر رقم الهاتف — مناسب للتحويل الذاتي والمحافظ.', brandBg: '#059669', text: '#ffffff' },
  { id: 'fawry-sd', name: 'Fawry Sudan', nameAr: 'فوري السودان', country: 'SD', group: 'Sudan', desc: 'ادفع عبر فوري (سودان إلكترونية) — الرقم التنفيذي يُرسل برسالة قصيرة.', brandBg: '#dc2626', text: '#ffffff' },
  // مصر
  { id: 'meeza', name: 'Meeza', nameAr: 'ميزة — الدفع المصري الموحد', country: 'EG', group: 'Egypt', desc: 'بطاقة ميزة للخصم المباشر (بطاقة مصر الموحدة) تقبل الدفع أونلاين وPOS.', brandBg: '#0ea5e9', text: '#ffffff' },
  { id: 'vodafone-cash', name: 'Vodafone Cash', nameAr: 'فودافون كاش', country: 'EG', group: 'Egypt', desc: 'خصم فوري من محفظة فودافون كاش عبر رقم الهاتف + الرمز السري.', brandBg: '#e11d48', text: '#ffffff' },
  { id: 'instapay', name: 'InstaPay', nameAr: 'إنستاباي (PAY)', country: 'EG', group: 'Egypt', desc: 'تحويل لحظي عبر إنستاباي باستخدام عنوان الدفع (IPA) أو رقم الهاتف.', brandBg: '#7c3aed', text: '#ffffff' },
  { id: 'fawry-eg', name: 'Fawry Egypt', nameAr: 'فوري مصر', country: 'EG', group: 'Egypt', desc: 'ادفع عبر فوري مصر بإيصال المأمور أو عبر فوري أونلاين ببطاقة الدفع.', brandBg: '#ea580c', text: '#ffffff' },
  { id: 'vodafone-wallet-eg', name: 'Orange Cash', nameAr: 'أورنج كاش', country: 'EG', group: 'Egypt', desc: 'خصم من محفظة أورنج كاش للهواتف المصرية عبر رقم الهاتف.', brandBg: '#f97316', text: '#ffffff' },
  // السعودية
  { id: 'mada', name: 'mada', nameAr: 'مدى — الشبكة الوطنية السعودية', country: 'SA', group: 'KSA', desc: 'شبكة مدى للاتصال المباشر بالبنك المحلي السعودي (تقبل أونلاين وPOS).', brandBg: '#16a34a', text: '#ffffff' },
  { id: 'stc-pay', name: 'STC Pay', nameAr: 'إس تي سي باي', country: 'SA', group: 'KSA', desc: 'محفظة STC Pay عبر رقم الهاتف — دفع فوري من المحفظة أو البطاقة.', brandBg: '#7c3aed', text: '#ffffff' },
  { id: 'apple-pay', name: 'Apple Pay', nameAr: 'أبل باي', country: 'SA', group: 'KSA', desc: 'دفع لاتلامسي عبر أبل باي (مستخدمو آيفون) — رمز الأمان عبر Face ID.', brandBg: '#111827', text: '#ffffff' },
  // دولي
  { id: 'visa', name: 'Visa', nameAr: 'فيزا', country: 'GLOBAL', group: 'Intl', desc: 'بطاقات فيزا الائتمانية والخصم المباشر — حماية 3D Secure.', brandBg: '#1e3a8a', text: '#ffffff' },
  { id: 'mastercard', name: 'Mastercard', nameAr: 'ماستر كارد', country: 'GLOBAL', group: 'Intl', desc: 'بطاقات ماستر كارد الائتمانية والخصم المباشر — قبول عالمي.', brandBg: '#b91c1c', text: '#ffffff' },
];
export const PAY_GROUP_LABEL: Record<PayMethod['group'], string> = {
  Sudan: 'السودان', Egypt: 'مصر', KSA: 'السعودية', Intl: 'دولي',
};

export const ALL_PAY_IDS = PAY_METHODS.map(p => p.id);

// ───────────── باقات الغربة ─────────────
export interface Pass { id: string; name: string; nameEn: string; priceSDG: number; trips: number; validityDays: number; perks: string[]; popular?: boolean; }
export const PASSES: Pass[] = [
  { id: 'passport', name: 'باسبور الغربة', nameEn: 'Ghorba Passport', priceSDG: 250_000, trips: 5, validityDays: 30, perks: ['5 رحلات ذهاب خلال 30 يوم', 'أولوية الحجز في المواعيد المزدحمة', 'خصم 15% على الشحن', 'تذكرة رقمية مدى الحياة على التطبيق'] },
  { id: 'digital', name: 'باقة رقمي', nameEn: 'Digital Plus', priceSDG: 480_000, trips: 10, validityDays: 90, popular: true, perks: ['10 رحلات خلال 90 يوم', 'استرداد حتى 80% قبل 6 ساعات', 'حقيبة شحن مجانية (20kg)', 'واي فاي مجاني مدى الحياة', 'أولوية الصعود'] },
  { id: 'student', name: 'باقة الطالب', nameEn: 'Student Saver', priceSDG: 150_000, trips: 4, validityDays: 60, perks: ['4 رحلات خلال 60 يوم', 'ببطاقة طالب جامعية سارية', 'خصم 25% على الأمتعة الإضافية', 'مقعد خلفي هادئ للمذاكرة'] },
];

// ───────────── سوشيال ─────────────
export const SOCIALS = [
  { id: 'facebook', name: 'فيسبوك', handle: '@busatalghurba', url: 'https://www.facebook.com/busatalghurba', color: '#1877f2' },
  { id: 'instagram', name: 'إنستغرام', handle: '@busat_alghurba', url: 'https://www.instagram.com/busat_alghurba', color: '#e1306c' },
  { id: 'tiktok', name: 'تيك توك', handle: '@busatal_ghurba', url: 'https://www.tiktok.com/@busatal_ghurba', color: '#111111' },
  { id: 'youtube', name: 'يوتيوب', handle: '@BusatAlGhurbaOfficial', url: 'https://www.youtube.com/@BusatAlGhurbaOfficial', color: '#ff0000' },
  { id: 'whatsapp', name: 'واتساب', handle: '+249 91 000 0000', url: 'https://wa.me/249910000000', color: '#25d366' },
  { id: 'x', name: 'إكس (تويتر)', handle: '@busatalghurba', url: 'https://x.com/busatalghurba', color: '#000000' },
];

export const HELPLINE = '19988';
export const HOTLINE_INTL = '+249 91 000 0000';
export const WHATSAPP = 'https://wa.me/249910000000';

// ───────────── شاغرة جزئية (اتجاه واحد) ─────────────
export const SERVICE_FEE_SDG = 3_000;
