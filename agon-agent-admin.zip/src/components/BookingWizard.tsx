import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeftRight, CalendarDays, ChevronDown, Search, X, BusFront, Sofa, Armchair,
  CreditCard, Landmark, TicketPercent, BadgeCheck, Printer, MapPin, Route as RouteIcon,
  Users, PartyPopper, CheckCircle2, DoorOpen, CircleUserRound, Wifi, MonitorPlay, Snowflake, Coffee, BedDouble, Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  CITIES, DEPARTURE_TIMES, FLEET, PAY_METHODS, PAY_GROUP_LABEL, ROUTES, SERVICE_FEE_SDG,
  SDG_PER_USD, cityById, findRoute, fmt, minutesLabel, routeById,
} from '../lib/data';
import { EMPTY_DRAFT, generateCode, occupiedSeats, upsertTicket, type Ticket } from '../lib/tickets';
import { useTickets } from '../lib/TicketContext';
import { fetchTakenSeats, pushTicket, MAX_RECEIPT_BYTES, RECEIPT_TYPES } from '../lib/remote';
import { GoldButton, DarkButton } from './ui';
import TicketCard from './TicketCard';

const inputCls =
  'w-full rounded-xl border border-[#0c3b2e]/20 bg-white px-3.5 py-3 text-sm font-semibold text-[#22312a] placeholder-[#9aa89c] shadow-sm transition focus:border-[#c9992e] focus:ring-2 focus:ring-[#e3b54a]/40 focus:outline-none';

const PROMOS: Record<string, { rate: number; label: string }> = {
  GHORBA10: { rate: 0.10, label: 'خصم الغربة 10%' },
  WELCOME15: { rate: 0.15, label: 'خصم ترحيبي 15%' },
  STUDENT10: { rate: 0.10, label: 'خصم الطالب 10%' },
  GHORBA20: { rate: 0.20, label: 'خصم كبار الزبائن 20%' },
};

const tomorrowISO = () => { const d = new Date(Date.now() + 86400000); return d.toISOString().slice(0, 10); };

export default function BookingWizard({ onClose }: { onClose: () => void }) {
  const { draft, patchDraft, resetDraft, step, setStep, refreshTickets, toast } = useTickets();
  const [done, setDone] = useState<Ticket | null>(null);
  const [searching, setSearching] = useState(false);

  // حقول الخطوة 1
  const [tripType, setTripType] = useState<'oneway' | 'round'>(draft.tripType);
  const [fromId, setFromId] = useState(draft.fromId || 'khartoum');
  const [toId, setToId] = useState(draft.toId || 'portsudan');
  const [dateISO, setDateISO] = useState(draft.dateISO || tomorrowISO());
  const [time, setTime] = useState(draft.time || '09:00');

  // حقول الخطوة 4
  const [payId, setPayId] = useState('bankak');
  const [promo, setPromo] = useState('');
  const [promoApplied, setPromoApplied] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [doc, setDoc] = useState('');
  const [email, setEmail] = useState('');
  const [cardNum, setCardNum] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [paying, setPaying] = useState(false);
  const [receipt, setReceipt] = useState<File | null>(null);
  const [payRef, setPayRef] = useState('');

  const route = routeById(draft.routeId) ?? findRoute(fromId, toId);
  const intl = !!route?.intl;
  const basePrice = route ? (intl ? route.priceUSD! : route.priceSDG!) : 0;
  const subtotal = tripType === 'round' ? basePrice * 2 * 0.9 : basePrice;
  const discount = promoApplied ? subtotal * PROMOS[promoApplied].rate : 0;
  const fee = intl ? 3 : SERVICE_FEE_SDG;
  const total = Math.max(0, subtotal - discount) + fee;
  const ccy = intl ? '$' : 'ج.س';

  const dateLong = dateISO
    ? new Date(dateISO + 'T00:00:00').toLocaleDateString('ar-SD', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    : '';
  const minDate = new Date().toISOString().slice(0, 10);

  /* ── مزامنة الحقول عند فتح المودال أو تغير الوجهة من الصفحة ── */
  useEffect(() => {
    if (draft.fromId) setFromId(draft.fromId);
    if (draft.toId) setToId(draft.toId);
    if (draft.dateISO) setDateISO(draft.dateISO);
    if (draft.time) setTime(draft.time);
    if (draft.tripType) setTripType(draft.tripType);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draft.fromId, draft.toId, draft.dateISO, draft.time, draft.tripType]);

  useEscape(onClose);

  const swap = () => { setFromId(toId); setToId(fromId); };

  const runSearch = () => {
    if (fromId === toId) { toast('اختر مدينتي وصول ومغادرة مختلفتين', 'لا يمكن الحجز من المدينة إلى نفسها.', 'warn'); return; }
    const r = findRoute(fromId, toId);
    if (!r) { toast('لا يوجد خط مباشر حالياً', 'هذه الوجهة غير مشغّلة مباشرة — جرّب الخرطوم أو بورتسودان كمفترق.', 'err'); return; }
    setSearching(true);
    window.setTimeout(() => {
      setSearching(false);
      const fromC = cityById(fromId)!, toC = cityById(toId)!;
      patchDraft({
        ...EMPTY_DRAFT, tripType, fromId, toId, fromName: fromC.name, toName: toC.name,
        routeId: r.id, minutes: r.minutes, dateISO, time,
        intl: !!r.intl, price: 0, seat: 0, busId: '', busName: '', brand: '', seats: 45,
        promoCode: '', discount: 0,
      });
      setStep(2);
    }, 650);
  };

  const pickBus = (busId: string) => {
    const bus = FLEET.find(b => b.id === busId)!;
    patchDraft({ busId, busName: bus.name, brand: bus.brand, seats: bus.seats, seat: 0 });
    setStep(3);
  };

  const pickSeat = (s: number) => patchDraft({ seat: s });

  const paySummary = () => {
    patchDraft({ tripType, price: Math.round(total), promoCode: promoApplied ?? '', discount: Math.round(discount) });
    setStep(4);
  };

  const applyPromo = () => {
    const code = promo.trim().toUpperCase();
    if (!code) return;
    if (PROMOS[code]) { setPromoApplied(code); toast('تم تطبيق الكود', `${PROMOS[code].label} — شوف المجموع اتحدّث.`, 'ok'); }
    else toast('كود غير صالح', 'جرّب: GHORBA10 أو WELCOME15 أو STUDENT10', 'warn');
  };

  const needsReceipt = !['visa', 'mastercard', 'mada', 'apple-pay'].includes(payId);

  const submitPayment = () => {
    const e: Record<string, string> = {};
    if (name.trim().length < 3) e.name = 'اكتب الاسم الكامل كما في الهوية';
    if (!/^[+]?[0-9][0-9\s-]{7,15}$/.test(phone.trim())) e.phone = 'رقم هاتف غير صحيح (مثال: 0912345678)';
    if (doc.trim().length < 6) e.doc = intl ? 'رقم الجواز مطلوب للسفر الدولي' : 'الرقم الوطني / البطاقة مطلوب';
    if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(email)) e.email = 'صيغة البريد غير صحيحة';
    const isCard = ['visa', 'mastercard', 'mada', 'apple-pay'].includes(payId);
    if (isCard && ['visa', 'mastercard', 'mada'].includes(payId)) {
      if (cardNum.replace(/\s/g, '').length < 12) e.card = 'رقم البطاقة غير مكتمل';
      if (cardName.trim().length < 3) e.cardName = 'الاسم على البطاقة';
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry.trim())) e.expiry = 'الصيغة MM/YY';
      if (!/^\d{3,4}$/.test(cvv.trim())) e.cvv = 'رمز الأمان 3 أو 4 أرقام';
    }
    if (needsReceipt) {
      if (!receipt) e.receipt = 'ارفع صورة إشعار التحويل (لقطة شاشة من التطبيق)';
      else if (receipt.size > MAX_RECEIPT_BYTES) e.receipt = 'حجم الملف أكبر من 5 ميجا';
      else if (!RECEIPT_TYPES.includes(receipt.type)) e.receipt = 'الصيغة المسموحة: صورة أو PDF';
    }
    setErrors(e);
    if (Object.keys(e).length) { toast('راجع البيانات', 'بعض الحقول ناقصة أو غير صحيحة.', 'err'); return; }

    setPaying(true);
    window.setTimeout(async () => {
      const code = generateCode();
      const ticket: Ticket = {
        code,
        fromId: draft.fromId, fromName: draft.fromName,
        toId: draft.toId, toName: draft.toName,
        routeId: draft.routeId,
        dateISO: draft.dateISO, time: draft.time,
        busId: draft.busId, busName: draft.busName,
        seat: draft.seat, intl: draft.intl,
        amount: Math.round(total), paidWith: payId,
        passengerName: name.trim(), passengerPhone: phone.trim(),
        passengerNationalId: doc.trim(),
        tripType, status: 'قيد المراجعة', createdAt: Date.now(), checkedIn: false,
        payRef: payRef.trim() || undefined, hasReceipt: !!receipt,
      };
      const sync = await pushTicket(ticket, needsReceipt ? receipt : null);
      if (sync === 'conflict') {
        // سبقك أحد على هذا المقعد — نرجعه لاختيار مقعد آخر
        setPaying(false);
        patchDraft({ seat: 0 });
        setStep(3);
        toast('المقعد اتحجز قبل لحظات', 'اختار مقعد تاني وكمّل الحجز.', 'warn');
        return;
      }
      if (sync === 'error') {
        setPaying(false);
        toast('تعذر إرسال الحجز', 'تأكد من الاتصال بالإنترنت وحاول مرة تانية.', 'err');
        return;
      }
      upsertTicket(ticket);
      refreshTickets();
      setPaying(false);
      setDone(ticket);
      void email; // البريد يُحفظ محلياً عبر الملاحظات — التذكرة في المحفظة
      confetti({ particleCount: 130, spread: 75, origin: { y: 0.6 }, colors: ['#e3b54a', '#0c3b2e', '#f4cd6f', '#ffffff'] });
      window.setTimeout(() => confetti({ particleCount: 80, spread: 100, startVelocity: 32, origin: { x: 0.15, y: 0.7 }, colors: ['#e3b54a', '#0c3b2e', '#c9992e'] }), 350);
      toast('تم استلام حجزك!', `الكود ${code} — بنراجع الإشعار ونؤكد التذكرة قريباً.`, 'ok');
    }, 1400);
  };

  const closeAll = () => { resetDraft(); setDone(null); onClose(); };

  /* ══════════ شاشة النجاح ══════════ */
  if (done) {
    return (
      <WizardShell onClose={closeAll} step={4} title="تم استلام حجزك">
        <div className="px-4 sm:px-6 pb-6 pt-2 text-center">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 ring-4 ring-emerald-200">
            <PartyPopper size={30} className="text-emerald-700" />
          </span>
          <h3 className="mt-3 font-display text-2xl font-black text-[#0c3b2e]">استلمنا حجزك يا غالي!</h3>
          <p className="mt-1 text-sm leading-7 text-[#4c5a50]">حالة الحجز <b>«قيد المراجعة»</b> — بنراجع إشعار الدفع ونؤكد تذكرتك. تتبّع حالتها في <b>«محفظتي»</b> برقم هاتفك <b dir="ltr">{done.passengerPhone}</b>. احفظ الكود: <b dir="ltr">{done.code}</b></p>
          <div className="mt-4 text-start"><TicketCard ticket={done} printableId="ticket-print" /></div>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            <GoldButton onClick={() => window.print()} className="!px-5 !py-2.5 text-sm"><Printer size={16} /> طباعة الكرت</GoldButton>
            <DarkButton outline onClick={closeAll} className="!px-5 !py-2.5 text-sm !text-[#0c3b2e] !ring-[#0c3b2e]/30 hover:!bg-[#0c3b2e]/5">حجز رحلة أخرى</DarkButton>
          </div>
        </div>
      </WizardShell>
    );
  }

  /* ══════════ الخطوات ══════════ */
  return (
    <WizardShell onClose={closeAll} step={step} title="احجز تذكرتك">
      {/* ─────────── الخطوة 1: البحث ─────────── */}
      {step === 1 && (
        <div className="px-4 sm:px-6 pb-6">
          <div className="flex items-center justify-center gap-2 rounded-2xl bg-[#0c3b2e]/5 p-1.5 ring-1 ring-[#0c3b2e]/10">
            {([['oneway', 'اتجاه واحد'], ['round', 'ذهاب وعودة — 10% خصم']] as const).map(([v, label]) => (
              <button key={v} onClick={() => setTripType(v)}
                className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-bold transition ${tripType === v ? 'bg-[#0c3b2e] text-[#f7f1e3] shadow' : 'text-[#0c3b2e] hover:bg-[#0c3b2e]/5'}`}>
                {label}
              </button>
            ))}
          </div>

          <div className="relative mt-4 grid gap-3 sm:grid-cols-[1fr_auto_1fr] items-end">
            <Field label="من — محطة المغادرة">
              <CitySelect value={fromId} onChange={setFromId} icon="from" />
            </Field>
            <button onClick={swap} aria-label="عكس الاتجاه"
              className="mx-auto flex h-11 w-11 items-center justify-center rounded-full bg-[#e3b54a] text-[#2b1d05] shadow-md ring-1 ring-[#8a6a12] transition hover:rotate-180 duration-300">
              <ArrowLeftRight size={20} />
            </button>
            <Field label="إلى — محطة الوصول">
              <CitySelect value={toId} onChange={setToId} icon="to" />
            </Field>
          </div>

          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Field label="تاريخ السفر">
              <div className="relative">
                <CalendarDays size={16} className="pointer-events-none absolute start-3.5 top-1/2 -translate-y-1/2 text-[#8a6a12]" />
                <input type="date" min={minDate} value={dateISO} onChange={e => setDateISO(e.target.value)}
                  className={`${inputCls} ps-10`} aria-label="تاريخ السفر" />
              </div>
            </Field>
            <Field label="ميعاد الإقلاع">
              <div>
                <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="وقت الإقلاع">
                  {DEPARTURE_TIMES.map(t => (
                    <button key={t} role="radio" aria-checked={time === t} onClick={() => setTime(t)}
                      className={`rounded-lg px-2.5 py-1.5 font-mono text-[11px] font-bold ring-1 transition ${time === t ? 'bg-[#c9992e] text-[#2b1d05] ring-[#8a6a12] shadow' : 'bg-white text-[#0c3b2e] ring-[#0c3b2e]/20 hover:ring-[#c9992e]'}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </Field>
          </div>

          {/* لمحة عن الخط */}
          {findRoute(fromId, toId) && (() => {
            const r = findRoute(fromId, toId)!;
            const isIntl = !!r.intl;
            const price = isIntl ? r.priceUSD! : r.priceSDG!;
            return (
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#c9992e]/40 bg-[#e3b54a]/10 px-4 py-3">
                <div className="flex items-center gap-3 text-[#0c3b2e]">
                  <RouteIcon size={20} className="shrink-0 text-[#c9992e]" />
                  <div className="text-xs leading-6">
                    <p className="font-bold">المسافة التقريبية: {minutesLabel(r.minutes)} {isIntl && '• رحلة دولية'}</p>
                    <p className="text-[#6b5a2e]">{isIntl ? `يبدأ السعر من $${fmt(price)}` : `يبدأ السعر من ${fmt(price)} ج.س (≈ $${fmt(price / SDG_PER_USD)})`} — الرحلة: {dateLong} {time}</p>
                  </div>
                </div>
                {isIntl
                  ? <span className="rounded-full bg-[#0c3b2e] px-3 py-1 text-[10px] font-bold text-[#e3b54a]">جواز سفر مطلوب</span>
                  : <span className="rounded-full bg-[#0c3b2e] px-3 py-1 text-[10px] font-bold text-[#e3b54a]">الرقم الوطني يكفي</span>}
              </div>
            );
          })()}

          <GoldButton onClick={runSearch} disabled={searching} className="mt-4 w-full text-base !py-4">
            {searching ? <><span className="h-5 w-5 animate-spin rounded-full border-2 border-[#2b1d05]/30 border-t-[#2b1d05]" /> جاري البحث عن أشيك بص…</> : <><Search size={20} /> ابحث عن البصات المتاحة</>}
          </GoldButton>
          <p className="mt-3 text-center text-[11px] text-[#6b5a2e]">إلغاء مجاني حتى 6 ساعات قبل الإقلاع • دعم 24/7 على 19988</p>
        </div>
      )}

      {/* ─────────── الخطوة 2: اختيار البص ─────────── */}
      {step === 2 && (
        <div className="px-4 sm:px-6 pb-6">
          <TripSummary draft={draft} onEdit={() => setStep(1)} />
          <p className="mt-4 mb-2 flex items-center gap-2 font-display font-extrabold text-[#0c3b2e]"><BusFront size={19} /> البصات المتاحة على هذا الخط ({FLEET.length})</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {FLEET.map(bus => (
              <button key={bus.id} onClick={() => pickBus(bus.id)}
                className="group bus-card relative overflow-hidden rounded-2xl border border-[#0c3b2e]/15 bg-white p-3 text-start shadow-sm transition hover:-translate-y-0.5 hover:border-[#c9992e] hover:shadow-[0_16px_36px_-14px_rgba(201,153,46,.5)]">
                {bus.featured && <span className="absolute top-0 end-0 rounded-es-xl bg-gradient-to-l from-[#e3b54a] to-[#c9992e] px-2.5 py-1 text-[9px] font-black text-[#2b1d05]">الأكثر حجزاً</span>}
                <img src="/images/fleet-bus.png" alt={`بص ${bus.name}`} className="h-20 w-full object-contain drop-shadow" loading="lazy" />
                <div className="mt-1.5 flex items-center justify-between gap-2">
                  <div>
                    <p className="font-changa font-bold text-[#0c3b2e]">{bus.name} <span className="text-[10px] font-sans font-semibold text-[#8a6a12]">{bus.nameEn}</span></p>
                    <p className="text-[10px] text-[#6b5a2e]">{bus.brand} • موديل {bus.year}</p>
                  </div>
                  <span className="flex shrink-0 flex-col items-center rounded-xl bg-[#0c3b2e] px-2.5 py-1 text-[#e3b54a]">
                    <Armchair size={13} /><span className="text-[10px] font-bold">{bus.seats} مقعد</span>
                  </span>
                </div>
                <p className="mt-1.5 text-[10px] leading-4 text-[#4c5a50] line-clamp-2">{bus.tagline}</p>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {bus.onboard.slice(0, 3).map(f => <span key={f} className="rounded-md bg-[#0c3b2e]/5 px-1.5 py-0.5 text-[9px] font-semibold text-[#0c3b2e]">{f}</span>)}
                </div>
              </button>
            ))}
          </div>
          <p className="mt-3 text-center text-[10px] text-[#6b5a2e]">اضغط على أي بص لاختيار مقعدك — السعر موحّد في كل الفئات على نفس الخط.</p>
        </div>
      )}

      {/* ─────────── الخطوة 3: اختيار المقعد ─────────── */}
      {step === 3 && (
        <SeatStep draft={draft} onBack={() => setStep(2)} onPick={pickSeat} onContinue={paySummary} />
      )}

      {/* ─────────── الخطوة 4: الدفع ─────────── */}
      {step === 4 && (
        <div className="px-4 sm:px-6 pb-6">
          <TripSummary draft={draft} onEdit={() => setStep(1)} compact />

          {/* ملخص السعر + الكود */}
          <div className="mt-3 rounded-2xl border border-[#0c3b2e]/15 bg-white p-3.5 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <p className="flex items-center gap-2 text-sm font-extrabold text-[#0c3b2e]"><Landmark size={16} className="text-[#c9992e]" /> ملخص الحجز</p>
              <button onClick={() => setStep(3)} className="text-[11px] font-bold text-[#c9992e] hover:underline">تغيير المقعد {draft.seat} ←</button>
            </div>
            <div className="mt-2 space-y-1.5 text-[12px]">
              <Row label={`السعر الأساسي (${tripType === 'round' ? 'ذهاب وعودة' : 'اتجاه واحد'})`}
                   value={`${fmt(subtotal)} ${ccy}`} />
              {intl && <Row label="≈ بالجنيه السوداني" value={`≈ ${fmt(subtotal * SDG_PER_USD)} ج.س`} dim />}
              {discount > 0 && <Row label={`خصم (${promoApplied})`} value={`− ${fmt(discount)} ${ccy}`} accent />}
              <Row label="رسوم الخدمة والحجز" value={`${fmt(fee)} ${ccy}`} dim />
              <div className="flex items-center justify-between border-t border-dashed border-[#0c3b2e]/20 pt-1.5">
                <span className="font-display font-black text-[#0c3b2e]">الإجمالي</span>
                <span className="font-changa text-xl font-extrabold text-[#c9992e]">{fmt(total)} {ccy}</span>
              </div>
            </div>
            <div className="mt-2.5 flex gap-2">
              <div className="relative flex-1">
                <TicketPercent size={15} className="absolute start-3 top-1/2 -translate-y-1/2 text-[#c9992e]" />
                <input value={promo} onChange={e => setPromo(e.target.value)} placeholder="كود الخصم (جرّب GHORBA10)"
                  className={`${inputCls} !py-2 ps-9 text-xs`} aria-label="كود الخصم" />
              </div>
              <button onClick={applyPromo} className="rounded-xl bg-[#0c3b2e] px-4 text-xs font-bold text-[#f7f1e3] hover:bg-[#114e3c]">تطبيق</button>
            </div>
            {promoApplied && <p className="mt-1.5 flex items-center gap-1 text-[10px] font-bold text-emerald-700"><BadgeCheck size={12} /> {PROMOS[promoApplied].label} مفعّل</p>}
          </div>

          {/* طرق الدفع */}
          <p className="mt-4 mb-1.5 flex items-center gap-2 text-sm font-extrabold text-[#0c3b2e]"><CreditCard size={16} className="text-[#c9992e]" /> اختر طريقة الدفع</p>
          <div className="max-h-44 space-y-2 overflow-y-auto pe-1">
            {(['Sudan', 'Egypt', 'KSA', 'Intl'] as const).map(group => (
              <div key={group}>
                <p className="mb-1 text-[9px] font-black uppercase tracking-[0.2em] text-[#8a6a12]">{PAY_GROUP_LABEL[group]}</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {PAY_METHODS.filter(p => p.group === group).map(p => (
                    <button key={p.id} onClick={() => setPayId(p.id)} title={p.desc}
                      className={`flex items-center gap-2 rounded-xl border p-2 text-start transition ${payId === p.id ? 'border-[#c9992e] bg-[#e3b54a]/15 ring-2 ring-[#e3b54a]/50' : 'border-[#0c3b2e]/12 bg-white hover:border-[#c9992e]/60'}`}>
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[9px] font-black leading-tight text-center" style={{ background: p.brandBg, color: p.text }}>{p.name.slice(0, 4)}</span>
                      <span className="min-w-0 text-[10px] font-bold leading-4 text-[#22312a]">{p.nameAr}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <p className="mt-1.5 text-[10px] leading-4 text-[#6b5a2e]">{PAY_METHODS.find(p => p.id === payId)?.desc}</p>

          {/* بيانات المسافر */}
          <p className="mt-4 mb-1.5 flex items-center gap-2 text-sm font-extrabold text-[#0c3b2e]"><CircleUserRound size={16} className="text-[#c9992e]" /> بيانات المسافر</p>
          <div className="grid gap-2 sm:grid-cols-2">
            <Field label="الاسم الكامل *" error={errors.name} className="sm:col-span-2">
              <input value={name} onChange={e => setName(e.target.value)} className={inputCls} placeholder="مثال: أحمد الطيب محمد" autoComplete="name" />
            </Field>
            <Field label="رقم الهاتف *" error={errors.phone}>
              <input dir="ltr" inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} className={inputCls} placeholder="0912345678" autoComplete="tel" />
            </Field>
            <Field label={intl ? 'رقم جواز السفر *' : 'الرقم الوطني / رقم البطاقة *'} error={errors.doc}>
              <input dir="ltr" value={doc} onChange={e => setDoc(e.target.value)} className={inputCls} placeholder={intl ? 'A0123456' : '2990101234567'} />
            </Field>
            <Field label="البريد الإلكتروني (اختياري)" error={errors.email} className="sm:col-span-2">
              <input dir="ltr" type="email" value={email} onChange={e => setEmail(e.target.value)} className={inputCls} placeholder="you@example.com" autoComplete="email" />
            </Field>
            {['visa', 'mastercard', 'mada'].includes(payId) && (
              <>
                <Field label="رقم البطاقة *" error={errors.card} className="sm:col-span-2">
                  <input dir="ltr" inputMode="numeric" value={cardNum} onChange={e => setCardNum(e.target.value.replace(/[^\d ]/g, '').slice(0, 23))} className={`${inputCls} font-mono`} placeholder="4111 1111 1111 1111" />
                </Field>
                <Field label="الاسم على البطاقة *" error={errors.cardName}>
                  <input dir="ltr" value={cardName} onChange={e => setCardName(e.target.value)} className={inputCls} placeholder="AHMED ALTAYEB" />
                </Field>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="الانتهاء *" error={errors.expiry}>
                    <input dir="ltr" inputMode="numeric" value={expiry} onChange={e => setExpiry(e.target.value.replace(/[^\d/]/g, '').slice(0, 5))} className={`${inputCls} font-mono`} placeholder="12/29" />
                  </Field>
                  <Field label="CVV *" error={errors.cvv}>
                    <input dir="ltr" inputMode="numeric" type="password" value={cvv} onChange={e => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))} className={`${inputCls} font-mono`} placeholder="•••" />
                  </Field>
                </div>
              </>
            )}
          </div>

          {needsReceipt && (
            <div className="mt-3 rounded-2xl border border-[#c9992e]/40 bg-[#e3b54a]/10 p-3">
              <p className="text-xs font-extrabold text-[#0c3b2e]">ارفع إشعار الدفع</p>
              <p className="mt-0.5 text-[10px] leading-5 text-[#6b5a2e]">حوّل المبلغ ({fmt(total)} {ccy}) ثم ارفع لقطة شاشة من إشعار التحويل. بيتم تأكيد التذكرة بعد مراجعته.</p>
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                <Field label="صورة الإشعار *" error={errors.receipt}>
                  <input type="file" accept="image/*,application/pdf" onChange={e => setReceipt(e.target.files?.[0] ?? null)}
                    className="block w-full rounded-xl border border-dashed border-[#0c3b2e]/30 bg-white p-2 text-[11px] font-semibold file:me-2 file:rounded-lg file:border-0 file:bg-[#0c3b2e] file:px-3 file:py-1.5 file:text-[11px] file:font-bold file:text-[#f7f1e3]" />
                </Field>
                <Field label="رقم العملية (اختياري)">
                  <input dir="ltr" value={payRef} onChange={e => setPayRef(e.target.value)} className={inputCls} placeholder="رقم الإشعار / العملية" />
                </Field>
              </div>
            </div>
          )}

          <GoldButton onClick={submitPayment} disabled={paying} className="mt-4 w-full !py-4 text-base">
            {paying
              ? <><span className="h-5 w-5 animate-spin rounded-full border-2 border-[#2b1d05]/30 border-t-[#2b1d05]" /> جاري إرسال الحجز…</>
              : <>{needsReceipt ? 'إرسال الحجز مع الإشعار' : 'تأكيد الحجز'} — {fmt(total)} {ccy} <BadgeCheck size={19} /></>}
          </GoldButton>
          <p className="mt-2 text-center text-[10px] text-[#6b5a2e]">دفع آمن ومشفر — بصات الغربة لا تحتفظ ببيانات البطاقة على الأجهزة الشخصية.</p>
        </div>
      )}
    </WizardShell>
  );
}

/* ─────────────── مكونات فرعية ─────────────── */

function useEscape(onClose: () => void) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
}

function Field({ label, error, children, className = '' }: { label: string; error?: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1 flex items-center gap-1 text-[11px] font-bold text-[#0c3b2e]">{label}</span>
      {children}
      {error && <span className="mt-1 block text-[10px] font-bold text-rose-600">{error}</span>}
    </label>
  );
}

function CitySelect({ value, onChange, icon }: { value: string; onChange: (v: string) => void; icon: 'from' | 'to' }) {
  const groups: Array<[string, string]> = [
    ['السودان — داخل المدن', 'SD'], ['مصر', 'EG'], ['السعودية', 'SA'],
  ];
  return (
    <div className="relative">
      <MapPin size={17} className={`pointer-events-none absolute start-3.5 top-1/2 -translate-y-1/2 ${icon === 'from' ? 'text-emerald-700' : 'text-rose-600'}`} />
      <select value={value} onChange={e => onChange(e.target.value)}
        className={`${inputCls} appearance-none ps-10 pe-9 cursor-pointer`} aria-label={icon === 'from' ? 'مدينة المغادرة' : 'مدينة الوصول'}>
        {groups.map(([label, country]) => (
          <optgroup key={country} label={label}>
            {CITIES.filter(c => c.country === country && !c.id.includes('-intl')).map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </optgroup>
        ))}
      </select>
      <ChevronDown size={16} className="pointer-events-none absolute end-3 top-1/2 -translate-y-1/2 text-[#6b5a2e]" />
    </div>
  );
}

const STEPS = ['الرحلة', 'البص', 'المقعد', 'الدفع'];

function WizardShell({ children, onClose, step, title }: { children: React.ReactNode; onClose: () => void; step: number; title: string }) {
  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true" aria-label="حجز تذكرة بصات الغربة">
      <div className="absolute inset-0 bg-[#04150e]/75 backdrop-blur-[3px]" onClick={onClose} />
      <div className="relative flex max-h-[96vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-3xl sm:rounded-3xl bg-[#f7f1e3] shadow-2xl ring-1 ring-black/10">
        {/* رأس المودال */}
        <div className="relative bg-[#0c3b2e] px-4 sm:px-6 pt-4 pb-5 star-pattern">
          <button onClick={onClose} aria-label="إغلاق" className="absolute end-4 top-4 rounded-full bg-white/10 p-2 text-[#f7f1e3] hover:bg-white/20"><X size={17} /></button>
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#e3b54a]">بصات الغربة — Booking</p>
          <h3 className="mt-0.5 font-display text-xl font-black text-[#f7f1e3]">{title}</h3>
          {/* شريط الخطوات */}
          <ol className="mt-3 flex items-center gap-1" aria-label="خطوات الحجز">
            {STEPS.map((s, i) => {
              const n = i + 1;
              const state = n < step ? 'done' : n === step ? 'now' : 'todo';
              return (
                <li key={s} className="flex flex-1 items-center gap-1">
                  <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-black ring-1 ${
                    state === 'done' ? 'bg-[#e3b54a] text-[#2b1d05] ring-[#e3b54a]'
                    : state === 'now' ? 'bg-[#f7f1e3] text-[#0c3b2e] ring-[#f7f1e3]'
                    : 'bg-transparent text-[#cfe3d6] ring-[#cfe3d6]/40'}`}>{state === 'done' ? '✓' : n}</span>
                  <span className={`hidden text-[10px] font-bold sm:block ${state === 'now' ? 'text-[#f7f1e3]' : 'text-[#cfe3d6]/80'}`}>{s}</span>
                  {n < STEPS.length && <span className="mx-1 h-px flex-1 bg-[#cfe3d6]/30" />}
                </li>
              );
            })}
          </ol>
        </div>
        <div className="overflow-y-auto pt-4">{children}</div>
      </div>
    </div>
  );
}

function TripSummary({ draft, onEdit, compact = false }: { draft: ReturnType<typeof useTickets>['draft']; onEdit: () => void; compact?: boolean }) {
  const r = routeById(draft.routeId);
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-[#0c3b2e] px-4 py-3 text-[#f7f1e3]">
      <div className="flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e3b54a]/20 text-[#e3b54a]"><RouteIcon size={19} /></span>
        <div className="text-xs leading-5">
          <p className="font-display text-sm font-extrabold text-[#f7f1e3]">{draft.fromName} ← {draft.toName}</p>
          <p className="text-[#cfe3d6]">{new Date(draft.dateISO + 'T00:00:00').toLocaleDateString('ar-SD', { weekday: 'long', day: 'numeric', month: 'long' })} • {draft.time} • {draft.tripType === 'round' ? 'ذهاب وعودة' : 'اتجاه واحد'}{r && !compact ? ` • ${minutesLabel(r.minutes)}` : ''}</p>
        </div>
      </div>
      <button onClick={onEdit} className="rounded-lg border border-[#e3b54a]/50 px-3 py-1.5 text-[10px] font-bold text-[#e3b54a] hover:bg-[#e3b54a]/10">تعديل البحث</button>
    </div>
  );
}

function Row({ label, value, dim = false, accent = false }: { label: string; value: string; dim?: boolean; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className={dim ? 'text-[#6b5a2e]' : 'text-[#22312a]'}>{label}</span>
      <span className={`font-mono font-bold ${accent ? 'text-emerald-700' : dim ? 'text-[#6b5a2e]' : 'text-[#0c3b2e]'}`} dir="ltr">{value}</span>
    </div>
  );
}

/* ── خطوة المقاعد ── */
function SeatStep({ draft, onBack, onPick, onContinue }: {
  draft: ReturnType<typeof useTickets>['draft'];
  onBack: () => void; onPick: (s: number) => void; onContinue: () => void;
}) {
  const tripKey = `${draft.dateISO}|${draft.time}|${draft.busId}|${draft.routeId}`;
  const [taken, setTaken] = useState<number[]>([]);
  useEffect(() => {
    let alive = true;
    fetchTakenSeats(draft).then(r => { if (alive) setTaken(r); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tripKey]);
  const occupied = useMemo(() => {
    const set = occupiedSeats(tripKey, draft.seats, 0.42);
    taken.forEach(n => set.add(n));
    return set;
  }, [tripKey, draft.seats, taken]);
  const rows = Math.ceil(draft.seats / 4);

  return (
    <div className="px-4 sm:px-6 pb-6">
      <TripSummary draft={draft} onEdit={onBack} compact />
      <div className="mt-4 grid gap-4 sm:grid-cols-[1fr_auto]">
        {/* جسم البص */}
        <div className="rounded-3xl border-2 border-[#0c3b2e]/25 bg-gradient-to-b from-[#10473a] to-[#0c3b2e] p-3 shadow-inner">
          {/* الكابينة */}
          <div className="flex items-center justify-between rounded-2xl bg-[#071f16] px-4 py-1.5 text-[#e3b54a]">
            <span className="flex items-center gap-2 text-[10px] font-bold"><CircleUserRound size={15} /> الكابينة — {draft.brand?.split(' ')[0]}</span>
            <DoorOpen size={17} />
          </div>
          {/* رف المقاعد */}
          <div className="mt-2 grid grid-cols-[repeat(2,auto)_auto_repeat(2,auto)] items-center justify-center gap-x-2 gap-y-1.5">
            {Array.from({ length: rows }, (_, r) => {
              const base = r * 4;
              const cells = [base + 1, base + 2, null, base + 3, base + 4];
              return cells.map((s, ci) => {
                if (s === null) return <span key={`aisle-${r}`} className="w-7 text-center text-[9px] font-bold text-[#e3b54a]/50">{r + 1}</span>;
                if (s > draft.seats) return <span key={`x-${s}`} className="h-9 w-9 sm:h-10 sm:w-10" />;
                const isOcc = occupied.has(s);
                const isSel = draft.seat === s;
                return (
                  <button key={s} disabled={isOcc} onClick={() => onPick(s)}
                    aria-label={isOcc ? `مقعد ${s} محجوز` : `مقعد ${s}`} aria-pressed={isSel}
                    className={`flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-t-xl rounded-b-md text-[11px] font-black transition ${
                      isOcc ? 'cursor-not-allowed bg-[#071f16] text-[#cfe3d6]/25'
                      : isSel ? 'scale-110 bg-gradient-to-b from-[#f4cd6f] to-[#c9992e] text-[#2b1d05] ring-2 ring-white shadow-[0_0_0_3px_#c9992e]'
                      : 'bg-[#1c6b50] text-[#f7f1e3] ring-1 ring-[#e3b54a]/40 hover:bg-[#27795a]'}`}>
                    {s}
                  </button>
                );
              });
            })}
          </div>
          <div className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-[#071f16] py-1.5 text-[9px] font-bold text-[#cfe3d6]/70">
            <Wifi size={11} /> <MonitorPlay size={11} /> <Snowflake size={11} /> <Coffee size={11} /> <BedDouble size={11} /> <Sparkles size={11} /> مقصورة الغربة الملكية
          </div>
        </div>

        {/* الملخص + المتابعة */}
        <div className="flex flex-col justify-between gap-3 rounded-2xl border border-[#0c3b2e]/15 bg-white p-4 sm:w-52 shadow-sm">
          <div>
            <p className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-widest text-[#8a6a12]"><Users size={13} /> مقعدك</p>
            <p className="mt-1 font-changa text-5xl font-extrabold text-[#0c3b2e]">{draft.seat || '—'}</p>
            <div className="mt-3 space-y-1.5 text-[10px] font-semibold text-[#4c5a50]">
              <p className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm bg-[#1c6b50] ring-1 ring-[#e3b54a]/40" /> متاح للحجز</p>
              <p className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm bg-gradient-to-b from-[#f4cd6f] to-[#c9992e]" /> مقعدك المختار</p>
              <p className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm bg-[#071f16]" /> محجوز</p>
            </div>
            <p className="mt-3 rounded-lg bg-[#e3b54a]/15 px-2 py-1.5 text-[9px] leading-4 text-[#6b5a2e] ring-1 ring-[#e3b54a]/40">الكراسي الأمامية (1–4) هادئة ومناسبة للأطفال وكبار السن.</p>
          </div>
          <div className="space-y-2">
            <GoldButton onClick={onContinue} disabled={!draft.seat} className="w-full !py-3 text-sm"><CheckCircle2 size={17} /> متابعة للدفع {draft.seat ? `— مقعد ${draft.seat}` : ''}</GoldButton>
            <button onClick={onBack} className="w-full text-center text-[11px] font-bold text-[#6b5a2e] hover:text-[#0c3b2e]">← رجوع لاختيار بص آخر</button>
          </div>
        </div>
      </div>
    </div>
  );
}
