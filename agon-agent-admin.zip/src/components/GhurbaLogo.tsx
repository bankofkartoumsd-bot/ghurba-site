// شعار بصات الغربة — شمس الغربة فوق الأفق مع شمس ذهبية ونجمة ثمانية سودانية
export default function GhurbaLogo({ size = 44, withWord = true, invert = false }: {
  size?: number; withWord?: boolean; invert?: boolean;
}) {
  const gold = '#e3b54a';
  const deep = invert ? '#f7f1e3' : '#0c3b2e';
  return (
    <span className="inline-flex items-center gap-2.5 select-none" aria-label="بصات الغربة">
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill={deep} stroke={gold} strokeWidth="2.4" />
        <path d="M32 10.5 L37.5 22.5 L50.5 24.5 L40.8 33.5 L44.2 46.2 L32 39.2 L19.8 46.2 L23.2 33.5 L13.5 24.5 L26.5 22.5 Z"
          fill={gold} fillOpacity="0.22" stroke={gold} strokeWidth="1.6" strokeLinejoin="round" />
        <circle cx="32" cy="30" r="7.2" fill={gold} />
        <path d="M20 41.5h24" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
        <path d="M24 46.5h16" stroke={gold} strokeWidth="2.2" strokeLinecap="round" opacity="0.85" />
      </svg>
      {withWord && (
        <span className="leading-none">
          <span className="block font-changa font-bold text-[1.35em] tracking-tight" style={{ color: invert ? '#f7f1e3' : '#0c3b2e' }}>
            بصات <span className="text-[#c9992e]">الغربة</span>
          </span>
          <span className="block mt-1 text-[0.6em] font-medium tracking-[0.28em] uppercase" style={{ color: invert ? '#cdbf9a' : '#6b5a2e' }}>
            Busat&nbsp;Al‑Ghorba
          </span>
        </span>
      )}
    </span>
  );
}
