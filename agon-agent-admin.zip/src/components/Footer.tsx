import GhurbaLogo from './GhurbaLogo';
import { HELPLINE, HOTLINE_INTL, WHATSAPP, SOCIALS, CITIES } from '../lib/data';
import { useState, type ReactNode } from 'react';
import { Phone, MapPin, Mail, BusFront, MessageCircle } from 'lucide-react';
import {
  FacebookIcon, InstagramIcon, TikTokIcon, YouTubeIcon, XIcon,
} from './SocialIcons';

const SOCIAL_ICON: Record<string, (p: { size?: number }) => ReactNode> = {
  facebook: FacebookIcon, instagram: InstagramIcon, tiktok: TikTokIcon,
  youtube: YouTubeIcon, x: XIcon,
};

export default function Footer() {
  const stations = ['khartoum', 'portsudan', 'atbara', 'omdurman', 'kassala', 'wadmadani'];
  return (
    <footer id="contact" className="relative bg-[#071f16] text-[#cfe3d6]">
      <div className="star-pattern absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="relative">
        {/* شريط الاتصال الذهبي */}
        <div className="border-b border-[#e3b54a]/15">
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-6 sm:flex-row">
            <div className="text-center sm:text-start">
              <p className="font-display text-lg font-black text-[#f7f1e3]">عندك استفسار أو عايز تحجز بالتلفون؟</p>
              <p className="text-xs text-[#cfe3d6]/80">فريق بصات الغربة بيرد عليك 24 ساعة — داخل السودان أو من الخليج.</p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2">
              <a href={`tel:${HELPLINE}`} className="flex items-center gap-2 rounded-xl bg-[#e3b54a] px-5 py-3 font-changa text-lg font-extrabold text-[#2b1d05] shadow hover:brightness-105">
                <Phone size={19} /> <span dir="ltr">{HELPLINE}</span>
              </a>
              <a href={WHATSAPP} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-xl bg-[#25d366] px-5 py-3 font-display text-sm font-extrabold text-[#06351c] shadow hover:brightness-105">
                <MessageCircle size={18} /> واتساب
              </a>
            </div>
          </div>
        </div>

        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-12">
          {/* العلامة + سوشيال */}
          <div className="md:col-span-3">
            <GhurbaLogo size={52} invert />
            <p className="mt-4 text-sm leading-7 text-[#cfe3d6]/90">
              منذ 1998 وبصات الغربة بتربط السودان ببعضه وبالخليج ومصر — أتوبيسات حديثة، سائقون محترفون،
              وأسعار من غير ما تزعل. <span className="text-[#e3b54a]">الغربة ما بينتهي… رحلاتنا مستمرة.</span>
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {SOCIALS.map(s => {
                const Icon = SOCIAL_ICON[s.id];
                return (
                  <a key={s.id} href={s.url} target="_blank" rel="noreferrer" title={`${s.name} — ${s.handle}`} aria-label={`${s.name} ${s.handle}`}
                    className="group flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10 transition hover:bg-[#e3b54a] hover:ring-[#e3b54a]">
                    {Icon
                      ? <Icon size={20} />
                      : <Phone size={18} className="text-[#f7f1e3] transition group-hover:text-[#2b1d05]" />}
                  </a>
                );
              })}
            </div>
            <p className="mt-3 text-[10px] text-[#cfe3d6]/60" dir="ltr">{HOTLINE_INTL}</p>
          </div>

          {/* الخطوط الشائعة */}
          <nav className="md:col-span-3" aria-label="أهم الخطوط">
            <p className="font-display text-sm font-black tracking-widest text-[#e3b54a] uppercase">أهم الخطوط</p>
            <ul className="mt-3 space-y-2 text-[13px]">
              {[
                'الخرطوم ← بورتسودان — يومياً 5:30 صباحاً',
                'الخرطوم ← عطبرة — كل ساعة من 6 صباحاً',
                'الخرطوم ← القاهرة — الاثنين والخميس',
                'الخرطوم ← جدة — الثلاثاء والجمعة',
                'أم درمان ← ود مدني — كل ساعتين',
                'القضارف ← كسلا — ثلاث رحلات يومياً',
              ].map(r => <li key={r}><a href="#routes" className="hover:text-[#e3b54a] transition">{r}</a></li>)}
            </ul>
          </nav>

          {/* المواقف */}
          <div className="md:col-span-3">
            <p className="font-display text-sm font-black tracking-widest text-[#e3b54a] uppercase">المواقف الرئيسية</p>
            <ul className="mt-3 space-y-3 text-[12px] leading-6">
              {stations.map(id => {
                const c = CITIES.find(x => x.id === id)!;
                return (
                  <li key={id} className="flex items-start gap-2">
                    <MapPin size={13} className="mt-1 shrink-0 text-[#e3b54a]" />
                    <span><b className="text-[#f7f1e3]">{c.name}:</b> {c.station.split('—')[1]?.trim()}</span>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* النشرة البريدية */}
          <Newsletter />
        </div>

        {/* الشريط السفلي */}
        <div className="relative border-t border-white/10">
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-4 text-[11px] sm:flex-row">
            <p className="flex items-center gap-2"><BusFront size={13} className="text-[#e3b54a]" /> © {new Date().getFullYear()} بصات الغربة للنقل البري المحدودة — سجل تجاري 123456 — الخرطوم، السودان</p>
            <div className="flex flex-wrap items-center gap-4">
              <a href="#passes" className="hover:text-[#e3b54a]">سياسة الإلغاء والاسترداد</a>
              <a href="#contact" className="hover:text-[#e3b54a]">الخصوصية والشروط</a>
              <a href={`mailto:book@busatghorba.sd`} className="flex items-center gap-1 hover:text-[#e3b54a]" dir="ltr"><Mail size={12} /> book@busatghorba.sd</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

function Newsletter() {
  const [email, setEmail] = useState('');
  const [state, setState] = useState<'idle' | 'ok' | 'err'>('idle');
  const submit = () => {
    if (/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(email.trim())) { setState('ok'); }
    else setState('err');
  };
  return (
    <div className="md:col-span-3">
      <p className="font-display text-sm font-black tracking-widest text-[#e3b54a] uppercase">رسائل الغربة</p>
      <p className="mt-2 text-[12px] leading-6 text-[#cfe3d6]/85">عروض أسبوعيّة على الخطوط الداخلية والدولية — مرة واحدة في الأسبوع، بلا إزعاج.</p>
      {state === 'ok' ? (
        <p className="mt-3 rounded-xl bg-emerald-400/10 px-4 py-3 text-[12px] font-bold text-emerald-300 ring-1 ring-emerald-400/30">أهلاً وسهلاً بيك في عيلة الغربة! وصلتك رسالة ترحيب على بريدك.</p>
      ) : (
        <form className="mt-3 flex" onSubmit={e => { e.preventDefault(); submit(); }}>
          <label htmlFor="nl-email" className="sr-only">بريدك الإلكتروني</label>
          <input id="nl-email" type="email" dir="ltr" value={email} onChange={e => { setEmail(e.target.value); setState('idle'); }}
            placeholder="you@example.com" aria-invalid={state === 'err'}
            className="w-full rounded-s-xl border border-white/10 bg-white/5 px-3 py-2.5 text-[12px] text-[#f7f1e3] placeholder-[#cfe3d6]/40 outline-none focus:border-[#e3b54a]" />
          <button type="submit" className="rounded-e-xl bg-[#e3b54a] px-4 text-[12px] font-black text-[#2b1d05] hover:brightness-105">اشتركني</button>
        </form>
      )}
      {state === 'err' && <p className="mt-1.5 text-[10px] font-bold text-rose-400">اكتب بريد إلكتروني صحيح (مثال: name@mail.com)</p>}
    </div>
  );
}

