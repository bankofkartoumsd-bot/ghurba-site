import { MessageCircle, PhoneCall } from 'lucide-react';
import { WHATSAPP, HELPLINE } from '../lib/data';

export default function FloatingWhatsApp() {
  return (
    <div className="fixed bottom-5 end-4 z-[65] flex flex-col items-end gap-2">
      {/* زر الاتصال — يظهر على الجوال فقط */}
      <a href={`tel:${HELPLINE}`} aria-label={`اتصل بالخط الساخن ${HELPLINE}`}
        className="flex h-12 w-12 items-center justify-center rounded-full bg-[#0c3b2e] text-[#e3b54a] shadow-lg ring-2 ring-[#e3b54a]/60 transition hover:scale-110 sm:hidden">
        <PhoneCall size={20} />
      </a>
      <a href={WHATSAPP} target="_blank" rel="noreferrer" aria-label="راسلنا على واتساب"
        className="group relative flex h-14 w-14 items-center justify-center rounded-full bg-[#25d366] text-[#06351c] shadow-[0_12px_30px_-6px_rgba(37,211,102,.6)] ring-4 ring-[#25d366]/25 transition hover:scale-110">
        <span className="absolute inset-0 animate-ping rounded-full bg-[#25d366]/40" aria-hidden="true" />
        <MessageCircle size={26} className="relative" fill="#06351c" strokeWidth={0} />
        <span className="pointer-events-none absolute end-full me-3 hidden whitespace-nowrap rounded-xl bg-[#071f16] px-3 py-2 text-[10.5px] font-bold text-[#f7f1e3] shadow-xl group-hover:block">محتاج مساعدة؟ إحنا هنا 24/7</span>
      </a>
    </div>
  );
}
