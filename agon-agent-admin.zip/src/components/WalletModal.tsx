import { useEffect, useState } from 'react';
import { Wallet, Trash2, Armchair, QrCode, Printer, XCircle, Inbox, Search } from 'lucide-react';
import { ModalShell, GoldButton } from './ui';
import TicketCard from './TicketCard';
import { useTickets } from '../lib/TicketContext';
import { loadTickets, removeTicket, updateTicket, type Ticket } from '../lib/tickets';
import { cancelRemote, trackByPhone } from '../lib/remote';

export default function WalletModal({ onClose }: { onClose: () => void }) {
  const { tickets, refreshTickets, toast } = useTickets();
  const [selected, setSelected] = useState<Ticket | null>(null);
  const [phone, setPhone] = useState('');
  const [found, setFound] = useState<Ticket[] | null>(null);
  const [searching, setSearching] = useState(false);

  // مزامنة حالة تذاكر الجهاز (قيد المراجعة ← مؤكدة…) مع القاعدة عبر أرقام الهواتف المستخدمة
  useEffect(() => {
    const phones = [...new Set(loadTickets().map(t => t.passengerPhone))];
    if (!phones.length) return;
    let alive = true;
    Promise.all(phones.map(trackByPhone)).then(groups => {
      if (!alive) return;
      let changed = false;
      for (const r of groups.flat()) {
        const local = loadTickets().find(t => t.code === r.code);
        if (local && (local.status !== r.status || local.checkedIn !== r.checkedIn)) {
          updateTicket(r.code, { status: r.status, checkedIn: r.checkedIn });
          changed = true;
        }
      }
      if (changed) refreshTickets();
    });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const search = async () => {
    if (phone.replace(/\D/g, '').length < 9) { toast('رقم الهاتف غير مكتمل', 'اكتب الرقم الذي حجزت به (9 أرقام على الأقل).', 'warn'); return; }
    setSearching(true);
    const r = await trackByPhone(phone);
    setSearching(false);
    setFound(r);
  };

  const cancel = (t: Ticket) => {
    updateTicket(t.code, { status: 'ملغاة' });
    void cancelRemote(t.code);
    refreshTickets();
    setSelected(null);
    toast('تم إلغاء التذكرة', `التذكرة ${t.code} اتلغت — المبلغ بيرجع خلال 3–5 أيام عمل.`, 'info');
  };
  const wipe = (t: Ticket) => {
    removeTicket(t.code);
    refreshTickets();
    toast('اتحذفت من المحفظة', `${t.code} اتشالت نهائياً.`, 'info');
  };

  if (selected) {
    return (
      <ModalShell onClose={() => setSelected(null)} label={`تذكرة ${selected.code}`} wide>
        <div className="p-4 sm:p-6">
          <TicketCard ticket={selected} printableId="ticket-print" />
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            <GoldButton onClick={() => window.print()} className="!px-5 !py-2.5 text-sm"><Printer size={16} /> طباعة</GoldButton>
            {(selected.status === 'مؤكدة' || selected.status === 'قيد المراجعة') && (
              <button onClick={() => cancel(selected)} className="inline-flex items-center gap-2 rounded-xl border border-rose-300 bg-rose-50 px-5 py-2.5 text-sm font-bold text-rose-700 hover:bg-rose-100">
                <XCircle size={16} /> إلغاء الحجز
              </button>
            )}
            <button onClick={() => wipe(selected)} className="inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold text-[#6b5a2e] hover:bg-black/5">
              <Trash2 size={14} /> حذف نهائياً
            </button>
          </div>
        </div>
      </ModalShell>
    );
  }

  const Items = (list: Ticket[]) => list.map(t => (
              <li key={t.code}>
                <button onClick={() => setSelected(t)}
                  className="flex w-full items-center gap-3 rounded-2xl border border-[#0c3b2e]/15 bg-white p-3 text-start shadow-sm transition hover:-translate-y-0.5 hover:border-[#c9992e] hover:shadow-lg">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#0c3b2e] text-[#e3b54a]"><QrCode size={22} /></span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate font-changa text-sm font-bold text-[#0c3b2e]">{t.fromName} ← {t.toName}</span>
                      <span className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-black ${t.status === 'مؤكدة' ? 'bg-emerald-100 text-emerald-800' : t.status === 'مستخدمة' ? 'bg-sky-100 text-sky-800' : t.status === 'قيد المراجعة' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'}`}>{t.status}</span>
                    </span>
                    <span className="mt-0.5 block text-[10px] text-[#6b5a2e]">
                      {new Date(t.dateISO + 'T00:00:00').toLocaleDateString('ar-SD', { day: 'numeric', month: 'short' })} • {t.time} • مقعد {t.seat} <Armchair className="inline" size={10} />
                    </span>
                    <span className="mt-0.5 block font-mono text-[9px] font-bold tracking-widest text-[#8a6a12]" dir="ltr">{t.code}</span>
                  </span>
                </button>
              </li>
  ));

  return (
    <ModalShell onClose={onClose} label="محفظتي — تذاكري">
      <div className="p-4 sm:p-6">
        <div className="flex items-center gap-3 border-b border-[#0c3b2e]/10 pb-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#0c3b2e] text-[#e3b54a]"><Wallet size={22} /></span>
          <div>
            <h3 className="font-display text-lg font-black text-[#0c3b2e]">محفظتي</h3>
            <p className="text-[11px] text-[#6b5a2e]">{tickets.length === 0 ? 'لا توجد تذاكر محفوظة على هذا الجهاز بعد' : `${tickets.length} تذكرة محفوظة على هذا الجهاز`}</p>
          </div>
        </div>

        {/* تتبع الحجز برقم الهاتف — بدون حساب */}
        <div className="mt-3 rounded-2xl border border-[#c9992e]/40 bg-[#e3b54a]/10 p-3">
          <p className="text-xs font-extrabold text-[#0c3b2e]">تتبّع حجزك برقم الهاتف</p>
          <form className="mt-2 flex gap-2" onSubmit={e => { e.preventDefault(); void search(); }}>
            <input dir="ltr" inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="0912345678"
              className="min-w-0 flex-1 rounded-xl border border-[#0c3b2e]/20 bg-white px-3 py-2 text-sm font-semibold focus:border-[#c9992e] focus:outline-none focus:ring-2 focus:ring-[#e3b54a]/40" aria-label="رقم الهاتف" />
            <button disabled={searching} className="inline-flex items-center gap-1.5 rounded-xl bg-[#0c3b2e] px-4 text-xs font-black text-[#f7f1e3] hover:bg-[#114e3c] disabled:opacity-60">
              <Search size={14} /> {searching ? 'جاري البحث…' : 'تتبّع'}
            </button>
          </form>
          {found && (
            <div className="mt-3">
              <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold text-[#6b5a2e]">
                <span>{found.length ? `${found.length} حجز` : 'ما لقينا حجوزات بهذا الرقم'}</span>
                <button onClick={() => setFound(null)} className="hover:text-[#c9992e]">إخفاء</button>
              </div>
              <ul className="max-h-[34vh] space-y-2.5 overflow-y-auto pe-1">
                {Items(found)}
              </ul>
            </div>
          )}
        </div>

        {tickets.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-10 text-center">
            <Inbox size={44} className="text-[#c9bfa3]" />
            <p className="font-display font-extrabold text-[#0c3b2e]">محفظتك فاضية لسه</p>
            <p className="max-w-[26ch] text-xs leading-6 text-[#6b5a2e]">احجز أول تذكرة ليك — الكرت الرقمي هيظهر هنا بمجرد تأكيد الدفع.</p>
            <GoldButton onClick={onClose} className="!text-sm">احجز أول تذكرة الآن</GoldButton>
          </div>
        ) : (
          <ul className="mt-4 max-h-[62vh] space-y-2.5 overflow-y-auto pe-1">
            {Items(tickets)}
          </ul>
        )}
      </div>
    </ModalShell>
  );
}
