// أيقونات علامات سوشيال مرسومة يدوياً (لا تتوفر في lucide)
export function FacebookIcon({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={`text-[#1877f2] group-hover:!text-[#2b1d05] ${className}`} aria-hidden="true">
      <path d="M13.5 21v-6.8h2.3l.35-2.7H13.5V9.8c0-.8.35-1.6 1.9-1.6h1.4V5.9C16.4 5.8 15.3 5.7 14 5.7c-2.8 0-4.8 1.7-4.8 4.9v1.9H6.7v2.7h2.5V21h4.3z"/>
    </svg>
  );
}
export function InstagramIcon({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" className={`text-[#e1306c] group-hover:!text-[#2b1d05] ${className}`} aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="5.2"/>
      <circle cx="12" cy="12" r="4.1"/>
      <circle cx="17.4" cy="6.6" r="1.35" fill="currentColor" stroke="none"/>
    </svg>
  );
}
export function TikTokIcon({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={`text-[#f7f1e3] group-hover:!text-[#2b1d05] ${className}`} aria-hidden="true">
      <path d="M14.5 3c.4 2.6 2.4 4.7 5.1 5v3.4c-1.8 0-3.5-.6-5-1.6v6.6c0 3.5-2.6 6.1-6 6.1A5.9 5.9 0 0 1 2.6 20c0-3.6 3-6.3 6.8-5.8v3.6c-1.7-.4-3.3.8-3.3 2.6 0 1.5 1.2 2.5 2.6 2.5 1.7 0 2.8-1 2.8-3.2V3h3z"/>
    </svg>
  );
}
export function YouTubeIcon({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={`text-[#ff0000] group-hover:!text-[#2b1d05] ${className}`} aria-hidden="true">
      <path d="M21.6 7.2a2.8 2.8 0 0 0-2-2C17.9 4.8 12 4.8 12 4.8s-5.9 0-7.6.4a2.8 2.8 0 0 0-2 2A29 29 0 0 0 2 12a29 29 0 0 0 .4 4.8 2.8 2.8 0 0 0 2 2c1.7.4 7.6.4 7.6.4s5.9 0 7.6-.4a2.8 2.8 0 0 0 2-2A29 29 0 0 0 22 12a29 29 0 0 0-.4-4.8zM10.2 15V9l5.4 3z"/>
    </svg>
  );
}
export function XIcon({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={`text-[#f7f1e3] group-hover:!text-[#2b1d05] ${className}`} aria-hidden="true">
      <path d="M4 4h3.6l6.1 9.3L19.7 4H22l-8 10.6 8.4 9.4h-3.6l-6.5-9.8L4.9 24H2.5l8.4-11z"/>
    </svg>
  );
}
