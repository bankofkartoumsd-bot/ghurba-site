import { useCallback, useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, ScanLine, Search, CheckCircle2, XCircle, Armchair, Keyboard, RefreshCw, SquareCheckBig } from 'lucide-react';
import { ModalShell, GoldButton } from './ui';
import { useTickets } from '../lib/TicketContext';
import { loadTickets, updateTicket, type Ticket } from '../lib/tickets';
import { checkInRemote, getTicketRemote } from '../lib/remote';

type ScanState =
  | { kind: 'scanning' }
  | { kind: 'found'; ticket: Ticket }
  | { kind: 'notfound'; code: string }
  | { kind: 'error'; message: string };

export default function ScannerModal({ onClose }: { onClose: () => void }) {
  const { refreshTickets, toast } = useTickets();
  const [mode, setMode] = useState<'camera' | 'manual'>('camera');
  const [state, setState] = useState<ScanState>({ kind: 'scanning' });
  const [manual, setManual] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);

  const lookup = useCallback(async (raw: string) => {
    const cleaned = raw.trim().toUpperCase();
    let code = cleaned;
    try {
      const parsed = JSON.parse(raw);
      if (parsed?.code) code = String(parsed.code).toUpperCase();
    } catch { /* نص خام */ }
    // المشرف المسجّل دخوله يرى أي تذكرة من القاعدة؛ غيره يرى تذاكر جهازه فقط
    const ticket = (await getTicketRemote(code)) ?? loadTickets().find(t => t.code === code);
    if (ticket) { setState({ kind: 'found', ticket }); }
    else setState({ kind: 'notfound', code });
  }, []);

  // ── الكاميرا ────────────────────────────────
  const stopCamera = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => {
    if (mode !== 'camera' || state.kind !== 'scanning') { stopCamera(); return; }
    let cancelled = false;
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('هذا المتصفح لا يدعم الكاميرا');
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        setCameraError(null);
        const video = videoRef.current!;
        video.srcObject = stream;
        await video.play();

        const tick = () => {
          const canvas = canvasRef.current, vid = videoRef.current;
          if (!canvas || !vid || vid.readyState !== vid.HAVE_ENOUGH_DATA) { rafRef.current = requestAnimationFrame(tick); return; }
          canvas.width = vid.videoWidth; canvas.height = vid.videoHeight;
          const ctx = canvas.getContext('2d', { willReadFrequently: true });
          if (!ctx) { rafRef.current = requestAnimationFrame(tick); return; }
          ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
          const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const result = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
          if (result?.data) { stopCamera(); lookup(result.data); return; }
          rafRef.current = requestAnimationFrame(tick);
        };
        rafRef.current = requestAnimationFrame(tick);
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof DOMException && (err.name === 'NotAllowedError' || err.name === 'SecurityError')
          ? 'إذن الكاميرا مرفوض — فعّلها من إعدادات المتصفح أو استخدم الإدخال اليدوي.'
          : 'تعذر تشغيل الكاميرا — استخدم الإدخال اليدوي بالكود.';
        setCameraError(msg);
        setMode('manual');
      }
    })();
    return () => { cancelled = true; stopCamera(); };
  }, [mode, state.kind, lookup, stopCamera]);

  const reset = () => { setState({ kind: 'scanning' }); setManual(''); };

  const toggleCheckIn = (t: Ticket) => {
    if (t.status === 'قيد المراجعة' || t.status === 'مرفوضة' || t.status === 'ملغاة') {
      toast('لا يمكن تسجيل الصعود', `حالة الحجز: ${t.status}`, 'warn');
      return;
    }
    const next = !t.checkedIn;
    updateTicket(t.code, { checkedIn: next, status: next ? 'مستخدمة' : 'مؤكدة' });
    void checkInRemote(t.code, next);
    refreshTickets();
    setState({ kind: 'found', ticket: { ...t, checkedIn: next, status: next ? 'مستخدمة' : 'مؤكدة' } });
    toast(next ? 'تم تسجيل الصعود ✓' : 'تم التراجع عن تسجيل الصعود', `المقعد ${t.seat} — ${t.passengerName}`, next ? 'ok' : 'info');
  };

  return (
    <ModalShell onClose={onClose} label="ماسح كرت الصعود">
      <div className="p-4 sm:p-6">
        <div className="flex items-center gap-3 border-b border-[#0c3b2e]/10 pb-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#0c3b2e] text-[#e3b54a]"><ScanLine size={22} /></span>
          <div>
            <h3 className="font-display text-lg font-black text-[#0c3b2e]">ماسح كرت الصعود</h3>
            <p className="text-[11px] text-[#6b5a2e]">امسح الـ QR من كرت المسافر أو اكتب الكود يدوياً للتحقق</p>
          </div>
        </div>

        {/* محوّل الكاميرا/اليدوي */}
        <div className="mt-3 grid grid-cols-2 gap-1 rounded-xl bg-[#0c3b2e]/5 p-1 ring-1 ring-[#0c3b2e]/10">
          {([['camera', 'مسح بالكاميرا', Camera], ['manual', 'إدخال يدوي', Keyboard]] as const).map(([m, label, Icon]) => (
            <button key={m} onClick={() => { setMode(m as 'camera' | 'manual'); setState({ kind: 'scanning' }); setCameraError(null); }}
              className={`flex items-center justify-center gap-2 rounded-lg py-2 text-[12px] font-bold transition ${mode === m ? 'bg-[#0c3b2e] text-[#e3b54a] shadow' : 'text-[#0c3b2e]'}`}>
              <Icon size={15} />{label}
            </button>
          ))}
        </div>
        {cameraError && <p className="mt-2 rounded-lg bg-amber-50 px-3 py-2 text-[11px] font-bold text-amber-800 ring-1 ring-amber-300">{cameraError}</p>}

        {/* منطقة المسح */}
        {state.kind === 'scanning' && mode === 'camera' && (
          <div className="relative mt-3 overflow-hidden rounded-2xl bg-black ring-1 ring-[#0c3b2e]/30" style={{ aspectRatio: '4/3' }}>
            <video ref={videoRef} muted playsInline autoPlay className="h-full w-full object-cover" />
            <canvas ref={canvasRef} className="hidden" />
            {/* إطار الاستهداف */}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div className="relative h-40 w-40">
                {['top-0 start-0 border-t-4 border-s-4 rounded-tr-2xl', 'top-0 end-0 border-t-4 border-e-4 rounded-tl-2xl', 'bottom-0 start-0 border-b-4 border-s-4 rounded-br-2xl', 'bottom-0 end-0 border-b-4 border-e-4 rounded-bl-2xl'].map(c => (
                  <span key={c} className={`absolute h-9 w-9 border-[#e3b54a] ${c}`} />
                ))}
                <span className="absolute inset-x-3 top-1/2 h-0.5 -translate-y-1/2 bg-gradient-to-l from-transparent via-[#e3b54a] to-transparent animate-pulse" />
              </div>
            </div>
            <p className="absolute bottom-2 inset-x-0 text-center text-[10px] font-bold text-white/85">وجّه الكاميرا نحو الـ QR على كرت الصعود</p>
          </div>
        )}

        {state.kind === 'scanning' && mode === 'manual' && (
          <form className="mt-3" onSubmit={e => { e.preventDefault(); if (manual.trim()) lookup(manual); }}>
            <label className="text-[11px] font-bold text-[#0c3b2e]" htmlFor="manual-code">كود التذكرة</label>
            <div className="mt-1 flex gap-2">
              <input id="manual-code" autoFocus dir="ltr" value={manual} onChange={e => setManual(e.target.value.toUpperCase())}
                placeholder="GR-2026-X4K7A2" className="w-full rounded-xl border border-[#0c3b2e]/25 bg-white px-4 py-3 font-mono text-base font-bold tracking-[0.15em] text-[#0c3b2e] placeholder-[#9aa89c] outline-none focus:border-[#c9992e] focus:ring-2 focus:ring-[#e3b54a]/40" />
              <GoldButton type="submit" className="!px-5"><Search size={18} /></GoldButton>
            </div>
            <p className="mt-2 text-[10px] text-[#6b5a2e]">الكود مطبوع أسفل الـ QR على الكرت — يبدأ بـ GR-</p>
          </form>
        )}

        {/* ── نتيجة: تم العثور ── */}
        {state.kind === 'found' && (
          <div className="mt-4 rounded-2xl border-2 border-emerald-500 bg-emerald-50 p-4 text-center ring-4 ring-emerald-100">
            <CheckCircle2 size={46} className="mx-auto text-emerald-600" />
            <p className="mt-1.5 font-display text-lg font-black text-emerald-800">تذكرة صالحة ✓</p>
            <p className="mt-0.5 font-mono text-xs font-bold tracking-[0.2em] text-emerald-900" dir="ltr">{state.ticket.code}</p>

            <dl className="mx-auto mt-3 grid max-w-sm grid-cols-2 gap-2 text-start text-[11px]">
              <Info label="المسافر" value={state.ticket.passengerName} />
              <Info label="الهاتف" value={state.ticket.passengerPhone} mono />
              <Info label="الرحلة" value={`${state.ticket.fromName} ← ${state.ticket.toName}`} />
              <Info label="التاريخ والوقت" value={`${new Date(state.ticket.dateISO + 'T00:00:00').toLocaleDateString('ar-SD', { day: 'numeric', month: 'long' })} — ${state.ticket.time}`} />
              <Info label="البص" value={state.ticket.busName} />
              <Info label="المقعد" value={`${state.ticket.seat}`} strong />
            </dl>

            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              <button onClick={() => toggleCheckIn(state.ticket)}
                className={`inline-flex items-center gap-2 rounded-xl px-5 py-3 font-display text-sm font-extrabold shadow transition ${state.ticket.checkedIn ? 'bg-sky-700 text-white hover:bg-sky-800' : 'bg-emerald-600 text-white hover:bg-emerald-700'}`}>
                <SquareCheckBig size={17} />
                {state.ticket.checkedIn ? 'مسجّل صعوده — تراجع' : 'سجّل صعود المسافر'}
              </button>
              <button onClick={reset} className="inline-flex items-center gap-2 rounded-xl border border-[#0c3b2e]/25 px-4 py-3 text-xs font-bold text-[#0c3b2e] hover:bg-[#0c3b2e]/5">
                <RefreshCw size={14} /> مسح تذكرة أخرى
              </button>
            </div>
          </div>
        )}

        {/* ── نتيجة: غير موجودة ── */}
        {state.kind === 'notfound' && (
          <div className="mt-4 rounded-2xl border-2 border-rose-400 bg-rose-50 p-5 text-center ring-4 ring-rose-100">
            <XCircle size={46} className="mx-auto text-rose-600" />
            <p className="mt-1.5 font-display text-lg font-black text-rose-800">تذكرة غير موجودة</p>
            <p className="mt-1 text-[12px] text-rose-900">الكود <span className="font-mono font-bold" dir="ltr">{state.code}</span> غير مسجل على هذا الجهاز — تأكد من الكود أو راجع شباك الغربة.</p>
            <button onClick={reset} className="mt-3 inline-flex items-center gap-2 rounded-xl bg-[#0c3b2e] px-5 py-2.5 text-xs font-bold text-[#f7f1e3] hover:bg-[#114e3c]"><RefreshCw size={14} /> حاول مرة أخرى</button>
          </div>
        )}

        <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[9.5px] text-[#6b5a2e]"><Armchair size={11} /> بوابات الغربة تقبل مسح الـ QR أو إدخال الكود يدوياً — التحقق يتم محلياً على الجهاز</p>
      </div>
    </ModalShell>
  );
}

function Info({ label, value, mono = false, strong = false }: { label: string; value: string; mono?: boolean; strong?: boolean }) {
  return (
    <div className="rounded-xl bg-white px-3 py-2 ring-1 ring-emerald-200">
      <dt className="text-[9px] font-black uppercase tracking-widest text-emerald-700/70">{label}</dt>
      <dd className={`mt-0.5 text-[#0c3b2e] ${mono ? 'font-mono' : ''} ${strong ? 'font-changa text-base font-extrabold' : 'text-[11px] font-bold'}`}>{value}</dd>
    </div>
  );
}
