import { type ReactNode, useEffect } from 'react';
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react';
import { useTickets } from '../lib/TicketContext';

/* ── زر رئيسي ذهبي ─────────────────────────────── */
export function GoldButton({ children, onClick, className = '', type = 'button', disabled }: {
  children: ReactNode; onClick?: () => void; className?: string; type?: 'button' | 'submit'; disabled?: boolean;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`shine-wrap inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-[#f4cd6f] via-[#e3b54a] to-[#c9992e] px-6 py-3 font-display font-extrabold text-[#2b1d05] shadow-[0_10px_26px_-8px_rgba(201,153,46,.65),inset_0_1px_0_rgba(255,255,255,.8)] ring-1 ring-[#8a6a12] transition hover:brightness-105 active:translate-y-[1px] disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
    >
      {children}
    </button>
  );
}

/* ── زر داكن ─────────────────────────────── */
export function DarkButton({ children, onClick, className = '', type = 'button', outline = false }: {
  children: ReactNode; onClick?: () => void; className?: string; type?: 'button' | 'submit'; outline?: boolean;
}) {
  const base = outline
    ? 'bg-transparent text-[#f7f1e3] ring-1 ring-[#e3b54a]/70 hover:bg-[#e3b54a]/10'
    : 'bg-[#0c3b2e] text-[#f7f1e3] hover:bg-[#114e3c] ring-1 ring-[#071f16] shadow-[0_10px_26px_-10px_rgba(7,31,22,.7)]';
  return (
    <button type={type} onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3 font-display font-bold transition active:translate-y-[1px] ${base} ${className}`}>
      {children}
    </button>
  );
}

/* ── عنوان قسم بالنمط السوداني ───────────────────── */
export function SectionHead({ kicker, title, sub, dark = false }: {
  kicker: string; title: string; sub?: string; dark?: boolean;
}) {
  return (
    <div className="text-center">
      <div className={`inline-flex items-center gap-3 text-[0.72rem] font-bold tracking-[0.32em] uppercase ${dark ? 'text-[#e3b54a]' : 'text-[#c9992e]'}`}>
        <span aria-hidden="true" className="h-px w-8 bg-current opacity-70" />
        <span>{kicker}</span>
        <span aria-hidden="true" className="h-px w-8 bg-current opacity-70" />
      </div>
      <h2 className={`mt-3 font-display font-black text-3xl md:text-4xl leading-[1.25] ${dark ? 'text-[#f7f1e3]' : 'text-[#0c3b2e]'}`}>
        {title}
      </h2>
      {sub && <p className={`mt-3 max-w-2xl mx-auto leading-7 ${dark ? 'text-[#cfe3d6]/90' : 'text-[#4c5a50]'}`}>{sub}</p>}
    </div>
  );
}

/* ── مودال عام (يُستخدم للماسح وشاشات المعاونة) ────── */
export function ModalShell({ children, onClose, label, wide = false }: {
  children: ReactNode; onClose: () => void; label: string; wide?: boolean;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center" role="dialog" aria-modal="true" aria-label={label}>
      <div className="absolute inset-0 bg-[#04150e]/70 backdrop-blur-[3px]" onClick={onClose} />
      <div className={`relative w-full ${wide ? 'max-w-3xl' : 'max-w-lg'} max-h-[94vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-[#fcfaf3] shadow-2xl ring-1 ring-black/10 animate-[modalIn_.28s_ease]`}>
        <button onClick={onClose} aria-label="إغلاق" className="absolute top-3 end-3 z-10 rounded-full bg-black/5 p-2 text-[#22312a] hover:bg-black/10 transition">
          <X size={18} />
        </button>
        {children}
      </div>
      <style>{`@keyframes modalIn{from{transform:translateY(36px);opacity:0}to{transform:none;opacity:1}}`}</style>
    </div>
  );
}

/* ── نظام التبيهات Toast ────────────────────────── */
const TOAST_STYLE = {
  ok:   { icon: CheckCircle2, bar: '#0e9f6e' },
  warn: { icon: AlertTriangle, bar: '#d97706' },
  err:  { icon: XCircle, bar: '#dc2626' },
  info: { icon: Info, bar: '#0c3b2e' },
} as const;

export function ToastViewport() {
  const { toasts, dismissToast } = useTickets();
  return (
    <div className="fixed bottom-5 start-1/2 -translate-x-1/2 z-[80] flex w-[min(92vw,420px)] flex-col gap-2" aria-live="polite">
      {toasts.map(t => {
        const S = TOAST_STYLE[t.tone];
        const Icon = S.icon;
        return (
          <div key={t.id} className="flex items-start gap-3 rounded-2xl bg-[#0c3b2e]/95 text-[#f7f1e3] p-3 pe-2 shadow-xl ring-1 ring-[#e3b54a]/40 backdrop-blur">
            <Icon size={20} className="mt-0.5 shrink-0" style={{ color: S.bar }} />
            <div className="min-w-0 flex-1">
              <p className="font-bold text-sm leading-6">{t.title}</p>
              {t.desc && <p className="text-xs text-[#cfe3d6] leading-5 mt-0.5">{t.desc}</p>}
            </div>
            <button onClick={() => dismissToast(t.id)} aria-label="إغلاق التنبيه" className="p-1.5 rounded-lg hover:bg-white/10"><X size={16} /></button>
          </div>
        );
      })}
    </div>
  );
}

/* ── شارة ذهبية صغيرة ────────────────────────────── */
export function GoldPill({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-[#e3b54a]/15 px-3 py-1 text-[11px] font-bold text-[#8a6a12] ring-1 ring-[#e3b54a]/50">
      {children}
    </span>
  );
}
