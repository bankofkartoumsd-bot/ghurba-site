import { QRCodeSVG } from 'qrcode.react';
import { Armchair, CalendarDays, Clock, Landmark, User, Phone, CreditCard, Hash, ShieldCheck } from 'lucide-react';
import GhurbaLogo from './GhurbaLogo';
import { PAY_METHODS, SDG_PER_USD, fmt, cityById } from '../lib/data';
import type { Ticket } from '../lib/tickets';

export function qrPayload(t: Ticket) {
  return JSON.stringify({
    app: 'BUSAT-ALGHORBA', v: 1, code: t.code,
    route: `${t.fromId}>${t.toId}`, date: t.dateISO, time: t.time,
    seat: t.seat, passenger: t.passengerName,
  });
}

export default function TicketCard({ ticket, printableId }: { ticket: Ticket; printableId?: string }) {
  const pay = PAY_METHODS.find(p => p.id === ticket.paidWith);
  const amount = ticket.intl
    ? `$${fmt(ticket.amount)}`
    : `${fmt(ticket.amount)} ج.س`;
  const amountAlt = ticket.intl
    ? `≈ ${fmt(ticket.amount * SDG_PER_USD)} ج.س`
    : `≈ $${fmt(ticket.amount / SDG_PER_USD)}`;
  const dateLabel = new Date(ticket.dateISO + 'T00:00:00').toLocaleDateString('ar-SD', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div
      id={printableId}
      dir="rtl"
      className="relative w-full overflow-hidden rounded-2xl bg-[#fdfcf6] shadow-[0_22px_50px_-18px_rgba(7,31,22,.5)] ring-1 ring-[#0c3b2e]/20"
    >
      {/* الشريط العلوي */}
      <div className="star-pattern flex items-center justify-between gap-3 bg-[#0c3b2e] px-4 py-2.5 text-[#f7f1e3]">
        <GhurbaLogo size={30} withWord={false} invert />
        <div className="text-center">
          <p className="font-changa text-sm sm:text-base font-semibold tracking-wide text-[#e3b54a]">كرت صعود رقمي</p>
          <p className="text-[9px] text-[#cfe3d6] tracking-[0.25em] uppercase" dir="ltr">Digital Boarding Pass</p>
        </div>
        <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold ring-1 ${
          ticket.status === 'مؤكدة' ? 'bg-emerald-400/15 text-emerald-300 ring-emerald-400/40'
          : ticket.status === 'مستخدمة' ? 'bg-sky-400/15 text-sky-300 ring-sky-400/40'
          : ticket.status === 'قيد المراجعة' ? 'bg-amber-400/15 text-amber-300 ring-amber-400/40'
          : 'bg-rose-400/15 text-rose-300 ring-rose-400/40'
        }`}>
          <ShieldCheck size={12} />{ticket.status}
        </span>
      </div>

      <div className="relative flex flex-col sm:flex-row">
        {/* القصاصة الجانبية — QR */}
        <div className="relative flex sm:w-[34%] flex-col items-center justify-center gap-1.5 border-b sm:border-b-0 sm:border-s border-dashed border-[#0c3b2e]/30 bg-[#f3efdd] px-4 py-4">
          {/* ثقوب التمزيق */}
          <span aria-hidden="true" className="absolute -top-2.5 start-1/2 h-5 w-5 -translate-x-1/2 rounded-full bg-[#f7f1e3] ring-1 ring-[#0c3b2e]/10" />
          <span aria-hidden="true" className="absolute -bottom-2.5 start-1/2 h-5 w-5 -translate-x-1/2 rounded-full bg-[#f7f1e3] ring-1 ring-[#0c3b2e]/10 sm:-start-2.5 sm:top-1/2 sm:-translate-y-1/2 sm:translate-x-0 sm:h-5 sm:w-5" />
          <QRCodeSVG value={qrPayload(ticket)} size={108} bgColor="#fdfcf6" fgColor="#0c3b2e" level="M" includeMargin={false} />
          <p className="font-mono text-[11px] font-bold tracking-[0.18em] text-[#0c3b2e]" dir="ltr">{ticket.code}</p>
          <p className="text-[9px] text-[#6b5a2e]">امسح الكرت عند البوابة — صالح لرحلة واحدة</p>
        </div>

        {/* جسم التذكرة */}
        <div className="flex-1 px-4 py-3.5">
          <div className="flex items-end justify-between gap-2 border-b border-[#0c3b2e]/10 pb-2">
            <div className="min-w-0">
              <p className="text-[10px] font-bold text-[#8a6a12] uppercase tracking-widest">{cityById(ticket.fromId)?.nameEn} ← {cityById(ticket.toId)?.nameEn}</p>
              <p className="font-changa text-lg sm:text-2xl font-bold leading-8 text-[#0c3b2e] truncate">
                {ticket.fromName} <span className="text-[#c9992e]">←</span> {ticket.toName}
              </p>
            </div>
            <div className="shrink-0 text-center">
              <p className="text-[9px] font-bold text-[#8a6a12] uppercase">المقعد</p>
              <p className="font-changa text-3xl font-extrabold leading-8 text-[#c9992e]">{ticket.seat}</p>
            </div>
          </div>

          <div className="mt-2 grid grid-cols-3 gap-x-3 gap-y-2 text-[11px]">
            <Meta icon={<CalendarDays size={12} />} label="التاريخ" value={dateLabel} wide />
            <Meta icon={<Clock size={12} />} label="الإقلاع" value={ticket.time} mono />
            <Meta icon={<Landmark size={12} />} label="البص" value={ticket.busName} />
            <Meta icon={<Hash size={12} />} label="نوع الرحلة" value={ticket.tripType === 'round' ? 'ذهاب وعودة' : 'اتجاه واحد'} />
            <Meta icon={<User size={12} />} label="المسافر" value={ticket.passengerName} wide />
            <Meta icon={<Phone size={12} />} label="الهاتف" value={ticket.passengerPhone} mono />
            <Meta icon={<CreditCard size={12} />} label="الدفع عبر" value={pay?.nameAr ?? ticket.paidWith} wide />
          </div>

          <div className="mt-2.5 flex items-center justify-between border-t border-[#0c3b2e]/10 pt-2">
            <div>
              <p className="text-[9px] font-bold text-[#8a6a12] uppercase tracking-widest">المبلغ المدفوع</p>
              <p className="font-changa text-lg font-bold text-[#0c3b2e]">{amount} <span className="text-[10px] font-medium text-[#6b5a2e]">({amountAlt})</span></p>
            </div>
            <div className="text-end">
              <Armchair size={14} className="ms-auto text-[#c9992e]" />
              <p className="text-[9px] text-[#6b5a2e]">الغربة — الرحلة بتاعتك من هنا</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Meta({ icon, label, value, wide = false, mono = false }: {
  icon: React.ReactNode; label: string; value: string; wide?: boolean; mono?: boolean;
}) {
  return (
    <div className={wide ? 'col-span-2 sm:col-span-1' : ''}>
      <p className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider text-[#8a6a12]">{icon}{label}</p>
      <p className={`mt-0.5 leading-4 text-[#22312a] ${mono ? 'font-mono' : ''} font-semibold truncate`} title={value}>{value}</p>
    </div>
  );
}
