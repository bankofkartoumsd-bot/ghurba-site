import { useEffect, useState } from 'react';
import { Menu, X, Phone, Wallet, BusFront, QrCode, Ticket } from 'lucide-react';
import GhurbaLogo from './GhurbaLogo';
import WalletModal from './WalletModal';
import ScannerModal from './ScannerModal';
import { HELPLINE } from '../lib/data';
import { useTickets } from '../lib/TicketContext';

const LINKS = [
  { href: '#home', label: 'الرئيسية' },
  { href: '#routes', label: 'الخطوط والمواعيد' },
  { href: '#fleet', label: 'الأسطول' },
  { href: '#passes', label: 'باقات الغربة' },
  { href: '#contact', label: 'تواصل معنا' },
];

export default function Navbar() {
  const { setBookingOpen, tickets } = useTickets();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { document.body.style.overflow = open ? 'hidden' : ''; return () => { document.body.style.overflow = ''; }; }, [open]);

  return (
    <>
      {/* الشريط العلوي */}
      <div className="relative z-[60] bg-[#071f16] text-[#e9e2c8]">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-2 px-4 py-1.5 text-[10.5px] sm:text-[11px]">
          <a href={`tel:${HELPLINE}`} className="flex items-center gap-1.5 font-bold hover:text-[#e3b54a] transition">
            <Phone size={12} className="text-[#e3b54a]" />
            <span dir="ltr">{HELPLINE}</span>
            <span className="hidden md:inline text-[#cfe3d6]/80 font-medium">— الخط الساخن 24/7</span>
          </a>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline text-[#cfe3d6]/80">الخرطوم ← بورتسودان • جدة • القاهرة — يومياً</span>
            <span className="flex items-center gap-1 font-bold text-[#e3b54a]"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" /> متاح الآن</span>
          </div>
        </div>
      </div>

      {/* شريط التنقل */}
      <header className={`sticky top-0 z-50 border-b transition-all duration-300 ${scrolled ? 'bg-[#f7f1e3]/92 shadow-[0_6px_30px_-12px_rgba(7,31,22,.35)] backdrop-blur-xl border-[#0c3b2e]/10' : 'bg-[#f7f1e3] border-transparent'}`}>
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-2 px-4 py-2.5">
          <a href="#home" aria-label="بصات الغربة — الرئيسية" className="shrink-0"><GhurbaLogo size={44} /></a>

          <nav className="hidden lg:flex items-center gap-1" aria-label="التنقل الرئيسي">
            {LINKS.map(l => (
              <a key={l.href} href={l.href} className="rounded-lg px-3.5 py-2 text-[13px] font-bold text-[#0c3b2e] transition hover:bg-[#0c3b2e]/8 hover:text-[#c9992e]">{l.label}</a>
            ))}
          </nav>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button onClick={() => setScannerOpen(true)} title="ماسح كرت الصعود" aria-label="ماسح كرت الصعود"
              className="rounded-xl p-2.5 text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 transition hover:bg-[#0c3b2e] hover:text-[#e3b54a]">
              <QrCode size={19} />
            </button>
            <button onClick={() => setWalletOpen(true)} title="محفظتي" aria-label="محفظتي"
              className="relative rounded-xl p-2.5 text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 transition hover:bg-[#0c3b2e] hover:text-[#e3b54a]">
              <Wallet size={19} />
              {tickets.length > 0 && <span className="absolute -top-1.5 -end-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-[#c9992e] px-1 text-[9px] font-black text-[#2b1d05] ring-2 ring-[#f7f1e3]">{tickets.length}</span>}
            </button>
            <button onClick={() => setBookingOpen(true)}
              className="hidden sm:inline-flex items-center gap-2 rounded-xl bg-[#0c3b2e] px-4 py-2.5 font-display text-[13px] font-extrabold text-[#f7f1e3] shadow-md transition hover:bg-[#114e3c]">
              <Ticket size={16} className="text-[#e3b54a]" /> احجز تذكرتك
            </button>
            <button onClick={() => setOpen(v => !v)} className="rounded-xl p-2.5 text-[#0c3b2e] ring-1 ring-[#0c3b2e]/20 lg:hidden" aria-label={open ? 'إغلاق القائمة' : 'فتح القائمة'} aria-expanded={open}>
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* القائمة المتنقلة */}
        {open && (
          <div className="lg:hidden border-t border-[#0c3b2e]/10 bg-[#f7f1e3] shadow-2xl">
            <div className="mx-auto max-w-7xl px-4 py-3">
              {LINKS.map(l => (
                <a key={l.href} href={l.href} onClick={() => setOpen(false)}
                  className="flex items-center justify-between border-b border-[#0c3b2e]/8 py-3.5 font-display font-extrabold text-[#0c3b2e]">
                  {l.label}<span className="text-[#c9992e]">←</span>
                </a>
              ))}
              <button onClick={() => { setOpen(false); setBookingOpen(true); }}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-[#0c3b2e] py-3.5 font-display font-extrabold text-[#e3b54a]">
                <BusFront size={18} /> احجز تذكرتك الآن
              </button>
            </div>
          </div>
        )}
      </header>

      {walletOpen && <WalletModal onClose={() => setWalletOpen(false)} />}
      {scannerOpen && <ScannerModal onClose={() => setScannerOpen(false)} />}
    </>
  );
}
