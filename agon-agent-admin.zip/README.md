# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) (or [oxc](https://oxc.rs) when used in [rolldown-vite](https://vite.dev/guide/rolldown)) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type-aware lint rules:

```js
export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      // Other configs...

      // Remove tseslint.configs.recommended and replace with this
      tseslint.configs.recommendedTypeChecked,
      // Alternatively, use this for stricter rules
      tseslint.configs.strictTypeChecked,
      // Optionally, add this for stylistic rules
      tseslint.configs.stylisticTypeChecked,

      // Other configs...
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
      // other options...
    },
  },
])
```

You can also install [eslint-plugin-react-x](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-x) and [eslint-plugin-react-dom](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-dom) for React-specific lint rules:

```js
// eslint.config.js
import reactX from 'eslint-plugin-react-x'
import reactDom from 'eslint-plugin-react-dom'

export default defineConfig([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      // Other configs...
      // Enable lint rules for React
      reactX.configs['recommended-typescript'],
      // Enable lint rules for React DOM
      reactDom.configs.recommended,
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
      // other options...
    },
  },
])
```

---

## لوحة الإدارة (Supabase)

- الرابط: `/#/admin` — تسجيل دخول بالبريد وكلمة المرور (Supabase Auth).
- الأقسام: نظرة عامة • الحجوزات (بحث، تسجيل صعود، إلغاء، CSV) • الرحلات (الإشغال) • التقارير.
- الجداول: `ghurba_tickets` و `ghurba_admins` (RLS مفعّل؛ الزوار يحجزون فقط، والمشرفون يقرؤون ويعدّلون).
- المتغيرات: انسخ `.env.example` إلى `.env.local` وضع رابط المشروع والمفتاح العام.

### إضافة أول مشرف
1. أنشئ مستخدماً من Supabase → Authentication → Users (بريد + كلمة مرور).
2. نفّذ في SQL Editor:
```sql
insert into public.ghurba_admins (user_id)
select id from auth.users where email = 'ضع-بريدك-هنا';
```

ثم `npm install` (يحدّث package-lock لإضافة `@supabase/supabase-js`) و `npm run dev`.

### تدفق الحجز بدون حساب
1. الزبون يحجز ويرفع صورة إشعار الدفع (بنكك وغيرها) — الحجز يبدأ **قيد المراجعة**.
2. المشرف يراجع الإشعار من `/#/admin` ← الحجوزات ← «تأكيد الدفع» أو «رفض» (الرفض يحرر المقعد).
3. الزبون يتتبّع حجزه من «محفظتي» برقم هاتفه، وعند التأكيد يظهر له كرت الصعود.
- إشعارات الدفع في مخزن خاص `ghurba-receipts` (5 ميجا، صور أو PDF) ولا يراها إلا المشرفون.

### شركة أبو يوسف — قوائم الركاب
- كل البصات 48 مقعداً (`BUS_CAPACITY` في `src/lib/data.ts`) واسم الشركة في `COMPANY_NAME`.
- الدفع إلكتروني فقط (لا يوجد دفع نقدي).
- عند اكتمال رحلة (48/48) يظهر تنبيه في «نظرة عامة» وزر «مكتملة — اطبع» في تبويب «الرحلات»؛ ويمكن طباعة قائمة أي رحلة في أي وقت.
- القائمة (A4): م • المقعد • رقم التذكرة • الاسم • رقم الهاتف • خانة صعود.
